#pragma once
#include "alphamah/core.hpp"
#include <memory>
namespace alphamah::paper {
// Optimistic leaf semantics: does a winning subset exist within these available tiles?
bool contains_win(const Hand& available,Rules rules={});
// Own the rule cache for one host search; TLS holds only a borrowed pointer.
class SubsetContext {
    struct Impl;
    std::unique_ptr<Impl> impl;
public:
    SubsetContext();
    ~SubsetContext();
    SubsetContext(const SubsetContext&)=delete;
    SubsetContext& operator=(const SubsetContext&)=delete;
};
}
