#pragma once
#include "alphamah/core.hpp"
#include <memory>
#include <random>

namespace alphamah {
unsigned random_bounded(std::mt19937& rng, unsigned size);
enum class RoundPhase { Turn, Response, NeedDraw, Terminal, Truncated };
struct TableState {
    std::array<Hand,4> hands;
    std::array<std::vector<PublicDiscard>,4> rivers;
    std::vector<int> wall;
    Payments scores{}, income{}, loss{};
    std::array<Action,4> responses{};
    std::array<int,4> draws{};
    RoundPhase phase = RoundPhase::Turn;
    int actor = 0, source = -1, offered = -1, last_draw = -1, response_offset = 1;
    unsigned response_done = 0;
    unsigned winners = 0;
    bool replacement = false, allow_kong = true, robbery = false;
    int draw_actor = 0;
    bool draw_replacement = false;
    std::uint64_t actions = 0;
    // Only public events and the observer's private draw enter the information-set key.
    std::string events;
    int observer = -1;
};
TableState deal_round(std::uint32_t seed, int dealer = 0);
Observation observe(const TableState& state, int player);
std::vector<Action> round_legal_actions(const Observation& o, Evaluator& evaluator);
Action public_policy(const Observation& o, Evaluator& evaluator, std::mt19937& rng, double random_rate = 0);
void round_act(TableState& state, const Action& action, Evaluator& evaluator);
bool round_draw(TableState& state, int observer = -1, int max_own_draws = 100);
bool same_action(const Action& a, const Action& b);
void validate_table(const TableState& state);

SearchResult upstream_search(const Observation& o, const SearchConfig& config);
bool upstream_prefer(const Candidate& a,const Candidate& b);
} // namespace alphamah
