#pragma once
#include <chrono>
#include <cstdint>
namespace alphamah {
struct ProfileMetric { std::uint64_t calls=0, ns=0; };
inline thread_local ProfileMetric profile_metrics[5];
struct ProfileScope {
#ifdef ALPHAMAH_PROFILE
    int slot;
    std::chrono::steady_clock::time_point start;
    explicit ProfileScope(int index):slot(index),start(std::chrono::steady_clock::now()) {}
    ~ProfileScope() { ++profile_metrics[slot].calls; profile_metrics[slot].ns+=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count(); }
#else
    explicit ProfileScope(int) {}
#endif
};
}
