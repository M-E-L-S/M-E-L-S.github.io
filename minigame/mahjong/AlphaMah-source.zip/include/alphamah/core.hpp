#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

namespace alphamah {

constexpr int tile_types = 34;
using Counts = std::array<std::uint8_t, tile_types>;
using Payments = std::array<int, 4>; // Positive is received, negative is paid.

Counts parse_tiles(const std::string& notation);
std::string format_tiles(const Counts& tiles);
std::string tile_name(int tile);
int tile_count(const Counts& tiles);

enum class MeldKind { Sequence, Triplet, OpenKong, ConcealedKong, AddedKong };
struct Meld {
    MeldKind kind = MeldKind::Sequence;
    int tile = 0; // Lowest tile for sequences.
    int source_player = -1; // Original pon source for an added kong.
};
struct Hand {
    Counts concealed{};
    std::vector<Meld> melds;
};
struct Rules {
    // Unconfirmed local convention: default to seven DISTINCT pairs.
    bool quad_counts_as_two_pairs = false;
};

Counts physical_tiles(const Hand& hand);
void validate_hand(const Hand& hand, bool after_draw);

struct Distance {
    int standard = 8;
    int seven_pairs = 13;
    int thirteen_orphans = 13;
    int best() const;
};
struct Patterns {
    bool standard = false;
    bool seven_pairs = false;
    bool thirteen_orphans = false;
    bool pure_straight = false;
    bool winning() const;
};

// Internal packed key, local to a rules-specific evaluator; never a game-state TT.
struct HandKey {
    std::uint64_t low = 0;
    std::uint64_t high = 0;
    std::uint64_t physical_low = 0;
    std::uint64_t physical_high = 0;
    bool operator==(const HandKey& other) const;
};
struct HandKeyHash { std::size_t operator()(const HandKey& key) const; };

class Evaluator {
public:
    explicit Evaluator(Rules rules = {});
    Distance distance(const Hand& hand);
    Patterns patterns(const Hand& hand);
    std::uint64_t improving_mask(const Hand& hand);
private:
    Rules rules_;
    std::unordered_map<HandKey, Distance, HandKeyHash> cache_;
    std::unordered_map<HandKey, std::uint64_t, HandKeyHash> improving_cache_;
};

struct WinContext { bool replacement_draw = false; };
int payment_per_loser(const Patterns& patterns, WinContext context = {});
Payments settle_win(int winner, int discarder, const Patterns& patterns,
                    WinContext context = {}); // discarder == -1: self draw.
Payments settle_kong(int player, const Meld& kong);
void apply_payments(Payments& balances, const Payments& payments);

struct PublicOpponent {
    int player = -1;
    std::vector<Meld> melds; // Visible melds only; concealed-kong identities stay hidden.
    int concealed_kongs = 0;
    std::vector<int> discards;
};
struct PublicDiscard { int tile = -1; bool claimed = false; };
struct Observation {
    Hand hand;
    // Known tiles OUTSIDE the player's entire hand: discards and opponents' melds.
    Counts known_outside{};
    WinContext current_draw{};
    int player = 0;
    int offered_tile = -1;
    int source_player = -1;
    int remaining_wall = -1;
    bool allow_self_kong = true;
    std::vector<PublicOpponent> opponents;
    bool has_public_table = false;
    bool robbing_kong = false;
    std::array<std::vector<PublicDiscard>,4> rivers;
};
Counts unseen_tiles(const Observation& observation);
Observation parse_observation(const std::string& hand, const std::string& melds,
                              const std::string& known, const std::string& context = "",
                              const std::string& opponents = "", bool replacement = false,
                              const std::string& rivers = "");

struct OpponentRisk {
    int player = -1;
    double tenpai_probability = 0;
    std::uint32_t accepted_samples = 0;
    bool exact_singleton = false;
    bool fallback = false;
    std::array<double, 34> win_probability{}; // Unconditional: includes the tenpai prior.
    std::array<double, 34> expected_payment{}; // One payer, not three.
};
struct RiskModel {
    std::vector<OpponentRisk> opponents;
    std::array<double, 34> deal_in_probability{};
    std::array<double, 34> expected_loss{}; // Sum for multi-ron.
    bool active() const { return !opponents.empty(); }
};

struct Efficiency {
    Distance distance;
    int improving_copies = 0;
    std::vector<int> improving_tiles;
    int winning_value = 0;
};
Efficiency efficiency(Evaluator& evaluator, const Hand& after_discard, const Counts& unseen);

struct SearchConfig {
    bool upstream_pd = true; // Production default: the vendored author's search.
    std::uint32_t time_limit_ms = 0; // Zero preserves deterministic iteration mode.
    unsigned threads = 1; // Independent root trees; native or WASM pthreads.
    std::uint32_t samples_per_discard = 128;
    int max_draws = 18;
    std::uint32_t seed = 1;
    Rules rules{};
    std::uint32_t iterations = 0;
    bool importance_sampling = false;
    bool merge_solitary = false;
    bool multidepth_sharing = false;
    std::uint32_t risk_samples = 128; // Ignored legacy wire argument; Python/C ABI compatibility.

};
enum class ActionKind { Discard, Pass, Chi, Pon, Kong, ConcealedKong, AddedKong, Win };
struct Action {
    ActionKind kind = ActionKind::Pass;
    int tile = -1;
    int sequence_start = -1;
    int meld_index = -1;
};
const char* action_name(ActionKind kind);
std::vector<Action> legal_actions(const Observation& observation);
struct Candidate {
    int upstream_order = -1;
    int followup_discard = -1; // Author's separate chi/pon + discard root candidate.
    Action action;
    int discard = -1;
    Efficiency efficiency;
    std::uint32_t samples = 0;
    double wins = 0; // Survival-weighted win mass when the risk model is active.
    double win_probability = 0;
    double expected_gain = 0; // Net expected score: wins + kongs - modeled losses.
    double expected_loss = 0;
    double deal_in_probability = 0;
    double immediate_expected_loss = 0;
    double continuation_value = 0; // Heuristic own-hand value beyond the simulation horizon.
    double search_value = 0; // expected_gain + continuation_value.
    double mean_winning_draw = 0;
};
struct SearchResult {
    bool upstream_pd = false;
    double elapsed_ms = 0;
    unsigned workers = 1;
    bool win_now = false;
    int gain_now = 0;
    int recommended_discard = -1;
    Action recommended_action;
    std::uint32_t iterations = 0;
    std::uint32_t tree_nodes = 0;
    std::uint32_t branching_decision_nodes = 0;
    int max_decision_depth = 0;
    std::vector<Candidate> candidates;
    RiskModel risk;
    bool dynamic = false;
    bool includes_losses = true;
    std::uint32_t world_samples = 0;
    std::uint64_t simulated_actions = 0;
    double belief_acceptance = 0;
    double risk_standard_error = 0;
    double importance_ess = 0;
    std::uint64_t transposition_hits = 0;
    std::uint64_t importance_draws = 0, solitary_deferrals = 0, short_horizon_captures = 0;
    bool paper = false, paper_root_risk = false;
    std::uint64_t paper_rollouts = 0, paper_cycle_skips = 0, paper_horizon_updates = 0;
    std::uint64_t paper_chance_groups = 0, paper_solitary_groups = 0;
};
SearchResult search(const Observation& observation, const SearchConfig& config = {});
std::string result_json(const SearchResult& result);

} // namespace alphamah
