#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif
// Initial closed-hand adapter. All richer hand/meld state is in the C++ API.
// Returns 0 on success, required buffer bytes (including NUL) if too small,
// or -1 for invalid arguments. Error text is JSON when the buffer fits.
// No partial output is written on a size query. out may be null if capacity=0.
int alphamah_search(const char* hand, const char* known_outside,
                    uint32_t samples_per_discard, int max_draws, uint32_t seed,
                    char* out, int capacity);
// Rich public-information adapter; same buffer contract as alphamah_search.
// Melds: kind:tile:source separated by |. Context: player:source:offered:wall:allow_kong.
// Opponents: player~hidden_kong_count~visible_melds~discard_notation separated by /.
// Empty fields use "-". Never pass opponent concealed tiles or concealed-kong identities.
int alphamah_search_public(const char* hand, const char* melds, const char* known_outside,
                           const char* context, const char* opponents, int replacement,
                           uint32_t samples, int draws, uint32_t seed, uint32_t risk_samples,
                           char* out, int capacity);
// Full information-set search. Rivers: seat~tile:claimed,tile:claimed / ... (all four seats).
int alphamah_search_table(const char* hand, const char* melds, const char* known_outside,
                          const char* context, const char* opponents, const char* rivers, int replacement,
                          uint32_t samples, int draws, uint32_t seed, uint32_t risk_samples,
                          char* out, int capacity);
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C"
#endif
// Timed single-worker interface, including WASM. A zero-capacity query returns
// a recommended 131072-byte buffer without running a timed search.
int alphamah_search_timed(const char* hand,const char* melds,const char* known,
    const char* context,const char* opponents,const char* rivers,int replacement,
    uint32_t milliseconds,int draws,uint32_t seed,char* out,int capacity);

#ifdef __cplusplus
extern "C"
#endif
int alphamah_evaluate(const char* hand,const char* melds,const char* known,int replacement,char* out,int capacity);

#ifdef __cplusplus
extern "C"
#endif
// Exact waits use only the player's tiles and publicly visible tiles.
int alphamah_hints(const char* hand,const char* melds,const char* known,char* out,int capacity);
