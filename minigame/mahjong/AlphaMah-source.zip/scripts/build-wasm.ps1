param([string]$Sdk='D:/sdkdata/emsdk')
$ErrorActionPreference='Stop'
Set-Location -LiteralPath (Split-Path $PSScriptRoot -Parent)
$env:EM_CONFIG=Join-Path $Sdk '.emscripten'
$env:EM_CACHE=Join-Path $PWD 'build-wasm-cache'
$env:TMP=Join-Path $PWD 'build-wasm-tmp'; $env:TEMP=$env:TMP
New-Item -ItemType Directory -Force $env:TMP | Out-Null
$cmake='D:/Qt/Tools/CMake_64/bin/cmake.exe'
$ninja='D:/Qt/Tools/Ninja/ninja.exe'
if (-not (Test-Path $cmake)) { $cmake=(Get-Command cmake -ErrorAction Stop).Source }
if (-not (Test-Path $ninja)) { $ninja=(Get-Command ninja -ErrorAction Stop).Source }
foreach ($variant in @(@{Build='build-wasm';Output='mt';Threads='ON'},@{Build='build-wasm-single';Output='st';Threads='OFF'})) {
    & $cmake -S . -B $variant.Build -G Ninja '-DCMAKE_BUILD_TYPE=Release' "-DCMAKE_MAKE_PROGRAM=$ninja" "-DCMAKE_TOOLCHAIN_FILE=$Sdk/upstream/emscripten/cmake/Modules/Platform/Emscripten.cmake" '-DALPHAMAH_BUILD_TESTS=OFF' "-DALPHAMAH_WASM_THREADS=$($variant.Threads)"
    if ($LASTEXITCODE) { throw 'WASM configure failed' }
    & $cmake --build $variant.Build -j 12
    if ($LASTEXITCODE) { throw 'WASM build failed' }
    $output=Join-Path 'web/engine' $variant.Output
    New-Item -ItemType Directory -Force $output | Out-Null
    Copy-Item -LiteralPath "$($variant.Build)/alphamah.js","$($variant.Build)/alphamah.wasm" -Destination $output
}
& ./.venv/Scripts/python.exe scripts/package_wasm.py
if ($LASTEXITCODE) { throw 'Packaging failed' }
