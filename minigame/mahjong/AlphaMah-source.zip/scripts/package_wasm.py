"""Package the static release, source and LGPL notices without build caches."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

root=Path(__file__).resolve().parents[1]
release=root/'release';release.mkdir(exist_ok=True)
source=release/'AlphaMah-source.zip'
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
    for folder in ['src','include','vendor','gui','lab','tests','scripts','docs','web']:
        for f in sorted((root/folder).rglob('*')):
            if f.is_file() and '__pycache__' not in f.parts and 'engine' not in f.relative_to(root).parts and f.suffix != '.zip' and f.name != 'SHA256SUMS.json':
                z.write(f,f.relative_to(root))
    for name in ['CMakeLists.txt','README.md','start-desktop.ps1','start-wasm.ps1']:
        z.write(root/name,name)
shutil.copyfile(root/'vendor/meowcats/LICENSE',root/'web/LICENSE-MeowCaTS.txt')
shutil.copyfile(source,root/'web/AlphaMah-source.zip')
files={str(f.relative_to(root/'web')).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((root/'web').rglob('*')) if f.is_file() and f.name!='SHA256SUMS.json'}
(root/'web/SHA256SUMS.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8')
archive=release/'AlphaMah-WASM.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in sorted((root/'web').rglob('*')):
        if f.is_file():z.write(f,f.relative_to(root/'web'))
    z.write(root/'scripts/serve_wasm.py','serve.py')
    z.writestr('start.cmd','@echo off\r\ncd /d "%~dp0"\r\npython serve.py --directory . --open\r\npause\r\n')
print(f'{archive} ({archive.stat().st_size:,} bytes)')
print('SHA256 '+hashlib.sha256(archive.read_bytes()).hexdigest())
