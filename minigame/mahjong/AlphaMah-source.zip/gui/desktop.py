"""Native Tk desktop client. Calls the native C++ process directly; no HTTP."""
from concurrent.futures import ThreadPoolExecutor
import argparse
from copy import deepcopy
import queue
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from server import Engine, Game, label, notation, parse_tiles, ROOT
from settings import SearchSettings, PRESETS, THREAD_CHOICES
from recorder import Recorder, SEATS

ACTIONS={'摸牌':'draw','弃牌':'discard','吃':'chi','碰':'pon','明杠':'kan','暗杠':'ankan',
         '加杠':'kakan','自己过牌':'decline','无人要牌':'pass','确认加杠':'confirm_kakan','胡牌':'win','流局':'exhausted'}
ACTION_LABEL={v:k for k,v in ACTIONS.items()}
ACTION_LABEL.update({'pass':'过','win':'胡','discard':'打'})

def tile_text(t):
    return '未知' if t is None or t<0 else label(t)

def action_text(action):
    text=ACTION_LABEL.get(action['action'],action['action'])+' '+(action.get('tile') or '')
    if action['action']=='chi': text+=' 起点 '+notation([action['sequence_start']])
    return text.strip()

def meld_text(m, hidden=False):
    if m['kind']=='ankan' and hidden: return '暗杠（未知）'
    if m['kind']=='chi': return '吃 '+''.join(label(t) for t in range(m['tile'],m['tile']+3))
    return ACTION_LABEL.get(m['kind'],m['kind'])+' '+tile_text(m['tile'])

class Desktop:
    def __init__(self, root, journal=None):
        self.root=root; root.title('AlphaMah · 原生试牌室')
        root.geometry(f'{min(1280,root.winfo_screenwidth()-60)}x{min(900,root.winfo_screenheight()-90)}'); root.minsize(1000,720)
        self.settings=SearchSettings(); self.engine=Engine(settings=self.settings)
        self.game=Game(self.engine); self.recorder=Recorder.load(journal) if journal else Recorder('2466899m257p26s2z')
        self.game_pool=ThreadPoolExecutor(max_workers=1); self.advice_pool=ThreadPoolExecutor(max_workers=1)
        self.messages=queue.Queue(); self.busy=False; self.advice_busy=False; self.dirty=False
        self.generation=0; self.result=None; self.closed=False; self.play_controls=[]
        self._style(); self._build(); self._render_game(); self._render_record()
        if journal:
            self.tabs.select(1)
            self.dirty=self.recorder.needs_advice; self._request_advice()
        root.after(60,self._poll); root.protocol('WM_DELETE_WINDOW',self.close)

    def _style(self):
        self.root.configure(bg='#192733')
        style=ttk.Style(self.root); style.theme_use('clam')
        style.configure('.',font=('Microsoft YaHei UI',10),background='#192733',foreground='#e7edf2')
        style.configure('TFrame',background='#192733'); style.configure('TLabelframe',background='#192733')
        style.configure('TLabelframe.Label',foreground='#e7c780')
        style.configure('TButton',padding=(12,7),background='#304756',foreground='#ffffff')
        style.map('TButton',background=[('active','#456273')])
        style.configure('TCombobox',fieldbackground='#ffffff',foreground='#15222c',arrowsize=18)
        style.map('TCombobox',fieldbackground=[('readonly','#ffffff')],foreground=[('readonly','#15222c')])
        style.configure('TEntry',fieldbackground='#ffffff',foreground='#15222c',padding=6)
        style.configure('Treeview',background='#20343f',fieldbackground='#20343f',foreground='#e7edf2',rowheight=28)
        style.configure('Treeview.Heading',background='#304756',foreground='#e7c780')
        style.configure('TNotebook.Tab',padding=(24,10),background='#304756',foreground='#e7edf2')
        style.map('TNotebook.Tab',background=[('selected','#e7c780')],foreground=[('selected','#182b33')])

    def _button(self, parent, title, command, play=False, **pack):
        b=ttk.Button(parent,text=title,command=command); b.pack(**pack)
        if play: self.play_controls.append(b)
        return b

    def _build(self):
        bar=ttk.Frame(self.root,padding=14); bar.pack(fill='x')
        ttk.Label(bar,text='AlphaMah',font=('Microsoft YaHei UI',19,'bold')).pack(side='left',padx=(0,24))
        ttk.Label(bar,text='思考时间').pack(side='left')
        self.level=ttk.Combobox(bar,values=[p.title for p in PRESETS.values()],state='readonly',width=17)
        self.level.current(0); self.level.pack(side='left',padx=8)
        ttk.Label(bar,text='并行线程').pack(side='left')
        self.workers=ttk.Combobox(bar,values=[str(n) for n in THREAD_CHOICES],state='readonly',width=5)
        self.workers.set(str(min(8, THREAD_CHOICES[-1])))
        self.settings.update(16,int(self.workers.get())); self.workers.pack(side='left',padx=8)
        self.level.bind('<<ComboboxSelected>>',self._settings_changed); self.workers.bind('<<ComboboxSelected>>',self._settings_changed)
        self.setting_status=ttk.Label(bar,text='随时切换，下一次决策生效'); self.setting_status.pack(side='left',padx=12)
        components=ttk.Frame(self.root,padding=(14,0,14,8)); components.pack(fill='x')
        self.components=[]
        for title in ('MST · 孤张合并','IS · 重要性采样','MDTT · 多深度共享'):
            var=tk.BooleanVar(value=False); self.components.append(var)
            ttk.Checkbutton(components,text=title,variable=var,command=self._settings_changed).pack(side='left',padx=(0,18))
        tabs=ttk.Notebook(self.root); self.tabs=tabs; tabs.pack(fill='both',expand=True,padx=14,pady=(0,14))
        play=ttk.Frame(tabs,padding=12); record=ttk.Frame(tabs,padding=12)
        tabs.add(play,text='人机对局'); tabs.add(record,text='持续牌局分析')
        self._build_play(play); self._build_record(record)

    def _settings_changed(self, _event=None):
        level=list(PRESETS)[self.level.current()]; workers=int(self.workers.get())
        self.settings.update(level,workers,sum((1<<i) for i,v in enumerate(self.components) if v.get()))
        self.setting_status.configure(text=f'{PRESETS[level].title} / {workers} 线程 · 下一次决策生效')

    def _build_play(self, parent):
        controls=ttk.Frame(parent); controls.pack(fill='x',pady=(0,12))
        ttk.Label(controls,text='牌山种子').pack(side='left'); self.seed=ttk.Entry(controls,width=14)
        self.seed.insert(0,str(self.game.seed)); self.seed.pack(side='left',padx=8)
        self._button(controls,'新一局',self._new_game,True,side='left')
        self.auto=tk.BooleanVar(value=True)
        ttk.Checkbutton(controls,text='自动继续 AI 回合',variable=self.auto,command=self._schedule_game).pack(side='left',padx=16)
        self._button(controls,'分析当前手牌',lambda:self._game_action({'kind':'hint'}),True,side='right')
        self.game_status=ttk.Label(parent,font=('Microsoft YaHei UI',12,'bold')); self.game_status.pack(anchor='w',pady=8)
        self.game_table=ttk.Treeview(parent,columns=('seat','hand','meld','river','score'),show='headings',height=6)
        for key,title,width in [('seat','玩家',100),('hand','暗手张数',90),('meld','副露',260),('river','牌河',560),('score','累计分',80)]:
            self.game_table.heading(key,text=title); self.game_table.column(key,width=width,minwidth=60)
        self.game_table.pack(fill='x',pady=8)
        self.game_hand=ttk.LabelFrame(parent,text='你的手牌 · 点击出牌',padding=12); self.game_hand.pack(fill='x',pady=8)
        self.game_options=ttk.Frame(parent); self.game_options.pack(fill='x',pady=8)
        lower=ttk.Panedwindow(parent,orient='horizontal'); lower.pack(fill='both',expand=True)
        logframe=ttk.LabelFrame(lower,text='牌局记录',padding=8); advice=ttk.LabelFrame(lower,text='手牌分析',padding=8)
        lower.add(logframe,weight=1); lower.add(advice,weight=2)
        self.game_log=tk.Text(logframe,height=12,bg='#20343f',fg='#e7edf2',font=('Microsoft YaHei UI',10),wrap='word')
        self.game_log.pack(fill='both',expand=True)
        self.game_advice_title=ttk.Label(advice,text='轮到自己时可请求分析'); self.game_advice_title.pack(anchor='w')
        self.game_advice=self._advice_tree(advice)

    def _build_record(self, parent):
        controls=ttk.Frame(parent); controls.pack(fill='x')
        ttk.Label(controls,text='起始暗手（13 张；自己已摸牌可填 14 张）').pack(side='left')
        self.initial_hand=ttk.Entry(controls,width=28); self.initial_hand.insert(0,self.recorder.initial['hand']); self.initial_hand.pack(side='left',padx=8)
        self.first_actor=ttk.Combobox(controls,values=SEATS,state='readonly',width=6); self.first_actor.current(self.recorder.initial['actor']); self.first_actor.pack(side='left')
        self._button(controls,'新建记录',self._new_record,side='left',padx=8)
        self._button(controls,'恢复记录',self._load_record,side='right',padx=4)
        self._button(controls,'保存记录',self._save_record,side='right',padx=4)
        self.record_status=ttk.Label(parent,font=('Microsoft YaHei UI',12,'bold')); self.record_status.pack(anchor='w',pady=(14,8))
        self.record_table=ttk.Treeview(parent,columns=('seat','hand','meld','river'),show='headings',height=5)
        for key,title,width in [('seat','玩家',80),('hand','暗手张数',90),('meld','公开副露',280),('river','完整牌河（✓ 已叫走）',630)]:
            self.record_table.heading(key,text=title); self.record_table.column(key,width=width,minwidth=60)
        self.record_table.pack(fill='x')
        self.record_hand=ttk.LabelFrame(parent,text='自己的暗手 · 点击填入本次牌',padding=8); self.record_hand.pack(fill='x',pady=8)
        events=ttk.Frame(parent); events.pack(fill='x',pady=8)
        self.event_player=ttk.Combobox(events,values=SEATS,state='readonly',width=7); self.event_player.current(0); self.event_player.pack(side='left')
        self.event_kind=ttk.Combobox(events,values=list(ACTIONS),state='readonly',width=12); self.event_kind.set('摸牌'); self.event_kind.pack(side='left',padx=8)
        self.event_kind.bind('<<ComboboxSelected>>',self._event_kind_changed)
        ttk.Label(events,text='本次牌 / 吃牌起点').pack(side='left')
        self.event_tile=ttk.Entry(events,width=8); self.event_tile.pack(side='left',padx=8)
        self._button(events,'记录动作',self._record_event,side='left')
        self._button(events,'撤销上一步',self._undo,side='left',padx=8)
        self._button(events,'重新分析',lambda:self._request_advice(force=True),side='right')
        palette=ttk.Frame(parent); palette.pack(fill='x')
        for t in range(34):
            tk.Button(palette,text=label(t),width=3,bg='#efe6cf',fg='#973f35' if t<9 or t>=27 else '#24566c',
                      command=lambda t=t:self._set_tile(t)).grid(row=t//17,column=t%17,padx=2,pady=2)
        ttk.Label(parent,text='他家暗摸／暗杠留空。响应中记录下一家摸牌，表示无人叫牌；叫牌应先记录。建议不会替你执行动作。').pack(anchor='w',pady=8)
        lower=ttk.Panedwindow(parent,orient='horizontal'); lower.pack(fill='both',expand=True)
        history=ttk.LabelFrame(lower,text='连续事件记录',padding=8); advice=ttk.LabelFrame(lower,text='自己的自动建议',padding=8)
        lower.add(history,weight=1); lower.add(advice,weight=2)
        self.record_log=tk.Text(history,height=8,bg='#20343f',fg='#e7edf2',font=('Microsoft YaHei UI',10),wrap='word'); self.record_log.pack(fill='both',expand=True)
        self.record_advice_title=ttk.Label(advice,text='等待自己的决策回合',wraplength=650); self.record_advice_title.pack(anchor='w')
        self._button(advice,'将建议填入动作栏（不执行）',self._fill_suggestion,side='bottom',anchor='w',pady=6)
        self.record_advice=self._advice_tree(advice)

    def _advice_tree(self, parent):
        tree=ttk.Treeview(parent,columns=('action','distance','copies','gain','visits'),show='headings',height=7)
        for key,title,width in [('action','动作',120),('distance','向听',55),('copies','剩余进张',80),('gain','乐观和牌率',130),('visits','访问',70)]:
            tree.heading(key,text=title); tree.column(key,width=width,minwidth=45)
        tree.pack(fill='both',expand=True,pady=8); return tree

    def _show_advice(self, result, title, tree):
        action=action_text(result)
        title.configure(text=f'建议：{action}　{result.get("elapsed_ms",0):.0f} ms / {result.get("workers",1)} 线程 / {result["iterations"]} 次迭代')
        tree.delete(*tree.get_children())
        for c in result['candidates']:
            a=action_text(c)
            estimate=f'{c["win_probability"]:.1%}' if c['samples'] else '—'
            tree.insert('', 'end',values=(a,c['shanten'],c['ukeire'],estimate,c['samples']))

    def _set_tile(self, tile):
        self.event_tile.delete(0,'end'); self.event_tile.insert(0,notation([tile]))

    def _event_kind_changed(self, _event=None):
        if self.event_kind.get()=='自己过牌':
            self.event_player.current(0); self.event_tile.delete(0,'end')

    def _render_game(self):
        g=self.game; self.game_table.delete(*self.game_table.get_children())
        for p in range(4):
            melds=' · '.join(meld_text(m,p!=0) for m in g.melds[p])
            river=' '.join(label(r['tile'])+('✓' if r['claimed'] else '') for r in g.rivers[p])
            self.game_table.insert('','end',values=(SEATS[p],len(g.hands[p]),melds,river,g.scores[p]))
        phase='本局结束' if g.phase=='over' else '等待你的响应' if g.phase=='response' else SEATS[g.turn]+'出牌'
        self.game_status.configure(text=f'第 {g.round} 局　剩余 {len(g.wall)} 张　{phase}'+(' · C++ 搜索中，设置仍可切换' if self.busy else ''))
        for child in self.game_hand.winfo_children(): child.destroy()
        for t in sorted(g.hands[0]):
            b=tk.Button(self.game_hand,text=label(t),font=('Microsoft YaHei UI',17,'bold'),bg='#f1ead7',fg='#283b42',padx=7,pady=8,
                        command=lambda t=t:self._game_action({'kind':'discard','tile':t}))
            b.pack(side='left',padx=3); b.configure(state='normal' if not self.busy and g.phase=='turn' and g.turn==0 else 'disabled')
        for child in self.game_options.winfo_children(): child.destroy()
        for option in g.options():
            data={k:v for k,v in option.items() if k!='label'}
            b=ttk.Button(self.game_options,text=option['label'],command=lambda d=data:self._game_action(d)); b.pack(side='left',padx=4)
            if self.busy: b.state(['disabled'])
        for b in self.play_controls: b.state(['disabled'] if self.busy else ['!disabled'])
        self.game_log.configure(state='normal'); self.game_log.delete('1.0','end'); self.game_log.insert('end','\n'.join(g.log)); self.game_log.see('end'); self.game_log.configure(state='disabled')
        if g.hint: self._show_advice(g.hint,self.game_advice_title,self.game_advice)

    def _game_action(self, action):
        if self.busy: return
        self.busy=True; self._render_game()
        future=self.game_pool.submit(self.game.action,action)
        future.add_done_callback(lambda f:self.messages.put(('game',f)))

    def _new_game(self):
        if self.busy: return
        try:
            seed=int(self.seed.get())
            if not 0<=seed<=0xffffffff: raise ValueError('种子范围为 0–4294967295')
            self.game.new(seed,self.settings.snapshot()[0]); self.game_advice.delete(*self.game_advice.get_children())
            self.game_advice_title.configure(text='轮到自己时可请求分析'); self._render_game(); self._schedule_game()
        except Exception as e: messagebox.showerror('无法开局',str(e),parent=self.root)

    def _schedule_game(self):
        if not self.closed and not self.busy and self.auto.get() and self.game.phase=='turn' and self.game.turn!=0:
            self.root.after(180,self._auto_step)

    def _auto_step(self):
        if self.auto.get() and not self.busy and self.game.phase=='turn' and self.game.turn!=0: self._game_action({'kind':'step'})

    def _new_record(self):
        try:
            other=Recorder(self.initial_hand.get(),self.first_actor.current())
            self.recorder=other; self._record_changed()
        except Exception as e: messagebox.showerror('无法新建记录',str(e),parent=self.root)

    def _record_event(self):
        try:
            kind=ACTIONS[self.event_kind.get()]; tiles=parse_tiles(self.event_tile.get())
            if len(tiles)>1: raise ValueError('本次牌只填一张；吃牌填顺子起点')
            tile=tiles[0] if tiles else -1
            if kind in ('decline','pass','confirm_kakan','win','exhausted'): tile=-1
            player=0 if kind=='decline' else self.event_player.current()
            self.recorder.record({'kind':kind,'player':player,'tile':tile})
            self.event_tile.delete(0,'end'); self._record_changed()
        except Exception as e: messagebox.showerror('没有录入动作',str(e),parent=self.root)

    def _record_changed(self):
        self.generation+=1; self.result=None; self.dirty=self.recorder.needs_advice
        self.record_advice.delete(*self.record_advice.get_children()); self._render_record(); self._request_advice()

    def _render_record(self):
        r=self.recorder; self.record_table.delete(*self.record_table.get_children())
        for p in range(4):
            self.record_table.insert('','end',values=(SEATS[p],r.counts[p],' · '.join(meld_text(m,p!=0) for m in r.melds[p]),
                ' '.join(label(x['tile'])+('✓' if x['claimed'] else '') for x in r.rivers[p])))
        status='已结束' if r.phase=='over' else ('抢加杠窗口' if r.robbery else SEATS[r.source]+'弃 '+label(r.offered)) if r.phase=='response' else SEATS[r.actor]+('待摸牌' if r.phase=='draw' else '出牌')
        if r.phase=='response' and 0 in r.passed: status+='（自己已过）'
        self.record_status.configure(text=f'剩余 {r.wall} 张　{status}　已记录 {len(r.events)} 个动作')
        for child in self.record_hand.winfo_children(): child.destroy()
        for t in sorted(r.hand):
            tk.Button(self.record_hand,text=label(t),bg='#f1ead7',fg='#283b42',font=('Microsoft YaHei UI',13),command=lambda t=t:self._set_tile(t)).pack(side='left',padx=2)
        if r.phase=='response':
            self.event_player.current(r.source if r.robbery else (r.source+1)%4)
            self.event_kind.set('确认加杠' if r.robbery else '摸牌')
        else:
            self.event_player.current(r.actor); self.event_kind.set('摸牌' if r.phase=='draw' else '弃牌')
        self.record_advice_title.configure(text='正在分析当前局面…' if r.needs_advice else '等待自己摸牌或响应；可继续记录他家动作')
        lines=[]
        for n,e in enumerate(r.events,1): lines.append(f'{n}. {SEATS[e["player"]]} {next((k for k,v in ACTIONS.items() if v==e["kind"]),e["kind"])} '+(tile_text(e['tile']) if e.get('tile',-1)>=0 else ''))
        self.record_log.configure(state='normal'); self.record_log.delete('1.0','end'); self.record_log.insert('end','\n'.join(lines)); self.record_log.see('end'); self.record_log.configure(state='disabled')

    def _request_advice(self, force=False):
        if not self.recorder.needs_advice:
            self.record_advice_title.configure(text='当前没有自己的决策；先记录后续动作'); return
        if force:
            self.generation+=1; self.dirty=True; self.result=None
            self.record_advice.delete(*self.record_advice.get_children())
        if self.advice_busy:
            if self.dirty: self.record_advice_title.configure(text='局面已更新；上一搜索结束后自动分析，旧建议不会显示')
            return
        if not self.dirty: return
        self.advice_busy=True; self.dirty=False; generation=self.generation
        level,workers=self.settings.snapshot()
        self.record_advice_title.configure(text=f'正在分析当前局面 · {PRESETS[level].title} / {workers} 线程')
        observation=self.recorder.observation()
        future=self.advice_pool.submit(self.engine.run,**observation)
        future.add_done_callback(lambda f,g=generation:self.messages.put(('advice',g,f)))

    def _fill_suggestion(self):
        if not self.result: return
        a=self.result['action']; mapping={'pass':'自己过牌','discard':'弃牌','win':'胡牌'}
        self.event_kind.set(mapping.get(a,next((k for k,v in ACTIONS.items() if v==a),'弃牌')))
        self.event_player.current(0); self.event_tile.delete(0,'end')
        if a=='chi': self._set_tile(self.result['sequence_start'])
        elif self.result.get('tile'): self.event_tile.insert(0,self.result['tile'])

    def _undo(self):
        try: self.recorder.undo(); self._record_changed()
        except Exception as e: messagebox.showerror('无法撤销',str(e),parent=self.root)

    def _save_record(self):
        path=filedialog.asksaveasfilename(parent=self.root,title='保存连续牌局',defaultextension='.json',filetypes=[('牌局记录','*.json')],initialdir=str(ROOT))
        if path:
            try: self.recorder.save(path)
            except Exception as e: messagebox.showerror('保存失败',str(e),parent=self.root)

    def _load_record(self):
        path=filedialog.askopenfilename(parent=self.root,title='恢复连续牌局',filetypes=[('牌局记录','*.json')],initialdir=str(ROOT))
        if path:
            try:
                other=Recorder.load(path); self.recorder=other
                self.initial_hand.delete(0,'end'); self.initial_hand.insert(0,other.initial['hand']); self.first_actor.current(other.initial['actor'])
                self._record_changed()
            except Exception as e: messagebox.showerror('恢复失败',str(e),parent=self.root)

    def _poll(self):
        if self.closed: return
        try:
            while True:
                item=self.messages.get_nowait()
                if item[0]=='game':
                    self.busy=False
                    try: item[1].result()
                    except Exception as e:
                        self.auto.set(False); messagebox.showerror('引擎操作失败',str(e),parent=self.root)
                    self._render_game(); self._schedule_game()
                else:
                    _,generation,future=item; self.advice_busy=False
                    try:
                        result=future.result()
                        if generation==self.generation:
                            self.result=result; self._show_advice(result,self.record_advice_title,self.record_advice)
                    except Exception as e:
                        if generation==self.generation: self.record_advice_title.configure(text='分析失败：'+str(e))
                    self._request_advice()
        except queue.Empty: pass
        self.root.after(60,self._poll)

    def close(self):
        self.closed=True; self.game_pool.shutdown(wait=False,cancel_futures=True); self.advice_pool.shutdown(wait=False,cancel_futures=True); self.root.destroy()

if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--journal'); args=parser.parse_args()
    root=tk.Tk()
    try: app=Desktop(root,args.journal)
    except Exception as e: messagebox.showerror('启动失败',str(e),parent=root); root.destroy(); raise
    root.mainloop()
