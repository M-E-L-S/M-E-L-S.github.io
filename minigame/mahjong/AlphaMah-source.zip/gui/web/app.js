const $ = id => document.getElementById(id);
let state, token, selected = null, busy = false, halted = false, stepTimer, lastResultRound = 0;
const names = ['你', '下家 AI', '对家 AI', '上家 AI'];
const escape = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function tileName(t) { return t < 27 ? `${t % 9 + 1}${['万','筒','索'][Math.floor(t / 9)]}` : '东南西北白发中'[t - 27]; }
function tileHtml(t, {small=false, button=false, extra='', index=null}={}) {
  const suit = t < 27 ? 'mps'[Math.floor(t / 9)] : 'z';
  const color = t === 32 ? ' green' : t === 33 ? ' red' : '';
  return `<${button ? 'button type="button"' : 'span'} class="tile ${suit}${color}${small ? ' small' : ''} ${extra}" ${button ? `data-tile="${t}" data-index="${index}"` : ''} aria-label="${tileName(t)}"><span class="rank">${t < 27 ? t % 9 + 1 : tileName(t)}</span>${t < 27 ? `<span class="suit">${['萬','筒','索'][Math.floor(t / 9)]}</span>` : ''}</${button ? 'button' : 'span'}>`;
}
function meldHtml(meld) {
  const labels = {chi:'吃',pon:'碰',kan:'明杠',ankan:'暗杠',kakan:'加杠'};
  let tiles = meld.kind === 'chi' ? [meld.tile,meld.tile+1,meld.tile+2] : Array(meld.kind === 'pon' ? 3 : 4).fill(meld.tile);
  return `<div class="meld-group">${tiles.map(t => t === null ? '<span class="back"></span>' : tileHtml(t,{small:true})).join('')}<span class="meld-label">${labels[meld.kind]}</span></div>`;
}
function render() {
  if (!state) return;
  $('connection').textContent = 'C++ 内核已连接';
  $('round').textContent = `第 ${state.round} 局 · 种子 ${state.seed}`;
  $('wall').textContent = state.wall;
  for (let p = 1; p < 4; ++p) {
    const player = state.players[p];
    $('seat-'+p).classList.toggle('active', state.turn === p && state.phase === 'turn');
    $('seat-'+p).innerHTML = `<div class="seat-title"><span class="seat-name">${player.name}</span>${state.dealer === p ? '<span class="dealer">庄</span>' : ''}<strong>${state.scores[p] > 0 ? '+' : ''}${state.scores[p]}</strong></div><div class="backs">${Array(player.count).fill('<span class="back"></span>').join('')}</div><div class="count">${player.count} 张手牌</div><div class="melds">${player.melds.map(meldHtml).join('')}</div>`;
  }
  for (let p = 0; p < 4; ++p) {
    const river = state.players[p].river;
    $('river-'+p).innerHTML = river.map((r,i) => tileHtml(r.tile,{small:true,extra:(r.claimed?'claimed ':'') + (state.pending?.source === p && i === river.length-1 ? 'last-discard' : '')})).join('');
  }
  $('human-score').textContent = `${state.scores[0] > 0 ? '+' : ''}${state.scores[0]}`;
  $('human-dealer').hidden = state.dealer !== 0;
  $('own-melds').innerHTML = state.players[0].melds.map(meldHtml).join('');
  const canDiscard = !busy && state.phase === 'turn' && state.turn === 0;
  if (!canDiscard) selected = null;
  let drawnIndex = state.players[0].hand.lastIndexOf(state.last_draw);
  $('hand').innerHTML = state.players[0].hand.map((t,i) => tileHtml(t,{button:true,index:i,extra:(selected === i?'selected ':'')+(i===drawnIndex?'drawn':'')})).join('');
  for (const button of $('hand').querySelectorAll('button')) {
    button.disabled = !canDiscard;
    button.onclick = () => {
      selected = Number(button.dataset.index);
      $('hand').querySelectorAll('button').forEach(b=>b.classList.toggle('selected',Number(b.dataset.index)===selected));
      $('discard').disabled = false;
    };
    button.ondblclick = () => act({kind:'discard',tile:Number(button.dataset.tile)});
  }
  $('discard').hidden = state.phase === 'response' || state.phase === 'over';
  $('discard').disabled = !canDiscard || selected === null;
  $('hint').disabled = !canDiscard;
  $('responses').innerHTML = '';
  for (const option of state.options) {
    const button = document.createElement('button');
    button.textContent = option.label;
    button.className = ['win','ron','kan','ankan','kakan'].includes(option.kind) ? 'primary' : '';
    button.disabled = busy;
    button.onclick = () => act(option);
    $('responses').append(button);
  }
  const ownTurn = state.turn === 0 && state.phase === 'turn';
  let status, detail;
  if (state.phase === 'over') { status = state.result.type === 'draw' ? '本局流局' : '本局已结束'; detail = '可以查看结算，或开始下一局。'; }
  else if (state.phase === 'response') { status = `要${state.options.some(o=>o.kind==='ron')?'胡这张牌':'这张牌'}吗？`; detail = `${names[state.pending.source]}打出 ${tileName(state.pending.tile)}`; }
  else if (ownTurn) { status = state.metrics.winning ? '可以自摸' : '轮到你出牌'; detail = state.metrics.winning ? '选择自摸结算，或继续打牌。' : '选一张牌，继续这一手。'; }
  else { status = `${names[state.turn]}${busy?'思考中':'的回合'}`; detail = '蒙特卡洛搜索正在比较弃牌收益。'; }
  if (busy && ownTurn) { status = '正在计算'; detail = '正在展开搜索并评估动作。'; }
  $('status').textContent = status;
  $('status-detail').textContent = detail;
  $('turn-label').textContent = state.phase === 'over' ? '本局结束' : state.phase === 'response' ? '等待你的响应' : ownTurn ? '你的回合' : `${names[state.turn]}回合`;
  $('hand-help').textContent = state.phase === 'over' ? '本局已结束' : state.phase === 'response' ? '选择吃、碰、杠、胡或过' : ownTurn ? '单击选牌，双击出牌' : '等待 AI 出牌';
  const m = state.metrics;
  $('shanten').textContent = m.shanten === -1 ? '和' : m.shanten === 0 ? '听' : m.shanten;
  $('ukeire').textContent = ownTurn ? '—' : m.ukeire;
  $('waits').innerHTML = !ownTurn && m.shanten === 0 ? m.waits.map(t=>tileHtml(t,{small:true})).join('') : '';
  $('pending').innerHTML = state.pending ? `<span>${names[state.pending.source]}打出</span>${tileHtml(state.pending.tile,{small:true})}` : '';
  const log = $('log');
  log.innerHTML = state.log.map(line=>`<li>${escape(line)}</li>`).join('');
  log.scrollTop = log.scrollHeight;
  $('timing').textContent = state.elapsed === null ? '' : `AI ${state.elapsed} ms`;
  $('hint-panel').hidden = !state.hint;
  if (state.hint) {
    const actionLabels = {discard:'打',ankan:'暗杠',kakan:'加杠',kan:'明杠',pon:'碰',chi:'吃',pass:'过'};
    $('hint-content').innerHTML = state.hint.action === 'win' ? '<p>当前可以自摸。</p>' : state.hint.candidates.slice(0,3).map(c=> {
      const tile = c.tile;
      const t = tile ? 'mpsz'.indexOf(tile[1]) * 9 + Number(tile[0]) - 1 : null;
      const diagnosticCount = state.hint.opponents?.[0]?.accepted_samples || 0;
      const sampled = state.hint.model === 'information_set_mcts_v4';
      const danger = sampled ? `${Math.round(c.deal_in_probability*diagnosticCount)}/${diagnosticCount} 危险样本` : `${(100*c.deal_in_probability).toFixed(1)}%`;
      const risk = state.hint.risk_model === 'disabled' ? '' : `<br>${c.action === 'kakan' ? '抢杠' : '放铳'}估计 ${danger} · 模拟失分 ${c.expected_loss.toFixed(1)}`;
      return `<div class="hint-row">${t === null ? '' : tileHtml(t,{small:true})}<p>${actionLabels[c.action] || c.action} · ${c.shanten === 0 ? '听牌' : c.shanten+' 向听'} · ${c.ukeire} 张进张<br>模拟胡牌率 ${(100*c.win_probability).toFixed(1)}% · 评估 ${c.search_value.toFixed(1)} · 访问 ${c.samples}${risk}</p></div>`;
    }).join('') + `<p class="search-stats">${state.hint.model === 'information_set_mcts_v4' ? '信息集 MCTS' : 'MCTS'} · ${state.hint.iterations} 次模拟 · ${state.hint.tree_nodes} 节点 · 决策深度 ${state.hint.max_decision_depth}</p>`
      + (state.hint.opponents?.length ? `<p class="search-stats">听牌样本：${state.hint.opponents.map(p=>`${names[p.player]} ${Math.round(p.tenpai_probability*p.accepted_samples)}/${p.accepted_samples}`).join(' · ')}<br>评估含净收支与后续牌型价值。${state.hint.model === 'information_set_mcts_v4' ? '概率模型来自本地规则自对弈；未抽到危险不代表安全。' : '风险为未校准的启发式估计。'}</p>` : '');
  }
  if (state.phase === 'over' && lastResultRound !== state.round) {
    lastResultRound = state.round;
    showResult();
  }
  schedule();
}
function showResult() {
  const r = state.result;
  $('result-title').textContent = r.type === 'draw' ? '流局' : r.winners.map(w=>names[w.player]).join('、') + (r.source === -1 ? '自摸' : r.robbery ? '抢杠胡' : '胡牌');
  $('result-detail').innerHTML = r.type === 'draw' ? '<p>牌山已尽，已结算的杠分保留。</p>' : r.winners.map(w => {
    const payments = w.payments.filter(amount => amount > 0);
    const amount = payments[0];
    const summary = payments.length > 1 && payments.every(n => n === amount) ? `其余三家各付 ${amount}`
      : w.payments.flatMap((n, p) => n > 0 ? [`${names[p]}付 ${n}`] : []).join('、');
    return `<p>${names[w.player]} · ${w.patterns.join('＋')} · ${summary}</p>`;
  }).join('');
  $('result-scores').innerHTML = names.map((name,p)=>`<tr><td>${name}</td><td class="${r.delta[p]>=0?'positive':'negative'}">${r.delta[p]>0?'+':''}${r.delta[p]}</td><td>${state.scores[p]}</td></tr>`).join('');
  $('revealed-hands').innerHTML = state.players.map((p,i)=> {
    const winningTile = r.type === 'win' && r.source !== -1 && r.winners.some(w=>w.player===i)
      ? ` ${tileHtml(r.tile,{small:true,extra:'last-discard'})}` : '';
    return `<div class="reveal-row"><p>${names[i]}</p>${p.hand.map(t=>tileHtml(t,{small:true})).join('')}${winningTile}${p.melds.map(meldHtml).join('')}</div>`;
  }).join('');
  if (!$('result-dialog').open) $('result-dialog').showModal();
}
function schedule() {
  clearTimeout(stepTimer);
  if (!busy && !halted && state.phase === 'turn' && state.turn !== 0)
    stepTimer = setTimeout(()=>act({kind:'step'}), 420);
}
async function api(path, data) {
  const response = await fetch(path, data === undefined ? {} : {method:'POST',headers:{'Content-Type':'application/json','X-Playtest-Token':token},body:JSON.stringify(data)});
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || '请求失败');
  return result;
}
function error(message) {
  $('toast').textContent = message; $('toast').hidden = false;
  setTimeout(()=>$('toast').hidden=true,6500);
}
async function act(data) {
  if (busy) return;
  busy = true; render();
  try { state = await api('/api/action',data); selected = null; }
  catch (e) { error(e.message); halted = true; clearTimeout(stepTimer); }
  finally { busy = false; render(); }
}
$('discard').onclick = () => selected !== null && act({kind:'discard',tile:state.players[0].hand[selected]});
$('hint').onclick = () => act({kind:'hint'});
$('hint-close').onclick = () => { state.hint = null; render(); };
$('rules-open').onclick = () => $('rules-dialog').showModal();
$('new-open').onclick = () => { $('seed').value = (state?.seed ?? 20261105) + 1; $('new-dialog').showModal(); };
document.querySelectorAll('[data-close]').forEach(b => b.onclick = () => $(b.dataset.close).close());
$('random-seed').onclick = () => { const seed = new Uint32Array(1); crypto.getRandomValues(seed); $('seed').value = seed[0]; };
async function newGame(data) {
  if (busy) return;
  busy = true; clearTimeout(stepTimer);
  try { state = await api('/api/new',data); selected = null; halted = false; lastResultRound = 0; $('new-dialog').close(); $('result-dialog').close(); }
  catch(e) { error(e.message); }
  finally { busy = false; render(); }
}
$('new-form').onsubmit = e => { e.preventDefault(); newGame({seed:Number($('seed').value),reset:$('reset-scores').checked}); };
$('next-round').onclick = () => newGame({seed:(state.seed+1)>>>0});
let settingsQueue = Promise.resolve();
$('live-samples').onchange = () => {
  const level=Number($('live-samples').value);
  settingsQueue=settingsQueue.then(async()=>{const r=await api('/api/settings',{samples:level});state.samples=r.samples;}).catch(e=>error(e.message));
};
try { state = await api('/api/state'); $('live-samples').value=state.samples; token = state.token; render(); }
catch(e) { $('connection').textContent='连接失败'; $('status').textContent='内核未连接'; error(e.message); }
