const $=id=>document.getElementById(id);
const names={discard:'打',pass:'过',win:'胡',chi:'吃',pon:'碰',kan:'明杠',ankan:'暗杠',kakan:'加杠'};
let token;
const ready=fetch('/api/state').then(r=>r.json()).then(s=>token=s.token);
function action(c){return `${names[c.action]||c.action} ${c.tile||''}${c.action==='chi'?'（顺子起点 '+c.sequence_start+'）':''}`;}
$('analyze-form').onsubmit=async event=>{
 event.preventDefault();$('analyze-submit').disabled=true;$('analysis-status').textContent='思考中…';$('analysis-output').hidden=true;
 try {
  await ready;
  const body={hand:$('input-hand').value,samples:Number($('input-level').value),threads:Number($('input-threads').value),wall:$('input-wall').value,rivers:[0,1,2,3].map(i=>$('river'+i).value),source:Number($('input-source').value),offered:$('input-offered').value,melds:JSON.parse($('input-melds').value),opponents:JSON.parse($('input-opponents').value),replacement:$('input-replacement').checked,allow_kong:$('input-allow-kong').checked,robbery:$('input-robbery').checked,seed:Number($('input-seed').value)};
  const response=await fetch('/api/analyze',{method:'POST',headers:{'Content-Type':'application/json','X-Playtest-Token':token},body:JSON.stringify(body)});
  const result=await response.json();if(!response.ok)throw Error(result.error);
  $('analysis-recommendation').textContent='建议：'+action(result);
  $('analysis-stats').textContent=`${result.wall_elapsed_ms} ms · ${result.workers} 线程 · ${result.iterations} 次模拟 · ${result.tree_nodes} 节点 · 决策深度 ${result.max_decision_depth}`;
  const tbody=$('analysis-candidates');tbody.replaceChildren();
  for(const c of result.candidates){const tr=document.createElement('tr');for(const text of [action(c),c.shanten,c.ukeire,(c.win_probability*100).toFixed(1)+'%',c.expected_gain.toFixed(2),c.search_value.toFixed(2),c.samples]){const td=document.createElement('td');td.textContent=text;tr.append(td);}tbody.append(tr);}
  $('analysis-json').textContent=JSON.stringify(result,null,2);$('analysis-output').hidden=false;$('analysis-status').textContent='分析完成';
 }catch(error){$('analysis-status').textContent=error.message;}finally{$('analyze-submit').disabled=false;}
};
