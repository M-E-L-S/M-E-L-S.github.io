import tempfile
from pathlib import Path
import unittest
from copy import deepcopy
from recorder import Recorder
from server import Engine
from settings import SearchSettings
from unittest.mock import patch
from types import SimpleNamespace
from desktop import action_text

class RecorderTests(unittest.TestCase):
    def test_own_pass_does_not_close_other_players_response(self):
        r=Recorder('2466899m257p26s2z',1)
        r.record({'kind':'discard','player':1,'tile':33})
        r.record({'kind':'decline','player':0})
        self.assertEqual(r.phase,'response'); self.assertFalse(r.needs_advice)
        r.record({'kind':'pon','player':3})
        self.assertEqual(r.actor,3); self.assertEqual(r.phase,'turn')
        r.record({'kind':'discard','player':3,'tile':33})
        self.assertTrue(r.needs_advice)
    def test_pass_and_win_without_a_tile_display(self):
        self.assertEqual(action_text({'action':'pass','tile':None}),'过')
        self.assertEqual(action_text({'action':'win'}),'胡')
    def test_draw_discard_undo_and_persistence(self):
        r=Recorder('2466899m257p26s2z')
        r.record({'kind':'draw','player':0,'tile':29})
        self.assertTrue(r.needs_advice); self.assertEqual(r.wall,83)
        r.record({'kind':'discard','player':0,'tile':29})
        self.assertFalse(r.needs_advice)
        r.record({'kind':'draw','player':1})
        r.record({'kind':'discard','player':1,'tile':30})
        self.assertTrue(r.needs_advice)
        workspace=Path(__file__).resolve().parents[1]/'build'
        with tempfile.TemporaryDirectory(dir=workspace) as d:
            self.assertTrue(Path(d).resolve().is_relative_to(workspace.resolve()))
            path=Path(d)/'journal.json'; r.save(path); clone=Recorder.load(path)
            self.assertEqual(clone.__dict__,r.__dict__)
        r.undo(); self.assertEqual(r.phase,'turn'); self.assertEqual(r.actor,1)
        self.assertEqual(r.wall,82)

    def test_transaction_rejects_impossible_tiles(self):
        r=Recorder('1111m123p123s11z2z')
        before=deepcopy(r.__dict__)
        with self.assertRaises(ValueError): r.record({'kind':'draw','player':0,'tile':0})
        self.assertEqual(r.__dict__,before)
        with self.assertRaises(ValueError): r.record({'kind':'draw','player':2,'tile':2})

    def test_call_changes_turn_and_claims_exact_river(self):
        r=Recorder('123m123p123s55m12z',3)
        r.record({'kind':'discard','player':3,'tile':4}) # Implicit unknown draw.
        self.assertEqual(r.wall,83)
        self.assertTrue(r.needs_advice)
        r.record({'kind':'pon','player':0})
        self.assertTrue(r.rivers[3][-1]['claimed']); self.assertEqual(r.actor,0)
        self.assertEqual(len(r.hand),11); self.assertFalse(r.allow_kong)
        o=r.observation(); self.assertEqual(o['known'],[])
        result=Engine(timed=False).run(**o,draws=1,samples=2)
        self.assertTrue(result['candidates'])

    def test_hidden_kong_never_stores_tile_identity(self):
        r=Recorder('2466899m257p26s2z',1)
        r.record({'kind':'draw','player':1})
        with self.assertRaises(ValueError): r.record({'kind':'ankan','player':1,'tile':31})
        r.record({'kind':'ankan','player':1})
        self.assertIsNone(r.melds[1][0]['tile'])
        r.record({'kind':'draw','player':1})
        r.record({'kind':'discard','player':1,'tile':31})
        self.assertEqual(r.observation()['opponents'][0]['concealed_kongs'],1)
        self.assertEqual(r.observation()['opponents'][0]['melds'],[])

    def test_added_kong_requires_robbery_confirmation(self):
        r=Recorder('123m123p123s55m12z',3)
        r.record({'kind':'discard','player':3,'tile':4}); r.record({'kind':'pon','player':0})
        r.record({'kind':'discard','player':0,'tile':27})
        for p,t in ((1,30),(2,31),(3,32)):
            r.record({'kind':'draw','player':p}); r.record({'kind':'discard','player':p,'tile':t})
        r.record({'kind':'draw','player':0,'tile':4}); r.record({'kind':'kakan','player':0,'tile':4})
        self.assertTrue(r.robbery)
        self.assertEqual(r.hand.count(4),1)
        with self.assertRaises(ValueError): r.record({'kind':'pass','player':0})
        r.record({'kind':'confirm_kakan','player':0})
        self.assertEqual(r.hand.count(4),0); self.assertEqual(r.phase,'draw')
        self.assertEqual(r.melds[0][0]['source'],3)
        r.record({'kind':'draw','player':0,'tile':28})
        self.assertTrue(r.observation()['replacement'])

    def test_live_settings_apply_at_next_engine_request(self):
        settings=SearchSettings(); self.assertEqual(settings.snapshot(),(16,1))
        settings.update(128,4); self.assertEqual(settings.snapshot(),(128,4))
        with self.assertRaises(ValueError): settings.update(5,4)
        self.assertEqual(settings.snapshot(),(128,4))

    def test_search_arguments_are_a_snapshot(self):
        settings=SearchSettings(); engine=Engine(settings=settings)
        calls=[]
        def run(args,**kwargs):
            calls.append(list(args)); settings.update(128,4)
            return SimpleNamespace(returncode=0,stdout='{}')
        observation=Recorder('2466899m257p26s23z').observation()
        with patch('server.subprocess.run',side_effect=run):
            engine.run(**observation); engine.run(**observation)
        self.assertEqual(calls[0][-3:],['1000','1','0'])
        self.assertEqual(calls[1][-3:],['8000','4','0'])
        self.assertEqual(calls[0][7],'4'); self.assertEqual(calls[1][7],'10')

    def test_components_reach_both_native_modes(self):
        settings=SearchSettings(); settings.set_components(7)
        engine=Engine(settings=settings); calls=[]
        def run(args,**kwargs):
            calls.append(list(args)); return SimpleNamespace(returncode=0,stdout='{}')
        observation=Recorder('2466899m257p26s23z').observation()
        with patch('server.subprocess.run',side_effect=run):
            engine.run(**observation)
            observation['mode']='respond'; engine.run(**observation)
        self.assertEqual([c[-1] for c in calls],['7','7'])
        self.assertEqual(settings.search_snapshot(),(16,1,7))
        with self.assertRaises(ValueError): settings.set_components(8)

if __name__=='__main__': unittest.main()
