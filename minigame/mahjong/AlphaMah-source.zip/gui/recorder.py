"""Public-information event journal. No opponent concealed tiles are stored."""
from collections import Counter
from copy import deepcopy
import json
from pathlib import Path
from server import parse_tiles, label, meld_tiles, notation

SEATS=('自己','下家','对家','上家')

class Recorder:
    def __init__(self, hand, actor=0):
        tiles=parse_tiles(hand) if isinstance(hand,str) else list(hand)
        if any(type(t) is not int or t not in range(34) for t in tiles): raise ValueError('起始牌值无效')
        if len(tiles) not in (13,14) or actor not in range(4) or (len(tiles)==14 and actor!=0):
            raise ValueError('起始暗手须为 13 张；已摸牌的自己回合可填 14 张')
        self.initial={'hand':notation(tiles),'actor':actor}
        self.events=[]
        self.hand=tiles; self.counts=[len(tiles),13,13,13]
        self.melds=[[],[],[],[]]; self.rivers=[[],[],[],[]]
        self.wall=136-sum(self.counts)
        self.actor=actor; self.phase='turn' if len(tiles)==14 else 'draw'
        self.source=-1; self.offered=-1; self.robbery=False
        self.passed=set()
        self.replacement=False; self.allow_kong=len(tiles)==14
        self.validate()

    @property
    def needs_advice(self):
        return (self.phase=='turn' and self.actor==0) or (self.phase=='response' and self.source!=0 and 0 not in self.passed)

    def _take(self, player, tiles):
        if player==0:
            for t in tiles:
                if t not in self.hand: raise ValueError('自己的暗手没有 '+label(t))
                self.hand.remove(t)
        self.counts[player]-=len(tiles)

    def _pass(self):
        if self.phase!='response' or self.robbery: raise ValueError('当前不是普通弃牌响应；加杠须选择确认加杠')
        self.actor=(self.source+1)%4; self.phase='draw'; self.replacement=False
        self.source=self.offered=-1

    def _draw(self, player, tile):
        if self.phase=='response' and not self.robbery: self._pass()
        if self.phase!='draw' or player!=self.actor: raise ValueError('须由待摸牌的玩家摸牌')
        if self.wall<=0: raise ValueError('牌山已空，请记录流局')
        if player==0:
            if tile not in range(34): raise ValueError('请填写自己的实际摸牌')
            self.hand.append(tile)
        elif tile!=-1: raise ValueError('他家暗摸牌留空，不记录其真实暗手')
        self.wall-=1; self.counts[player]+=1; self.phase='turn'; self.allow_kong=True

    def record(self, event):
        previous=deepcopy(self.__dict__)
        try:
            event=deepcopy(event)
            if not isinstance(event,dict): raise ValueError('事件格式错误')
            self._apply(event); self.validate(); self.events.append(event)
        except Exception:
            self.__dict__=previous
            raise

    def _apply(self, e):
        kind=e.get('kind'); p=e.get('player',self.actor); tile=e.get('tile',-1)
        if type(p) is not int or p not in range(4): raise ValueError('玩家须为 0–3')
        if type(tile) is not int or tile not in range(-1,34): raise ValueError('牌值错误')
        if self.phase=='over': raise ValueError('本局已结束，可撤销或新建记录')
        if kind=='draw': self._draw(p,tile); return
        if kind=='pass': self._pass(); return
        if kind=='decline':
            if self.phase!='response' or p==self.source or p in self.passed: raise ValueError('当前不能记录该玩家过牌')
            self.passed.add(p); return
        if kind=='discard':
            if self.phase=='draw' and p!=0: self._draw(p,-1)
            if self.phase!='turn' or p!=self.actor or tile<0: raise ValueError('请先记录该玩家摸牌，再记录弃牌')
            self._take(p,[tile]); self.rivers[p].append({'tile':tile,'claimed':False})
            self.phase='response'; self.source=p; self.offered=tile; self.robbery=False; self.replacement=False; self.passed=set()
            return
        if kind in ('chi','pon','kan'):
            if self.phase!='response' or self.robbery or p==self.source or p in self.passed: raise ValueError('当前不能吃碰明杠；改动已过的响应请先撤销')
            offered=self.offered
            if kind=='chi':
                if p!=(self.source+1)%4: raise ValueError('只有下家可以吃牌')
                if tile<0 or tile>=27 or tile%9>6 or offered not in range(tile,tile+3): raise ValueError('吃牌请填写包含当前弃牌的顺子起点')
                consumed=[t for t in range(tile,tile+3) if t!=offered]
            else:
                if tile not in (-1,offered): raise ValueError('碰杠须使用当前弃牌')
                tile=offered; consumed=[tile]*(3 if kind=='kan' else 2)
            if kind=='kan' and self.wall<=0: raise ValueError('没有补牌，不能杠')
            self._take(p,consumed)
            self.melds[p].append({'kind':kind,'tile':tile,'source':self.source})
            self.rivers[self.source][-1]['claimed']=True
            self.actor=p; self.phase='draw' if kind=='kan' else 'turn'
            self.replacement=kind=='kan'; self.allow_kong=False; self.source=self.offered=-1
            return
        if kind=='ankan':
            if self.phase!='turn' or p!=self.actor or not self.allow_kong or not self.wall: raise ValueError('当前不能暗杠')
            if p==0:
                if tile<0: raise ValueError('自己的暗杠需要填写牌')
                self._take(p,[tile]*4)
            else:
                if tile!=-1: raise ValueError('他家暗杠留空，只记录暗杠数量')
                self.counts[p]-=4
            self.melds[p].append({'kind':'ankan','tile':tile if p==0 else None,'source':-1})
            self.phase='draw'; self.replacement=True; self.allow_kong=False
            return
        if kind=='kakan':
            if self.phase!='turn' or p!=self.actor or not self.allow_kong or not self.wall: raise ValueError('当前不能加杠')
            if not any(m['kind']=='pon' and m['tile']==tile for m in self.melds[p]): raise ValueError('没有对应的碰牌')
            if p==0 and tile not in self.hand: raise ValueError('自己没有第四张牌')
            self.source=p; self.offered=tile; self.robbery=True; self.phase='response'; self.passed=set()
            return
        if kind=='confirm_kakan':
            if self.phase!='response' or not self.robbery: raise ValueError('没有待确认的加杠')
            p=self.source; tile=self.offered
            meld=next(m for m in self.melds[p] if m['kind']=='pon' and m['tile']==tile)
            self._take(p,[tile]); meld['kind']='kakan'
            self.actor=p; self.phase='draw'; self.replacement=True; self.robbery=False
            self.source=self.offered=-1
            return
        if kind=='win':
            if not ((self.phase=='turn' and p==self.actor) or (self.phase=='response' and p!=self.source and p not in self.passed)):
                raise ValueError('胡牌玩家与当前回合不符')
            self.phase='over'; return
        if kind=='exhausted':
            if self.wall: raise ValueError('牌山未空，不能记录牌尽流局')
            self.phase='over'; return
        raise ValueError('未知记录动作')

    def validate(self):
        if not 0<=self.wall<=84 or self.counts[0]!=len(self.hand): raise ValueError('牌山或手牌张数错误')
        public=Counter(self.hand); total=self.wall+sum(self.counts)
        for p in range(4):
            if self.counts[p]<0 or len(self.melds[p])>4: raise ValueError('手牌或副露数量错误')
            for m in self.melds[p]:
                if p!=0 and m['kind']=='ankan': total+=4
                else:
                    tiles=meld_tiles(m); total+=len(tiles); public.update(tiles)
            for r in self.rivers[p]:
                if not r['claimed']: total+=1; public[r['tile']]+=1
            if self.phase!='over':
                extra=int((self.phase=='turn' and self.actor==p) or (self.phase=='response' and self.robbery and self.source==p))
                if self.counts[p]!=13-3*len(self.melds[p])+extra: raise ValueError('回合与暗手张数不一致，请撤销并检查事件')
        if self.robbery and self.source!=0: public[self.offered]+=1
        if total!=136 or any(n>4 for n in public.values()): raise ValueError('实体牌数不守恒，或已知同种牌超过四张')
        hidden_quads=sum(m['kind']=='ankan' for p in (1,2,3) for m in self.melds[p])
        if sum(public[t]==0 for t in range(34))<hidden_quads: raise ValueError('已知牌与他家暗杠数量冲突')

    def observation(self):
        if not self.needs_advice: raise ValueError('当前尚未轮到自己决策')
        offered=self.offered if self.phase=='response' else -1
        known=[r['tile'] for river in self.rivers for r in river if not r['claimed']]
        opponents=[]
        for p in (1,2,3):
            visible=[deepcopy(m) for m in self.melds[p] if m['kind']!='ankan']
            for m in visible: known.extend(meld_tiles(m))
            opponents.append({'player':p,'melds':visible,'concealed_kongs':sum(m['kind']=='ankan' for m in self.melds[p]),'discards':[r['tile'] for r in self.rivers[p]]})
        if self.robbery: known.append(offered)
        return dict(mode='respond' if offered>=0 else 'search',hand=list(self.hand),melds=deepcopy(self.melds[0]),known=known,
                    replacement=self.replacement if offered<0 else False,
                    context=[0,self.source if offered>=0 else -1,offered,self.wall,int(self.allow_kong),int(self.robbery)],
                    opponents=opponents,rivers=deepcopy(self.rivers))

    def undo(self):
        if not self.events: return
        other=Recorder(**self.initial)
        for event in self.events[:-1]: other.record(event)
        self.__dict__=other.__dict__

    def save(self, path):
        target=Path(path); temporary=target.with_suffix(target.suffix+'.tmp')
        temporary.write_text(json.dumps({'format':'alphamah-public-journal-v1','initial':self.initial,'events':self.events},ensure_ascii=False,indent=2),encoding='utf-8')
        temporary.replace(target)

    @classmethod
    def load(cls, path):
        target=Path(path)
        if target.stat().st_size>2_000_000: raise ValueError('记录文件过大')
        data=json.loads(target.read_text(encoding='utf-8'))
        if data.get('format')!='alphamah-public-journal-v1' or not isinstance(data.get('events'),list) or len(data['events'])>2048:
            raise ValueError('不是支持的牌局记录文件')
        other=cls(**data['initial'])
        for e in data['events']: other.record(e)
        return other
