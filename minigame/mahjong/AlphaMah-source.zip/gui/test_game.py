import unittest
from collections import Counter
from server import Engine, Game, meld_tiles

class PlaytestTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.engine = Engine(timed=False)

    def setUp(self):
        self.g = Game(self.engine)

    def conservation(self):
        g = self.g
        counts = Counter(g.wall)
        for p in range(4):
            counts.update(g.hands[p])
            for m in g.melds[p]: counts.update(meld_tiles(m))
            counts.update(r['tile'] for r in g.rivers[p] if not r['claimed'])
        self.assertEqual(counts, Counter({t:4 for t in range(34)}))
        self.assertEqual(sum(g.scores), 0)

    def reveal_wall_until(self, count):
        # Endgame fixtures: turn excess wall tiles into public, unclaimed discards.
        # This fixes the remaining opportunity, rather than asserting that a noisy
        # multi-turn planner must make one particular opening choice.
        for i,tile in enumerate(self.g.wall[:-count]):
            self.g.rivers[i%4].append({'tile':tile,'claimed':False})
        self.g.wall=self.g.wall[-count:]
        self.conservation()

    def fixture(self, human, melds=(), other_hands=None, turn=0, forced_draw=None, other_melds=None):
        import random
        g = self.g
        pool = [t for t in range(34) for _ in range(4)]
        hands = [list(human), [], [], []]
        declared = [list(melds), [], [], []]
        for p, groups in (other_melds or {}).items(): declared[p] = list(groups)
        for tile in human: pool.remove(tile)
        for groups in declared:
            for meld in groups:
                for tile in meld_tiles(meld): pool.remove(tile)
        for p, hand in (other_hands or {}).items():
            hands[p] = list(hand)
            for tile in hand: pool.remove(tile)
        if forced_draw is not None: pool.remove(forced_draw)
        random.Random(42).shuffle(pool)
        for p in (1,2,3):
            if not hands[p]:
                size = 13 - 3*len(declared[p])
                hands[p], pool = pool[:size], pool[size:]
        if forced_draw is not None: hands[turn].append(forced_draw)
        g.hands, g.melds, g.wall = hands, declared, pool
        g.rivers = [[] for _ in range(4)]
        g.turn, g.phase, g.pending = turn, 'turn', None
        g.last_draw, g.replacement, g.draw_allowed_kong = forced_draw, False, True
        g.refresh()
        self.conservation()

    def test_pon_and_chi_keep_physical_tiles(self):
        human = [0,1,2,9,10,11,18,19,20,4,4,27,28]
        self.fixture(human, turn=3, forced_draw=4)
        self.g.discard(3,4)
        self.assertIn('pon',[o['kind'] for o in self.g.options()])
        self.g.action({'kind':'pon'})
        self.assertEqual(self.g.melds[0][0], {'kind':'pon','tile':4,'source':3})
        self.assertEqual(len(self.g.hands[0]),11)
        self.conservation()
        self.fixture(human, turn=3, forced_draw=3)
        self.g.discard(3,3)
        self.g.action({'kind':'chi','start':2})
        self.assertEqual(self.g.melds[0][0]['tile'],2)
        self.conservation()

    def test_concealed_and_added_kong_replace_tile(self):
        human = [0]*4+[9,10,11,18,19,20,27,27,28,28]
        self.fixture(human)
        before = len(self.g.wall)
        self.g.action({'kind':'ankan','tile':0})
        self.assertEqual(self.g.scores,[30,-10,-10,-10])
        self.assertEqual(len(self.g.wall),before-1)
        self.assertEqual(len(self.g.hands[0]),11)
        self.assertTrue(self.g.replacement)
        self.conservation()
        self.g.scores = [0]*4
        self.fixture([9,10,11,18,19,20,27,27,28,28,4], [{'kind':'pon','tile':4,'source':2}])
        self.g.complete_added_kong(0,4)
        self.assertEqual(self.g.scores,[10,0,-10,0])
        self.conservation()

    def test_rob_added_kong_does_not_charge_kong(self):
        self.fixture([9,10,11,18,19,20,30,30,31,31,4],
                     [{'kind':'pon','tile':4,'source':2}],
                     {1:[9,10,11,18,19,20,27,27,27,28,28,3,5]})
        self.g.action({'kind':'kakan','index':0})
        self.assertEqual(self.g.phase,'over')
        self.assertTrue(self.g.result['robbery'])
        self.assertEqual(self.g.melds[0][0]['kind'],'pon')
        self.assertEqual(self.g.scores,[-20,20,0,0])
        self.conservation()

    def test_deal_visibility_and_determinism(self):
        self.assertEqual(len(self.g.wall), 83)
        self.conservation()
        view = self.g.view()
        self.assertTrue(all(view['players'][p]['hand'] is None for p in (1,2,3)))
        other = Game(self.engine)
        self.assertEqual(other.hands, self.g.hands)
        self.assertEqual(other.wall, self.g.wall)

    def test_whole_round(self):
        for _ in range(400):
            self.conservation()
            g = self.g
            if g.phase == 'over': break
            if g.phase == 'response':
                options = g.options()
                choice = next((o for o in options if o['kind'] == 'ron'), None)
                if choice is None:
                    choice = next((o for o in options if o['kind'] in ('kan','pon','chi')), {'kind':'pass'})
                g.action(choice)
            elif g.turn == 0:
                if g.metrics['winning']: g.action({'kind':'win'})
                else: g.action({'kind':'discard','tile':g.hands[0][-1]})
            else: g.ai_step()
        self.assertEqual(self.g.phase, 'over')
        self.assertIsNotNone(self.g.result)
        self.assertTrue(all(self.g.view()['players'][p]['hand'] is not None for p in range(4)))
        self.assertEqual(sum(self.g.scores), 0)

    def test_kong_and_added_source(self):
        self.g.kong_payment(0, -1)
        self.assertEqual(self.g.scores, [30,-10,-10,-10])
        self.g.kong_payment(0, 2)
        self.assertEqual(self.g.scores, [40,-10,-20,-10])
        old = self.g.scores.copy()
        self.g.finish_draw()
        self.assertEqual(self.g.scores, old)
        self.g.new(42)
        self.assertEqual((self.g.dealer, self.g.turn), (1, 1))

    def test_dealer_continues_after_winning_and_pays_double_on_a_later_loss(self):
        g = self.g
        win = {"payment": 10, "seven_pairs": False, "pure_straight": False, "thirteen_orphans": False}
        g.finish_win([(0, win), (2, win)], 3, 1)
        self.assertEqual(g.result['delta'], [20,0,10,-30])
        self.assertEqual([w['payments'] for w in g.result['winners']], [[0,0,0,20],[0,0,0,10]])
        g.new(42)
        self.assertEqual((g.round, g.dealer, g.turn), (2, 0, 0))
        g.finish_win([(2, win)], -1, 1)
        self.assertEqual(g.result['delta'], [-20,-10,40,-10])
        self.assertEqual(g.result['winners'][0]['payments'], [20,10,0,10])
        g.new(43)
        self.assertEqual((g.round, g.dealer, g.turn), (3, 1, 1))

    def test_evaluate_open_dragon(self):
        from server import notation
        info = self.engine.run('evaluate',[9,9,9,28,28],
                               [{'kind':'chi','tile':t,'source':3} for t in (0,3,6)])
        self.assertTrue(info['winning'])
        self.assertEqual(info['payment'],20)
        self.assertEqual(notation([33,33,0]), '1m77z')

    def test_no_hidden_hand_in_ai_input(self):
        g = self.g
        p = 1
        known = g.known(p)
        self.assertEqual(known, [])
        # Moving unseen tiles between an opponent and the wall must not affect
        # observations, even though the referee's full state changes.
        g.hands[2][0], g.wall[0] = g.wall[0], g.hands[2][0]
        self.assertEqual(g.known(p), known)
        self.conservation()

    def test_invalid_turn(self):
        self.g.action({'kind':'discard','tile':self.g.hands[0][-1]})

    def test_risk_observation_and_search_ignore_hidden_tile_locations(self):
        g = self.g
        observed = g.public_opponents(0)
        rng = g.rng.getstate()
        first = g.decision(0)
        g.hands[1][0],g.wall[0] = g.wall[0],g.hands[1][0]
        self.assertEqual(observed,g.public_opponents(0))
        g.rng.setstate(rng)
        self.assertEqual(first,g.decision(0))
        self.assertEqual(first['model'],'meowcats_upstream_pd_v10')
        self.assertEqual(first['opponents'],[])
        self.conservation()

    def test_concealed_kong_identity_does_not_reach_risk_model(self):
        self.fixture([0,1,2,9,10,11,18,19,20,27,27,28,28,29],
                     other_melds={1:[{'kind':'ankan','tile':8,'source':-1}]})
        g=self.g
        public=g.public_opponents(0); known=g.known(0)
        self.assertEqual(public[0]['concealed_kongs'],1)
        self.assertEqual(public[0]['melds'],[])
        # Relabel two otherwise invisible tile kinds, including the hidden kong.
        swap=lambda t: 17 if t==8 else 8 if t==17 else t
        g.wall=[swap(t) for t in g.wall]
        for p in (1,2,3): g.hands[p]=[swap(t) for t in g.hands[p]]
        g.melds[1][0]['tile']=17
        self.assertEqual(public,g.public_opponents(0))
        self.assertEqual(known,g.known(0))
        result=g.decision(0)
        self.assertEqual(result['model'],'meowcats_upstream_pd_v10')
        self.assertEqual(result['opponents'],[])
        self.conservation()
        if self.g.phase == 'turn' and self.g.turn != 0:
            with self.assertRaises(ValueError): self.g.action({'kind':'discard','tile':self.g.hands[0][-1]})

    def test_ai_actually_calls_pon(self):
        self.fixture([3,4,5,6,7,8,12,13,14,21,22,23,27,28],
                     other_hands={1:[0,1,2,9,10,11,18,19,20,4,4,27,28]})
        self.reveal_wall_until(4)
        self.g.discard(0,4)
        self.assertEqual(self.g.turn,1)
        self.assertEqual(self.g.melds[1], [{'kind':'pon','tile':4,'source':0}])
        self.assertFalse(self.g.draw_allowed_kong)
        self.conservation()

    def test_ai_actually_declares_concealed_kong(self):
        self.fixture([3,4,5,6,7,8,12,13,14,21,22,23,27],
                     other_hands={1:[0,0,0,0,9,10,11,18,19,20,27,27,28,28]},turn=1)
        self.reveal_wall_until(1)
        self.g.ai_step()
        self.assertEqual(self.g.melds[1], [{'kind':'ankan','tile':0,'source':-1}])
        self.assertEqual(self.g.scores,[-20,40,-10,-10])
        self.assertTrue(self.g.replacement)
        self.conservation()

if __name__ == '__main__': unittest.main()
