"""Search settings shared by desktop controls and engine requests."""
from dataclasses import dataclass
import threading
import os

MAX_THREADS = min(64, os.cpu_count() or 1)
THREAD_CHOICES = tuple(sorted(set([1, MAX_THREADS] + [n for n in (2,4,8,12,16,24,32,48,64) if n <= MAX_THREADS])))

@dataclass(frozen=True)
class Preset:
    title: str
    milliseconds: int
    draws: int
    risk_samples: int

PRESETS = {16: Preset('快速 · 1 秒',1000,4,256),
           64: Preset('标准 · 3 秒',3000,6,512),
           128: Preset('深入 · 8 秒',8000,10,1024)}

class SearchSettings:
    def __init__(self, level=16, threads=1):
        self._lock=threading.Lock()
        self._components=0
        self.update(level,threads)

    def update(self, level, threads, components=None):
        if level not in PRESETS or not 1 <= threads <= MAX_THREADS:
            raise ValueError('请选择有效的思考档位和并行数')
        if components is not None and (type(components) is not int or not 0 <= components <= 7):
            raise ValueError("组件设置无效")
        with self._lock:
            self._level,self._threads=level,threads
            if components is not None: self._components=components

    def snapshot(self):
        with self._lock: return self._level,self._threads

    def set_components(self, mask):
        if type(mask) is not int or not 0 <= mask <= 7: raise ValueError('组件设置无效')
        with self._lock: self._components=mask

    def components(self):
        with self._lock: return self._components

    def search_snapshot(self):
        with self._lock: return self._level,self._threads,self._components
