"""Loopback-only playtest host; all hand evaluation/search uses the C++ core."""
from __future__ import annotations
import argparse
import re
from collections import Counter
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import random
import secrets
import subprocess
import threading
import time
from urllib.parse import urlsplit
from settings import PRESETS, SearchSettings, MAX_THREADS

ROOT = Path(__file__).resolve().parents[1]
NAMES = ["你", "下家 AI", "对家 AI", "上家 AI"]
KINDS = ["chi", "pon", "kan", "ankan", "kakan"]

def notation(tiles):
    counts = Counter(tiles)
    return "".join("".join(str(r + 1) * counts[s * 9 + r] for r in range(7 if s == 3 else 9)) + suit
                   for s, suit in enumerate("mpsz") if any(counts[s * 9 + r] for r in range(7 if s == 3 else 9)))

def label(tile):
    return (str(tile % 9 + 1) + ["万", "筒", "索"][tile // 9]) if tile < 27 else "东南西北白发中"[tile - 27]

def meld_tiles(meld):
    return list(range(meld["tile"], meld["tile"] + 3)) if meld["kind"] == "chi" else [meld["tile"]] * (3 if meld["kind"] == "pon" else 4)

class Engine:
    def __init__(self, executable=None, threads=1, timed=True, settings=None, components=0):
        self.threads, self.timed = threads, timed
        self.settings=settings
        self.components=components
        self.executable = Path(executable) if executable else ROOT / "build" / "alphamah_web_engine.exe"
        if not self.executable.is_file():
            raise RuntimeError(f"先构建 alphamah_web_engine：{self.executable}")

    def run(self, mode, hand, melds, known=(), replacement=False, samples=16, draws=8, seed=1, context=None, opponents=None, rivers=None):
        workers=self.threads
        components=self.components
        if mode in ("search","respond") and self.settings is not None:
            samples,workers,components=self.settings.search_snapshot()
            draws=PRESETS[samples].draws
            if context is not None: draws=max(1,min(draws,(context[3]+3)//4))
        encoded = "|".join(f'{KINDS.index(m["kind"])}:{m["tile"]}:{m["source"]}' for m in melds)
        args = [str(self.executable), mode, notation(hand) or "-", encoded or "-", notation(known) or "-",
                str(int(replacement)), str(samples), str(draws), str(seed & 0xFFFFFFFF)]
        if context is not None:
            args.append(":".join(str(value) for value in context))
        if opponents is not None:
            if context is None: raise ValueError("Opponent model needs an observer context")
            public = []
            for p in opponents:
                visible = "|".join(f'{KINDS.index(m["kind"])}:{m["tile"]}:{m["source"]}' for m in p["melds"])
                public.append(f'{p["player"]}~{p["concealed_kongs"]}~{visible or "-"}~{notation(p["discards"]) or "-"}')
            args.extend(["/".join(public) or "-",str(PRESETS.get(samples,PRESETS[16]).risk_samples)])
        if rivers is not None:
            if opponents is None: raise ValueError("Public rivers need all three opponent summaries")
            args.append("/".join(f'{p}~'+(",".join(f'{r["tile"]}:{int(r["claimed"])}' for r in river) or "-")
                                 for p,river in enumerate(rivers)))
        if mode in ("search", "respond") and rivers is not None:
            budget = PRESETS[samples].milliseconds if self.timed else 0
            if mode == "respond": budget = min(budget,1000)
            args.extend([str(budget),str(workers),str(components)])
        process = subprocess.run(args, capture_output=True, text=True, timeout=300,
                                 creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if process.returncode:
            raise RuntimeError("C++ 内核：" + process.stderr.strip())
        return json.loads(process.stdout)

class Game:
    def __init__(self, engine):
        self.engine = engine
        self.scores = [0] * 4
        self.round = 0
        self.dealer = 0
        self.new(20261105, 16, reset=True)

    def new(self, seed, samples=16, reset=False):
        if samples not in (16, 64, 128):
            raise ValueError("请选择有效思考档位")
        if reset:
            self.scores = [0] * 4
            self.round = 0
        if self.round == 0:
            self.dealer = 0
        elif not self.result or not any(w["player"] == self.dealer for w in self.result.get("winners", [])):
            self.dealer = (self.dealer + 1) % 4
        self.round += 1
        self.seed, self.samples = seed, samples
        self.rng = random.Random(seed)
        self.wall = [t for t in range(34) for _ in range(4)]
        self.rng.shuffle(self.wall)
        self.hands = [[] for _ in range(4)]
        for _ in range(13):
            for p in range(4):
                self.hands[p].append(self.wall.pop())
        self.melds = [[] for _ in range(4)]
        self.rivers = [[] for _ in range(4)]
        self.turn = self.dealer
        self.phase = "turn"
        self.pending = None
        self.log = []
        self.result = None
        self.round_start = self.scores.copy()
        self.last_draw = None
        self.replacement = False
        self.draw_allowed_kong = True
        self.metrics = None
        self.hint = None
        self.elapsed = None
        self.push(f"第 {self.round} 局 · {NAMES[self.dealer]}坐庄")
        self.draw(self.dealer)

    def push(self, message):
        self.log.append(message)

    def known(self, player):
        known = [r["tile"] for river in self.rivers for r in river if not r["claimed"]]
        for p in range(4):
            if p == player:
                continue
            for meld in self.melds[p]:
                if meld["kind"] != "ankan":
                    known.extend(meld_tiles(meld))
        return known

    def evaluate(self, player, extra=None, replacement=None, with_known=False):
        hand = self.hands[player] + ([] if extra is None else [extra])
        return self.engine.run("evaluate", hand, self.melds[player], self.known(player) if with_known else (),
                               self.replacement if replacement is None else replacement)

    def refresh(self):
        self.metrics = self.evaluate(0, replacement=self.replacement if self.turn == 0 else False, with_known=True)

    def draw(self, player, replacement=False):
        if not self.wall:
            self.finish_draw()
            return
        tile = self.wall.pop(0) if replacement else self.wall.pop()
        self.hands[player].append(tile)
        self.turn, self.phase = player, "turn"
        self.last_draw, self.replacement = tile, replacement
        self.draw_allowed_kong = True
        self.pending = None
        self.hint = None
        self.refresh()

    def options(self):
        if self.phase == "over":
            return []
        if self.phase == "response":
            return self.pending["offers"]
        if self.turn != 0:
            return []
        offers = []
        if self.metrics["winning"]:
            offers.append({"kind": "win", "label": "自摸"})
        if self.wall and self.draw_allowed_kong:
            counts = Counter(self.hands[0])
            for tile, number in sorted(counts.items()):
                if number == 4:
                    offers.append({"kind": "ankan", "tile": tile, "label": "暗杠 " + label(tile)})
            for i, meld in enumerate(self.melds[0]):
                if meld["kind"] == "pon" and counts[meld["tile"]]:
                    offers.append({"kind": "kakan", "index": i, "label": "加杠 " + label(meld["tile"])})
        return offers

    def discard(self, player, tile):
        if self.phase != "turn" or player != self.turn or tile not in self.hands[player]:
            raise ValueError("现在不能打这张牌")
        self.hands[player].remove(tile)
        self.rivers[player].append({"tile": tile, "claimed": False})
        self.push(f"{NAMES[player]} 打出 {label(tile)}")
        self.hint = None
        self.response(player, tile)

    def claim_options(self, player, source, tile):
        offers = []
        count = self.hands[player].count(tile)
        if count >= 2: offers.append({"kind": "pon", "label": "碰"})
        if count >= 3 and self.wall: offers.append({"kind": "kan", "label": "杠"})
        if (source + 1) % 4 == player and tile < 27:
            for start in range(max(tile // 9 * 9, tile - 2), min(tile, tile // 9 * 9 + 6) + 1):
                needed = list(range(start, start + 3)); needed.remove(tile)
                if all(t in self.hands[player] for t in needed):
                    offers.append({"kind": "chi", "start": start,
                                   "label": "吃 " + "".join(str(t % 9 + 1) for t in range(start, start + 3))})
        return offers

    def decision(self, player, offered=-1, source=-1):
        started = time.monotonic()
        output = self.engine.run("respond" if offered >= 0 else "search", self.hands[player], self.melds[player],
                                 self.known(player), self.replacement if offered < 0 else False,
                                 self.samples, max(1, min(PRESETS[self.samples].draws, (len(self.wall) + 3) // 4)),
                                 self.rng.getrandbits(32),
                                 (player, source, offered, len(self.wall), int(self.draw_allowed_kong)),
                                 self.public_opponents(player), self.rivers)
        self.elapsed = round((time.monotonic() - started) * 1000)
        return output

    def public_opponents(self, player):
        return [{"player": p, "melds": [dict(m) for m in self.melds[p] if m["kind"] != "ankan"],
                 "concealed_kongs": sum(m["kind"] == "ankan" for m in self.melds[p]),
                 "discards": [r["tile"] for r in self.rivers[p]]} for p in range(4) if p != player]

    def response(self, source, tile, robbery=False):
        wins = []
        offers = []
        for offset in (1, 2, 3):
            p = (source + offset) % 4
            info = self.evaluate(p, tile, replacement=False)
            if info["winning"]:
                wins.append((p, info))
                if p == 0:
                    offers.append({"kind": "ron", "label": "抢杠胡" if robbery else "胡牌"})
        if source != 0 and not robbery and not any(p != 0 for p, _ in wins):
            offers.extend(self.claim_options(0, source, tile))
        if offers:
            offers.append({"kind": "pass", "label": "过"})
        self.phase = "response"
        self.pending = {"source": source, "tile": tile, "wins": wins, "offers": offers, "robbery": robbery}
        if not offers:
            self.resolve("pass")
        else:
            self.refresh()

    def resolve(self, kind, start=None):
        pending = self.pending
        wins = [(p, info) for p, info in pending["wins"] if p != 0 or kind == "ron"]
        if wins:
            self.finish_win(wins, pending["source"], pending["tile"], robbery=pending["robbery"])
            return
        if pending["robbery"]:
            self.complete_added_kong(pending["source"], pending["tile"])
            return
        source, tile = pending["source"], pending["tile"]
        calls = []
        if kind in ("chi", "pon", "kan"): calls.append((0, kind, start))
        for player in (1, 2, 3):
            if player == source: continue
            options = self.claim_options(player, source, tile)
            if not options: continue
            choice = self.decision(player, tile, source)
            for option in options:
                if choice["action"] == option["kind"] and (option["kind"] != "chi" or choice["sequence_start"] == option["start"]):
                    calls.append((player, option["kind"], option.get("start")))
                    break
        if not calls:
            self.draw((source + 1) % 4)
            return
        # All responses use the same unmodified pre-claim state. Ron has already
        # been resolved; pon/kan outrank chi, then seat order breaks ties.
        player, kind, start = min(calls, key=lambda c: (c[1] == "chi", (c[0] - source) % 4))
        self.rivers[source][-1]["claimed"] = True
        if kind == "chi":
            needed = list(range(start, start + 3)); needed.remove(tile)
            meld = {"kind": kind, "tile": start, "source": source}
        else:
            needed = [tile] * (3 if kind == "kan" else 2)
            meld = {"kind": kind, "tile": tile, "source": source}
        for t in needed:
            self.hands[player].remove(t)
        self.melds[player].append(meld)
        self.push(f"{NAMES[player]} {'吃' if kind == 'chi' else '碰' if kind == 'pon' else '杠'} {label(tile)}")
        self.turn, self.phase, self.pending = player, "turn", None
        self.last_draw, self.replacement, self.draw_allowed_kong = None, False, False
        if kind == "kan":
            self.kong_payment(player, source)
            self.draw(player, replacement=True)
        else:
            self.refresh()

    def transfer(self, winner, source, amount, *, dealer_win=False):
        payments = [0] * 4
        for p in range(4):
            if p != winner and (source == -1 or source == p):
                paid = amount * (2 if p == self.dealer or dealer_win else 1)
                payments[p] = paid
                self.scores[p] -= paid
                self.scores[winner] += paid
        return payments

    def kong_payment(self, player, source):
        payments = self.transfer(player, source, 10)
        payers = "、".join(f"{NAMES[p]} −{amount}" for p, amount in enumerate(payments) if amount)
        self.push(f"杠分：{NAMES[player]} +{sum(payments)}，{payers}")

    def complete_added_kong(self, player, tile):
        meld = next(m for m in self.melds[player] if m["kind"] == "pon" and m["tile"] == tile)
        self.hands[player].remove(tile)
        meld["kind"] = "kakan"
        self.kong_payment(player, meld["source"])
        self.draw(player, replacement=True)

    def self_kong(self, player, kind, tile=None, index=None):
        if not self.wall or not self.draw_allowed_kong:
            raise ValueError("现在不能开杠")
        if kind == "ankan":
            if self.hands[player].count(tile) != 4: raise ValueError("暗杠需要四张同牌")
            for _ in range(4): self.hands[player].remove(tile)
            self.melds[player].append({"kind": "ankan", "tile": tile, "source": -1})
            self.push(f"{NAMES[player]}暗杠 {label(tile)}")
            self.kong_payment(player, -1)
            self.draw(player, replacement=True)
        elif kind == "kakan":
            if type(index) is not int or not 0 <= index < len(self.melds[player]): raise ValueError("无效副露")
            meld = self.melds[player][index]
            tile = meld["tile"]
            if meld["kind"] != "pon" or tile not in self.hands[player]: raise ValueError("不能加杠")
            self.push(f"{NAMES[player]}尝试加杠 {label(tile)}")
            self.response(player, tile, robbery=True)

    def finish_win(self, wins, source, tile, robbery=False):
        results = []
        for player, info in wins:
            payments = self.transfer(player, source, info["payment"], dealer_win=player == self.dealer)
            patterns = []
            for key, name in (("seven_pairs", "七对子"), ("pure_straight", "龙"), ("thirteen_orphans", "国士无双")):
                if info[key]: patterns.append(name)
            if source == -1 and self.replacement: patterns.append("岭上开花")
            results.append({"player": player, "patterns": patterns or ["普通胡"],
                            "payment": info["payment"], "payments": payments})
            self.push(f"{NAMES[player]} {'自摸' if source == -1 else '抢杠胡' if robbery else '胡牌'} · {'＋'.join(patterns) or '普通胡'} · +{sum(payments)}")
        self.phase, self.pending = "over", None
        self.result = {"type": "win", "winners": results, "source": source, "tile": tile,
                       "robbery": robbery, "delta": [s - old for s, old in zip(self.scores, self.round_start)]}

    def finish_draw(self):
        self.phase, self.pending = "over", None
        self.result = {"type": "draw", "delta": [s - old for s, old in zip(self.scores, self.round_start)]}
        self.push("牌山已尽，流局。已结算的杠分保留。")

    def ai_step(self):
        if self.phase != "turn" or self.turn == 0:
            return
        p = self.turn
        info = self.evaluate(p)
        if info["winning"]:
            self.finish_win([(p, info)], -1, self.last_draw)
            return
        output = self.decision(p)
        if output["action"] in ("ankan", "kakan"):
            tile = output.get("tile")
            index = "mpsz".index(tile[-1]) * 9 + int(tile[0]) - 1 if tile else None
            self.self_kong(p, output["action"], index, output.get("meld_index"))
            return
        tile = output["tile"]
        index = "mpsz".index(tile[-1]) * 9 + int(tile[0]) - 1
        self.discard(p, index)

    def action(self, data):
        kind = data.get("kind")
        if kind == "step":
            self.ai_step(); return
        if kind == "hint":
            if self.phase != "turn" or self.turn != 0: raise ValueError("轮到你时才能分析")
            self.hint = self.decision(0)
            return
        if self.phase == "response":
            if not any(all(data.get(k) == v for k, v in option.items() if k != "label") for option in self.options()):
                raise ValueError("不能执行这个响应动作")
            self.resolve(kind, data.get("start")); return
        if self.phase != "turn" or self.turn != 0:
            raise ValueError("尚未轮到你")
        if kind == "discard":
            tile = data.get("tile")
            if type(tile) is not int: raise ValueError("请选择一张牌")
            self.discard(0, tile); return
        if not any(all(data.get(k) == v for k, v in option.items() if k != "label") for option in self.options()):
            raise ValueError("现在不能执行这个动作")
        if kind == "win":
            self.finish_win([(0, self.metrics)], -1, self.last_draw)
        elif kind in ("ankan", "kakan"):
            self.self_kong(0, kind, data.get("tile"), data.get("index"))

    def view(self):
        over = self.phase == "over"
        pending = None if not self.pending else {k: self.pending[k] for k in ("source", "tile", "robbery")}
        return {"round": self.round, "seed": self.seed, "samples": self.engine.settings.snapshot()[0] if self.engine.settings else self.samples, "threads": self.engine.settings.snapshot()[1] if self.engine.settings else self.engine.threads, "dealer": self.dealer,
                "turn": self.turn, "phase": self.phase, "wall": len(self.wall), "scores": self.scores,
                "players": [{"name": NAMES[p], "count": len(self.hands[p]),
                             "hand": sorted(self.hands[p]) if p == 0 or over else None,
                             "melds": [{**m, "tile": None} if p != 0 and m["kind"] == "ankan" and not over else m
                                       for m in self.melds[p]], "river": self.rivers[p]} for p in range(4)],
                "last_draw": self.last_draw if self.turn == 0 else None, "pending": pending,
                "options": self.options(), "metrics": self.metrics, "hint": self.hint, "log": self.log[-60:],
                "result": self.result, "elapsed": self.elapsed}

def parse_tiles(text):
    text=re.sub(r"\s+","",text); tiles=[]; pos=0
    for m in re.finditer(r"([1-9]+)([mpsz])",text):
        if m.start()!=pos: raise ValueError("牌格式示例：123m456p789s11223z")
        suit="mpsz".index(m[2])
        for rank in m[1]:
            if suit==3 and int(rank)>7: raise ValueError("字牌范围为 1z 到 7z")
            tiles.append(suit*9+int(rank)-1)
        pos=m.end()
    if pos!=len(text) or any(n>4 for n in Counter(tiles).values()): raise ValueError("牌输入错误或同种牌超过四张")
    return tiles

def analyze(engine,data):
    hand=parse_tiles(str(data.get("hand",""))); melds=data.get("melds",[])
    if not isinstance(melds,list) or len(melds)>4: raise ValueError("副露格式错误")
    rivers=[[{"tile":t,"claimed":False} for t in parse_tiles(str(x))] for x in data.get("rivers",["","","",""])]
    if len(rivers)!=4: raise ValueError("需要四家牌河")
    opponents=data.get("opponents",[{"player":p,"concealed_kongs":0,"melds":[],"discards":[]} for p in (1,2,3)])
    for m in melds+[m for opponent in opponents for m in opponent["melds"]]:
        if m["kind"]=="ankan": continue
        source=m["source"]
        if source not in range(4): raise ValueError("副露来源应为 0–3")
        matching=[r for r in rivers[source] if not r["claimed"] and r["tile"]==m.get("called_tile",m["tile"])]
        if not matching: raise ValueError("副露供牌须在来源牌河中；吃牌需填写 called_tile")
        if "river_index" in m:
            index=m["river_index"]
            if type(index) is not int or not 0<=index<len(rivers[source]) or rivers[source][index] not in matching:
                raise ValueError("river_index 须指向来源牌河中尚未被叫走的对应牌")
            rivers[source][index]["claimed"]=True
        else:
            matching[0]["claimed"]=True
    known=[r["tile"] for river in rivers for r in river if not r["claimed"]]
    for opponent in opponents:
        for m in opponent["melds"]: known.extend(meld_tiles(m))
    hidden=sum(13-3*(len(p["melds"])+p["concealed_kongs"])+4*p["concealed_kongs"] for p in opponents)
    auto_wall=136-len(hand)-sum(len(meld_tiles(m)) for m in melds)-len(known)-hidden
    wall=int(data["wall"]) if data.get("wall") not in (None,"") else auto_wall
    samples=int(data.get("samples",16)); workers=int(data.get("threads",engine.threads))
    if samples not in (16,64,128) or not 1 <= workers <= MAX_THREADS: raise ValueError("搜索设置无效")
    robbery=bool(data.get("robbery",False))
    source=int(data.get("source",-1)); offered=parse_tiles(str(data.get("offered","")))
    if source not in (-1,1,2,3) or len(offered)>1 or ((source==-1)!=(len(offered)==0)): raise ValueError("响应需同时填写来源和一张他家弃牌")
    if offered and not robbery and (not rivers[source] or rivers[source][-1]["tile"]!=offered[0]): raise ValueError("响应牌须为来源牌河最后一张")
    if robbery:
        if not offered or not any(p["player"]==source and any(m["kind"]=="pon" and m["tile"]==offered[0] for m in p["melds"]) for p in opponents): raise ValueError("抢加杠须有来源玩家对应的公开碰牌")
        known.append(offered[0])
        if data.get("wall") in (None,""): wall-=1
    replacement=bool(data.get("replacement",False))
    if replacement and offered: raise ValueError("补牌标记仅用于自己摸牌回合")
    local=Engine(engine.executable,workers,engine.timed,components=engine.settings.components() if engine.settings else engine.components); started=time.perf_counter()
    result=local.run("respond" if offered else "search",hand,melds,known,replacement=replacement,samples=samples,draws=PRESETS[samples].draws,seed=int(data.get("seed",1)),context=[0,source,offered[0] if offered else -1,wall,int(bool(data.get("allow_kong",True))),int(robbery)],opponents=opponents,rivers=rivers)
    result["wall_elapsed_ms"]=round((time.perf_counter()-started)*1000,1)
    return result

def serve(port, engine):
    settings=SearchSettings(16,engine.threads)
    engine.settings=settings
    game = Game(engine)
    lock = threading.Lock()
    token = secrets.token_urlsafe(24)
    class Handler(BaseHTTPRequestHandler):
        def send_json(self, data, status=200):
            raw = json.dumps(data, ensure_ascii=False).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers(); self.wfile.write(raw)

        def do_GET(self):
            if urlsplit(self.path).path == "/api/state":
                with lock: self.send_json({**game.view(), "token": token})
                return
            files = {"/analyze": "analyze.html", "/analyze.js": "analyze.js", "/": "index.html", "/app.js": "app.js", "/style.css": "style.css"}
            name = files.get(urlsplit(self.path).path)
            if not name:
                self.send_error(404); return
            raw = (ROOT / "gui" / "web" / name).read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", {"html": "text/html", "js": "text/javascript", "css": "text/css"}[name.split('.')[-1]] + "; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers(); self.wfile.write(raw)

        def do_POST(self):
            if self.headers.get("X-Playtest-Token") != token:
                self.send_json({"error": "请刷新页面重试"}, 403); return
            try:
                size = int(self.headers.get("Content-Length", 0))
                if not 0 < size <= 4096: raise ValueError("请求大小无效")
                data = json.loads(self.rfile.read(size))
                if self.path == "/api/settings":
                    settings.update(int(data.get("samples",settings.snapshot()[0])),int(data.get("threads",settings.snapshot()[1])))
                    self.send_json(dict(zip(("samples","threads"),settings.snapshot()))); return
                with lock:
                    if self.path == "/api/analyze":
                        self.send_json(analyze(engine,data)); return
                    if self.path == "/api/new":
                        settings.update(int(data.get("samples",settings.snapshot()[0])),int(data.get("threads",settings.snapshot()[1])))
                        seed = int(data.get("seed", 20261105))
                        if not 0 <= seed <= 0xFFFFFFFF: raise ValueError("种子范围为 0 到 4294967295")
                        game.new(seed, settings.snapshot()[0], bool(data.get("reset", False)))
                    elif self.path == "/api/action": game.action(data)
                    else: self.send_json({"error": "未知接口"}, 404); return
                    self.send_json(game.view())
            except (ValueError, RuntimeError, subprocess.TimeoutExpired, KeyError, TypeError, IndexError) as e:
                self.send_json({"error": str(e)}, 400)

        def log_message(self, fmt, *args):
            if args and str(args[0]).startswith("POST"):
                return

    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"AlphaMah playtest: http://127.0.0.1:{httpd.server_port}", flush=True)
    try: httpd.serve_forever()
    except KeyboardInterrupt: pass
    finally: httpd.server_close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--engine")
    parser.add_argument("--threads",type=int,choices=(1,2,4,8),default=1)
    args = parser.parse_args()
    serve(args.port, Engine(args.engine,args.threads))
