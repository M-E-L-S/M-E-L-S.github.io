import unittest
from server import Engine, analyze, parse_tiles

class FakeEngine:
    executable=None
    threads=1
    timed=False

class AnalysisInputTests(unittest.TestCase):
    def test_replacement_win(self):
        result=analyze(Engine(timed=False),{'hand':'123456789m111p22z','replacement':True})
        self.assertEqual(result['action'],'win')
        self.assertEqual(result['gain_now'],120)

    def test_robbery_has_no_calls(self):
        opponents=[{'player':p,'concealed_kongs':0,'melds':[],'discards':[]} for p in (1,2,3)]
        opponents[0]['melds']=[{'kind':'pon','tile':4,'source':2}]
        result=analyze(Engine(timed=False),{'hand':'123m123p123s11z22z','source':1,'offered':'5m','robbery':True,'opponents':opponents,'rivers':['','','5m','']})
        self.assertEqual([c['action'] for c in result['candidates']],['pass'])
    def test_real_engine_and_claimed_river(self):
        engine=Engine(timed=False)
        result=analyze(engine,{'hand':'123p123s11z22z5m', 'melds':[{'kind':'pon','tile':4,'source':1}], 'rivers':['','5m','','']})
        self.assertTrue(result['candidates'])
        self.assertEqual(sum(c['samples'] for c in result['candidates']),result['iterations'])

    def test_real_response_and_parallel(self):
        result=analyze(Engine(timed=False),{'hand':'123m123p123s55m12z','source':3,'offered':'5m','rivers':['','','','5m'],'threads':2})
        self.assertEqual(result['workers'],1)  # Author's shipped FlatMC call policy.
        self.assertIn('pon',[c['action'] for c in result['candidates']])
        discard=analyze(Engine(timed=False),{'hand':'123m123p123s55m123z','threads':2})
        self.assertEqual(discard['workers'],2)
    def test_tiles(self):
        self.assertEqual(parse_tiles('123m 77z'),[0,1,2,33,33])
        for text in ('0m','8z','11111p','123','x123m'):
            with self.assertRaises(ValueError): parse_tiles(text)

    def test_invalid_response(self):
        with self.assertRaises(ValueError):
            analyze(FakeEngine(),{'hand':'123m123p123s111z2z','source':1,'offered':'2z'})

    def test_missing_claim_history(self):
        with self.assertRaises(ValueError):
            analyze(FakeEngine(),{'hand':'123p123s11z22z5m','melds':[{'kind':'pon','tile':4,'source':1}]})
