"""Import the pinned upstream sources and apply only explicit portability/rule hooks."""
from pathlib import Path
import hashlib,json,shutil,re,difflib
ROOT=Path(__file__).resolve().parents[1]
SHA='1e6ae5320d5e0d3d3b5d017ff83e05d02b9ba162'
SRC=ROOT/'tools/upstream-extract'/('MeowCaTS_1.0-'+SHA)
DST=ROOT/'vendor/meowcats'
original={}
for folder in ('MJLibrary','MctsLibrary','SamplingLibrary'):
 for p in (SRC/folder).rglob('*'):
  if p.suffix.lower() not in ('.cpp','.h'): continue
  rel=p.relative_to(SRC).as_posix(); text=p.read_text(encoding='utf-8-sig')
  original[rel]=text
  q=DST/rel; q.parent.mkdir(parents=True,exist_ok=True); q.write_text(text,encoding='utf-8')
for name in ('LICENSE','config.ini','ExplorationTermTable.txt'):
 shutil.copy2(SRC/name,DST/name)
def edit(rel,old,new):
 p=DST/rel; s=p.read_text(); assert old in s,(rel,old); p.write_text(s.replace(old,new),encoding='utf-8')
# Relative include spelling is a compiler/platform concern, not a search change.
for rel in original:
 p=DST/rel; s=p.read_text(); s=re.sub(r'(#include\s+"[^"\n]*)',lambda m:m[0].replace('\\','/'),s)
 p.write_text(s,encoding='utf-8')
edit('MJLibrary/MJ_Base/MahjongBaseConfig.h','#define NEED_GROUP 5','#define NEED_GROUP 4')
edit('MJLibrary/MJ_Base/MahjongBaseConfig.h','#pragma once','#pragma once\n#include <cstdint>')
edit('MJLibrary/MJ_Base/MahjongBaseConfig.h','#define NONPICKABLE_TILE_COUNT 16','#define NONPICKABLE_TILE_COUNT 0')
edit('MJLibrary/MJ_Base/Tile.h','g_vTileIds[MAX_RANK + 2]','g_vTileIds[MAX_RANK + 3]')
edit('MJLibrary/MJ_Base/Tile.cpp','g_vTileIds[MAX_RANK + 2]','g_vTileIds[MAX_RANK + 3]')
edit('SamplingLibrary/DrawCountTable.h','#pragma once','#pragma once\n#include <fstream>\nusing std::ifstream;\nusing std::ofstream;')
# MinGW cannot reliably link the original header-defined nontrivial TLS template member.
p=DST/'MJLibrary/Base/OpenAddressHashTable2.h'; s=p.read_text()
s=s.replace('thread_local static std::unique_ptr<OpenAddressHashTableEntry2<_data>[]> m_entry;',
'''using Owner=std::unique_ptr<OpenAddressHashTableEntry2<_data>[]>;
    static Owner*& owner() {
        static thread_local Owner* value=nullptr;
        return value;
    }
    static Owner& entries() {
        if(!owner()) owner()=new Owner;
        return *owner();
    }
    static void releaseTable() {
        delete owner();owner()=nullptr;
        m_count=0;m_size=0;m_mask=0;g_bFirstSetup=true;
    }''')
s=re.sub(r'template<class _data>\s*thread_local std::unique_ptr<OpenAddressHashTableEntry2<_data>\[\]> OpenAddressHashTable2<_data>::m_entry;','',s)
s=s.replace('m_entry','entries()'); p.write_text(s)
edit('MctsLibrary/BaseTree2.cpp','TT::m_entry','TT::entries()')
# Rule callbacks handle seven pairs/kokushi and optimistic hands larger than fourteen.
p=DST/'MJLibrary/MJ_Base/PlayerTile.h'; s=p.read_text()
s=re.sub(r'inline int getMinLack\(\) const \{[^\n]+', 'int getMinLack() const;',s)
s=re.sub(r'inline int getMinLack\(const int& iNeedGroup\) const \{[^\n]+', 'int getMinLack(const int& iNeedGroup) const;',s)
s=re.sub(r'inline bool isWin\(const int& iNeedGroup = NEED_GROUP\) const \{[^\n]+', 'bool isWin(const int& iNeedGroup = NEED_GROUP) const;',s)
s=re.sub(r'inline bool canWin\(const Tile& oTile, const int& iNeedGroup = NEED_GROUP\) const \{[^\n]+', 'bool canWin(const Tile& oTile, const int& iNeedGroup = NEED_GROUP) const;',s)
s=s.replace('inline bool willBeAloneTile(const Tile& oTile) const { return m_oHandTile.willBeAloneTile(oTile); };','bool willBeAloneTile(const Tile& oTile) const;')
p.write_text(s)
# One explicit per-worker random stream; the upstream header used TU-local bind copies.
p=DST/'MJLibrary/Base/Tools.h'; s=p.read_text(); start=s.index('static uint64_t uiRandGenCount'); end=s.index('template<typename T>',start)
s=s[:start]+'''extern thread_local std::default_random_engine gen;
extern thread_local std::uniform_real_distribution<double> dis_double;
extern thread_local std::uniform_int_distribution<int> dis_int;
inline double random_double() { return dis_double(gen); }
inline int random_int() { return dis_int(gen); }

'''+s[end:]; p.write_text(s)
# Standard filesystem replaces the old Windows Boost dependency.
p=DST/'MJLibrary/Base/Tools.cpp'; s=p.read_text(); start=s.index('#ifdef WINDOWS'); end=s.index('using std::stringstream;',start)
s=s[:start]+'#include <filesystem>\nnamespace fs = std::filesystem;\n'+s[end:]; p.write_text(s)
start=s.index('void CERR('); end=s.index('/*void getNextPlayer',start) if '/*void getNextPlayer' in s[start:] else s.index('/*int getNextPlayer',start)
s=s[:start]+'void CERR(const string&) {}\n\n'+s[end:]; p.write_text(s)
# Deterministic hash initialization permits exact cross-process replay; hashing stays unchanged.
edit('MJLibrary/MJ_Base/MJStateHashKeyCalculator.cpp','std::default_random_engine gen = std::default_random_engine(rd());','std::default_random_engine gen = std::default_random_engine(1);')
# The dormant debug table's hard-coded 16-tile dimensions do not fit the 14-tile constants.
p=DST/'MctsLibrary/ExplorationTermTable.cpp'; s=p.read_text()
start=s.index('{',s.index('array<ExplorationTerm_t, EXPLORATION_TERM_TABLE_SIZE> ExplorationTermTable::m_pExplorationTermTable ='))
end=s.index('};',start)+2
s=s[:start]+'{};'+s[end:]; p.write_text(s)
# Embedded apps must not read arbitrary cwd config or write debug logs there.
edit('MJLibrary/Base/Ini.cpp','string sPath = getCurrentPath() + sFileName;','string sPath = sFileName == "config.ini" ? ALPHAMAH_MEOW_CONFIG : getCurrentPath() + sFileName;')
host=(DST/'config.ini').read_text().replace('PrintDebugMsg = 1','PrintDebugMsg = 0').replace('LogTreeSgf = 1','LogTreeSgf = 0')
host=host.replace('[Multithread]\nThreadNum = 1','[Multithread]\nThreadNum = 0')
(DST/'host.ini').write_text(host)
# The local public-position API can reach exhausted pools absent from the author's
# assumed sampling window. Bounds only: do not draw nonexistent tiles or overrun arrays.
p=DST/'SamplingLibrary/SamplingData/GodMoveSamplingData.cpp'; s=p.read_text()
start=s.index('int GodMoveSamplingData::_sample_fourPLayer('); end=s.index('bool GodMoveSamplingData::getTile_fourPlayer',start)
part=s[start:end]
part=part.replace('int iPossiblePlayerTileSize = m_vPossiblePlayerTiles.size();',
 'int iPossiblePlayerTileSize = m_vPossiblePlayerTiles.size();\n\tconst int iPhysicalDrawCount = std::min(m_iDrawCount, m_oRemainTile.getRemainNumber() / PLAYER_COUNT); // HOST_POOL_BOUND')
part=part.replace('i < m_iDrawCount','i < iPhysicalDrawCount').replace('return m_iDrawCount;','return iPhysicalDrawCount;')
s=s[:start]+part+s[end:];p.write_text(s)
edit('SamplingLibrary/GodMoveSampling_v3.cpp','m_vCandidates[i].m_iDrawCount++;',
 'm_vCandidates[i].m_iDrawCount = std::min(m_vCandidates[i].m_iDrawCount + 1, AVERAGE_MAX_DRAW_COUNT); // HOST_ARRAY_BOUND')
# FlatMC time limits are wall-clock milliseconds. WASM pthreads can overflow clock().
sampling='SamplingLibrary/GodMoveSampling_v3'
edit(sampling+'.h','#include <array>','#include <array>\n#include <chrono>')
edit(sampling+'.h','time_t m_uiStartTime;', 'std::chrono::steady_clock::time_point m_startTime;')
edit(sampling+'.cpp','using std::fstream;\n','''using std::fstream;

namespace {
using SamplingClock = std::chrono::steady_clock;
using Milliseconds = std::chrono::milliseconds;
}
''')
edit(sampling+'.cpp','m_uiStartTime = clock();','m_startTime = SamplingClock::now();')
edit(sampling+'.cpp','clock() - m_uiStartTime >= m_uiSampleParameter',
 'SamplingClock::now() - m_startTime >= Milliseconds(m_uiSampleParameter)')
edit(sampling+'.cpp',r'CERR(FormatString("[makeMoveDecision]Used time: %d ms.\n", clock() - m_uiStartTime));',
 'const auto elapsed = std::chrono::duration_cast<Milliseconds>(SamplingClock::now() - m_startTime);\n\t\t'
 r'CERR("[makeMoveDecision]Used time: " + std::to_string(elapsed.count()) + " ms.\n");')
for indent,budget in (('\t\t','m_uiSampleParameter'),('\t','cuiSampleParameter')):
 edit(sampling+'.cpp',f'{indent}time_t startTime = clock();\n{indent}while (clock() - startTime < {budget})',
  f'{indent}const auto deadline = SamplingClock::now() + Milliseconds({budget});\n{indent}while (SamplingClock::now() < deadline)')
# Pass strings through the C-style variadic logger as pointers for Clang.
for candidate in ('m_vCandidates[iSelectedIndex]', 'm_vCandidates.at(0)', 'm_vCandidates.at(i)'):
 action=f'{candidate}.m_oAction.toString()'
 edit(sampling+'.cpp',f'{action}));',f'{action}.c_str()));')
# Route HandTile's unused legacy helpers through the local rule evaluator too.
p=DST/'MJLibrary/MJ_Base/HandTile.h'; s=p.read_text()
s=s.replace('#include "MinLackTable/MinLackTable_old.h"','')
s=re.sub(r'inline int getMinLack\(\) const \{[^\n]+','int getMinLack() const;',s)
s=re.sub(r'inline int getMinLack\(const int& iNeedGroup\) const \{[^\n]+','int getMinLack(const int& iNeedGroup) const;',s)
p.write_text(s)
patch=[]
for rel,before in original.items():
 after=(DST/rel).read_text()
 patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='upstream/'+rel,tofile='adapted/'+rel))
(DST/'adaptation.patch').write_text(''.join(patch),encoding='utf-8')
(DST/'provenance.json').write_text(json.dumps({'upstream':SHA,'repository':'https://github.com/fight5566jay/MeowCaTS_1.0','original_normalized_sha256':{k:hashlib.sha256(v.encode()).hexdigest() for k,v in original.items()}},indent=2)+'\n')
# Compile the actual application-level selection method as an independent test oracle.
header=original['MctsLibrary/MctsPlayer.h']
candidate=header[header.index('class Candidate'):header.index('class MctsPlayerConfig')]
body=original['MctsLibrary/MctsPlayer.cpp']
body=body[body.index('Move MctsPlayer::getBestMove()'):body.index('void MctsPlayer::printInfo')]
oracle='''#pragma once
// Actual pinned application method, with a minimal host solely for differential tests.
namespace meowcats_root_oracle {
'''+candidate+'''
class MctsPlayer {
public:
    struct Config { bool m_bSelectBestWinRateCandidate=false; } m_oConfig;
    std::vector<Candidate> m_vCandidates;
    std::vector<int> roots{0,1,2,3};
    const std::vector<int>& getCurrentMctsList() const { return roots; }
    Move getBestMove();
};
'''+body+'}\n'
(DST/'root_policy_oracle.hpp').write_text(oracle,encoding='utf-8')
print('Imported',len(original),'source files; all search changes are visible in adaptation.patch')
