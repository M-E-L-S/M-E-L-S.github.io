#include "alphamah/simulation.hpp"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <numeric>
#include <stdexcept>

using namespace alphamah;
namespace {
std::map<std::string,std::string> args;
int integer(const std::string& key,int fallback) { return args.count(key) ? std::stoi(args[key]) : fallback; }
double real(const std::string& key,double fallback) { return args.count(key) ? std::stod(args[key]) : fallback; }
std::string value(const std::string& key) {
    if (!args.count(key)) throw std::invalid_argument("Missing "+key);
    return args[key];
}
void arena() {
    unsigned games=integer("--games",16), first=integer("--seed",300001), total=0;
    SearchConfig config; config.iterations=integer("--iterations",128); config.max_draws=integer("--draws",4);
    config.time_limit_ms=integer("--time-ms",0);config.threads=integer("--threads",1);
    unsigned features=integer("--features",0);if(features>7)throw std::invalid_argument("Feature mask must be 0-7");
    config.merge_solitary=features&1;config.importance_sampling=features&2;config.multidepth_sharing=features&4;
    std::ofstream out(value("--out"));
    out<<"seed,seat,net_objective,score,deal_in,self_draw,win,draw,own_draws,searches,iterations,seconds,total_iterations,ess,solitary_deferrals,short_horizon_captures,revision,paper_rollouts,tt_hits,cycle_skips,backend,features,root_risk\n";
    for (unsigned game=0;game<games;++game) for (int seat=0;seat<4;++seat) for (bool net:{true}) {
        if (args.count("--arm") && int(net)!=integer("--arm",0)) continue;
        auto table=deal_round(first+game,(integer("--dealer-offset",0)+game)%4); std::mt19937 rng((first+game)^0xd3a2646cu); Evaluator e;
        auto start=std::chrono::steady_clock::now(); unsigned searches=0; bool dealt_in=false;
        std::uint64_t iterations=0, deferred=0, captures=0, rollouts=0,hits=0,cycles=0; double ess=0;
        while (table.phase!=RoundPhase::Terminal) {
            if (table.phase==RoundPhase::NeedDraw) { round_draw(table); continue; }
            auto o=observe(table,table.actor); auto legal=round_legal_actions(o,e); Action action;
            if (table.actor==seat && legal.size()>1 && legal.front().kind!=ActionKind::Win) {
                config.seed=(first+game)*65537u+searches*17u+seat;
                auto result=search(o,config); action=result.recommended_action; ++searches;
                iterations+=result.iterations; ess+=result.importance_ess;
                deferred+=result.solitary_deferrals; captures+=result.short_horizon_captures;
                rollouts+=result.paper_rollouts; hits+=result.transposition_hits; cycles+=result.paper_cycle_skips;
            } else action=public_policy(o,e,rng,real("--noise",0));
            int source=table.actor; round_act(table,action,e);
            if (table.phase==RoundPhase::Terminal && table.winners && table.source==seat && source!=seat) dealt_in=true;
        }
        validate_table(table);
        double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
        out<<first+game<<','<<seat<<','<<net<<','<<table.scores[seat]<<','<<dealt_in<<','
           <<(bool(table.winners&(1u<<seat)) && table.source<0)<<','<<bool(table.winners&(1u<<seat))<<','<<(!table.winners)<<','
           <<table.draws[seat]<<','<<searches<<','<<config.iterations<<','<<seconds<<','<<iterations<<','<<ess<<','<<deferred<<','<<captures<<','<<0
           <<','<<rollouts<<','<<hits<<','<<cycles<<','<<"upstream"<<','<<integer("--features",-1)<<','<<0<<'\n'; out.flush(); ++total;
        std::cerr<<"arena="<<total<<'/'<<games*4<<" seed="<<first+game<<" seat="<<seat<<" net="<<net<<" score="<<table.scores[seat]<<'\n';
    }
    std::cout<<"{\"rounds\":"<<total<<",\"seed_first\":"<<first<<",\"seed_last\":"<<first+games-1<<",\"iterations_per_search\":"<<config.iterations<<"}\n";
}
}
int main(int argc,char** argv) { try { if(argc<2 || std::string(argv[1])!="arena")throw std::invalid_argument("Use arena");for(int i=2;i<argc;i+=2){if(i+1==argc)throw std::invalid_argument("Missing value");args[argv[i]]=argv[i+1];}arena();return 0;}catch(const std::exception& e){std::cerr<<e.what()<<"\n";return 1;} }
