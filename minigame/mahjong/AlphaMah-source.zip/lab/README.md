# 作者源码消融

当前研究入口为 author_ablation.py；C++ 实验入口仅保留 arena。旧算法、模型训练及旧后端对照脚本已删除，历史复现使用 upstream-pd-v10 标签。

先构建项目，再运行：
python -X utf8 lab/author_ablation.py

冻结程序与数据在 build/author-ablation-v11。程序运行八个原组件组合，固定预算及等时长使用独立牌山；未完成的任务可恢复。只生成统计报告可加 --report。
报告见 [完整消融](../docs/author-ablation.md)。
