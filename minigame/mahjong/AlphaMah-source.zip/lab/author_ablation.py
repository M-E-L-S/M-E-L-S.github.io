"""Original-source-only factorial ablation. Frozen design; no score-driven tuning."""
from pathlib import Path
import csv,hashlib,json,os,random,shutil,subprocess,time
from concurrent.futures import ThreadPoolExecutor,as_completed
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'build/author-ablation-v11'
SPECS={'fixed':dict(first=3000001,seeds=48,ms=0,threads=1,iterations=1024),'time':dict(first=3100001,seeds=24,ms=1000,threads=4,iterations=1024)}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def freeze():
 OUT.mkdir(exist_ok=True)
 design=dict(stages=SPECS,masks=list(range(8)),bits={'MST':1,'IS':2,'MDTT':4},
   opponent='unchanged public offense policy, no private opponent hand access',
   contrasts='3 factorial main effects averaged across the other 4 contexts; 3 full-minus-component effects; full vs baseline. 7 contrasts per metric',
   statistics='whole-wall paired bootstrap, average 4 seats, 20000 draws; 7-contrast Bonferroni intervals',
   budget='fixed: 1024 outer iterations, nominal batch 10, single root. time: 1s elapsed, 4 roots. Author FlatMC calls remain single host decision',
   selection='Fresh evaluation walls; no algorithm or parameter tuning on scores. Component conclusions require corrected interval above zero',
   upstream='1e6ae5320d5e0d3d3b5d017ff83e05d02b9ba162')
 files=[*ROOT.glob('src/*.cpp'),*ROOT.glob('include/alphamah/*.hpp'),ROOT/'CMakeLists.txt',ROOT/'lab/lab.cpp',*ROOT.joinpath('vendor/meowcats').rglob('*')]
 hashes={p.relative_to(ROOT).as_posix():sha(p) for p in files if p.is_file()}
 p=OUT/'protocol.json'
 if p.exists():
  r=json.loads(p.read_text());assert r['design']==design and r['sources']==hashes;assert all(sha(OUT/n)==v for n,v in r['binaries'].items());return r
 for a,b in [('alphamah_lab.exe','engine.exe'),('alphamah_cli.exe','cli.exe')]:shutil.copy2(ROOT/'build'/a,OUT/b)
 r=dict(design=design,sources=hashes,binaries={n:sha(OUT/n) for n in ['engine.exe','cli.exe']},logical_processors=os.cpu_count())
 p.write_text(json.dumps(r,indent=2)+'\n');return r
def jobs(stage):
 s=SPECS[stage]
 for off in range(s['seeds']):
  for mask in range(8):
   seed=s['first']+off;p=OUT/f'{stage}-{seed}-{mask}.csv'
   yield p,[str(OUT/'engine.exe'),'arena','--features',str(mask),'--games','1','--seed',str(seed),'--dealer-offset',str(off%4),'--iterations',str(s['iterations']),'--time-ms',str(s['ms']),'--threads',str(s['threads']),'--draws','6','--out',str(p)]
def complete(p):return p.exists() and len(list(csv.DictReader(p.open())))==4
def run(j):
 p,cmd=j
 if complete(p):return p.name+' cached'
 start=time.perf_counter()
 with p.with_suffix('.log').open('w') as f:subprocess.run(cmd,check=True,stdout=f,stderr=f,timeout=2400,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
 assert complete(p);return p.name+f' {time.perf_counter()-start:.1f}s'
def ci(values):
 rng=random.Random(20261110);v=sorted(sum(rng.choice(values) for _ in values)/len(values) for _ in range(20000))
 return dict(mean=sum(values)/len(values),ci95=[v[500],v[19499]],adjusted=[v[71],v[19928]],wall_differences=values)
def summary(stage):
 s=SPECS[stage];data={};rows=[]
 for p,_ in jobs(stage):
  assert complete(p),p
  mask=int(p.stem.split('-')[2])
  rs=list(csv.DictReader(p.open()));assert {int(x['seat']) for x in rs}==set(range(4))
  for r in rs:
   key=int(r['seed']),int(r['seat']),mask;assert key not in data;data[key]=r
   rows.append(dict(stage=stage,mask=mask,**r))
 arms={str(m):{k:sum(float(r[k]) for r in rows if r['mask']==m)/(4*s['seeds']) for k in ['score','win','deal_in','seconds','total_iterations']} for m in range(8)}
 pairs={}
 for name,bit in [('MST',1),('IS',2),('MDTT',4)]:
  pairs[name+'_main']=[(m|bit,m) for m in range(8) if not m&bit]
  pairs[name+'_full']=[(7,7^bit)]
 pairs['complete']=[(7,0)]
 contrasts={}
 for name,ps in pairs.items():
  contrasts[name]={}
  for metric in ['score','win','deal_in']:
   dif=[sum(float(data[seed,seat,a][metric])-float(data[seed,seat,b][metric]) for seat in range(4) for a,b in ps)/(4*len(ps)) for seed in range(s['first'],s['first']+s['seeds'])]
   contrasts[name][metric]=ci(dif)
 r=dict(arms=arms,contrasts=contrasts)
 (OUT/(stage+'-summary.json')).write_text(json.dumps(r,indent=2)+'\n');return r,rows
def report():
 r=dict(protocol=freeze(),validation=json.loads((OUT/'validation.json').read_text()),stages={},scope='Original PD and author components only; local referee and fixed public-policy opponents');rows=[]
 for stage in SPECS:
  r['stages'][stage],more=summary(stage);rows+=more
 assert len(rows)==2304
 dest=ROOT/'docs/reports'
 with (dest/'author-ablation-v11-rounds.csv').open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 r['rounds_sha256']=sha(dest/'author-ablation-v11-rounds.csv')
 (dest/'author-ablation-v11.json').write_text(json.dumps(r,indent=2)+'\n')
 lines=['# 作者原组件完整消融','', '当前仅保留作者源码 PD。旧适配 PD、自制 MCTS、对手采样模型及相关训练／对照脚本已从工作树删除，历史版本保存在 upstream-pd-v10 标签。作者 vendor 源码本轮未改。','',
 '使用新牌山完成 2,304 局：固定预算 48 牌山 × 四座 × 八组合，以及等时长 24 牌山 × 四座 × 八组合。固定预算 1,024 次外层迭代、每批十条名义模拟；等时长每次 1 秒、四根。真实响应沿用作者 FlatMC，不由这三个树组件控制。对手、规则、种子及自动期限在各组保持一致。','',
 '等时长对局在同一台机器上以八个作业并发运行、每次弃牌四根；这是该共享 CPU 环境下的整局比较，不是独占 CPU 的吞吐率测量。','',
 'MST/IS/MDTT 三个二元开关构成完整 2³ 设计。主效应平均其余组件的四种背景；移除效应比较完整组合与去掉一个组件。预先规定三个主效应、三个移除效应和完整组合对 PD 共七个对比。先平均四座配对差，再按整個牌山 bootstrap 20,000 次；每项指标内对七个对比调整区间。正净分差表示开启该组件有利，放铳差为负才有利。组件间可能交互，不能只按一个均值给算法排普遍名次。','']
 for stage,label in [('fixed','固定预算'),('time','等时长')]:
  x=r['stages'][stage];lines+=['## '+label,'','| 组合 | 和牌率 | 每局净分 | 放铳率 |','| --- | ---: | ---: | ---: |']
  for m in range(8):
   a=x['arms'][str(m)];name='PD'+''.join('＋'+n for n,b in [('MST',1),('IS',2),('MDTT',4)] if m&b)
   lines.append(f"| {name} | {100*a['win']:.2f}% | {a['score']:+.3f} | {100*a['deal_in']:.2f}% |")
  lines+=['','| 对比 | 每局净分差 | 普通 95% 区间 | 七对比调整区间 |','| --- | ---: | --- | --- |']
  for name,c in x['contrasts'].items():
   a=c['score'];lo,hi=a['ci95'];l,h=a['adjusted'];lines.append(f"| {name} | {a['mean']:+.3f} | [{lo:+.3f}, {hi:+.3f}] | [{l:+.3f}, {h:+.3f}] |")
 lines+=['','## 组件判断','','| 组件 | 固定预算主效应 / 完整组合内 | 等时长主效应 / 完整组合内 |','| --- | --- | --- |']
 def verdict(c):
  l,h=c['score']['adjusted'];return '确认增加净分' if l>0 else '确认降低净分' if h<0 else '未确认增减'
 for name in ['MST','IS','MDTT']:
  vals=[' / '.join(verdict(r['stages'][st]['contrasts'][name+k]) for k in ['_main','_full']) for st in SPECS];lines.append('| '+name+' | '+' | '.join(vals)+' |')
 lines+=['','本轮结论：三个组件的平均净分主效应及在完整组合中的净分作用，在固定预算和等时长两组中均未通过七对比调整后的判断。和牌率主效应也未确认显著增减。等时长 PD＋MST＋IS 的净分均值最高，但不能把这个事后排序当作稳定优势；默认不据此启用组件。','',
 '“未确认”表示区间无法分辨增减，不代表证明组件无效。全部结论仅限这套十四张规则、公开策略对手和所列预算；未复现论文训练数据、比赛对手或更大预算，不做算法含义微调。默认保留源码 PD；完整组合及各原开关均可显式使用。','',
 '清理后的规则检查 97,277 项、四人裁判检查 16,219 项、作者源码移植检查 1,231 项与 29 项 Python 检查通过。48 组清理前／后固定种子输出逐字段相同；93 个 vendor 文件与 v10 冻结版指纹一致，组件源码本轮未改。','',
 '逐局数据：[CSV](reports/author-ablation-v11-rounds.csv)；设计、源码／程序指纹、和牌率及放铳率区间：[JSON](reports/author-ablation-v11.json)。','',
 '复现：先构建项目，再运行 python lab/author_ablation.py；只生成报告可用 --report。所有算法冻结后开始测评，没有按结果选择测试种子或调整算法。']
 (ROOT/'docs/author-ablation.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 print('Archived',len(rows),'rounds',flush=True)
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--report',action='store_true');a=p.parse_args();freeze()
 if not a.report:
  for stage in SPECS:
   js=list(jobs(stage));random.Random(451).shuffle(js)
   with ThreadPoolExecutor(max_workers=8) as pool:
    fs=[pool.submit(run,j) for j in js]
    for i,f in enumerate(as_completed(fs),1):
     try:msg=f.result()
     except BaseException:
      for pending in fs:pending.cancel()
      raise
     print(stage,i,'/',len(fs),msg,flush=True)
   summary(stage)
 report()
