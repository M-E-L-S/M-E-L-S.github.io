// Visual regression harness. This file is served from tests/, never the release site.
// The normal app renders public states and handles real pointer/keyboard events.
const params = new URL(location.href).searchParams;
const example = params.get('case') || 'melds';
const rivers = [
  [27,28,30,26,9,13,10,11,32,15],
  [9,18,0,33,30,20,14,0,29,27],
  [16,22,30,0,28,32,11,15,19,21],
  [19,32,18,25,13,7,26,16,23,31]
].map(rs => rs.map((tile,i) => ({tile,claimed:i===2||i===6})));
let s={round:1,dealer:0,turn:0,phase:'turn',wall:47,scores:[0,0,0,0],lastDraw:15,options:[],pending:null,result:null,hints:{waits:[],discards:[]},players:[
 {hand:[6,7,8,12,13,14,15,15],count:8,melds:[{kind:'ankan',tile:2,source:-1},{kind:'chi',tile:18,source:3,called_tile:19}],river:rivers[0]},
 {hand:null,count:4,melds:[{kind:'kakan',tile:3,source:0},{kind:'pon',tile:10,source:2},{kind:'kan',tile:24,source:3}],river:rivers[1]},
 {hand:null,count:10,melds:[{kind:'pon',tile:21,source:3}],river:rivers[2]},
 {hand:null,count:1,melds:[{kind:'pon',tile:17,source:2},{kind:'chi',tile:4,source:2},{kind:'kan',tile:1,source:1},{kind:'pon',tile:31,source:0}],river:rivers[3]}
]};
if(example==='hints'||example==='touch'){
 s.players[0]={hand:[0,1,2,3,4,5,6,7,8,9,9,9,28,29],count:14,melds:[],river:rivers[0]};s.lastDraw=29;
 s.hints={waits:[],discards:[{tile:28,waits:[{tile:29,remaining:3}]},{tile:29,waits:[{tile:28,remaining:3}]}]};
}
if(example==='closed'||example==='animation'){
 s.players[0]={hand:[0,1,2,3,4,5,6,7,8,9,9,9,28,29],count:14,melds:[],river:rivers[0]};s.lastDraw=29;
 for(let p=1;p<4;p++){s.players[p].count=13;s.players[p].melds=[];}
}
if(example==='stress'){
 s.players[0].hand=[27,28];s.players[0].count=2;s.lastDraw=28;
 for(let p=0;p<4;p++){
   s.players[p].melds=[0,9,18,31].map(tile=>({kind:'ankan',tile:p?null:tile,source:-1}));
   s.players[p].river=Array.from({length:37},(_,i)=>({tile:i%34,claimed:i===2||i===6}));
   if(p)s.players[p].count=1;
 }
}
if(example==='meld-clearance'){
 const groups=Number(params.get('groups') ?? 4);
 s.turn=Number(params.get('seat') ?? 1);
 for(let p=0;p<4;p++){
   const hasDrawn=p===s.turn, count=13-3*groups+Number(hasDrawn);
   s.players[p]={
     hand:p===0?Array.from({length:count},(_,i)=>i):null,
     count,hasDrawn,river:rivers[p],
     melds:Array.from({length:groups},(_,i)=>({kind:'kan',tile:14+4*p+i,source:(p+1)%4}))
   };
 }
 s.lastDraw=s.turn===0?s.players[0].hand.at(-1):null;
}
if(example==='reference'){
 s.wall=13;s.scores=[25000,25000,25000,25000];s.lastDraw=33;
 const rs=[[21,16,27,28,28,24,3,8,15,9,0,22,13,17,14],[24,28,27,27,30,9,14,17,19,23,22,13,24,7],[20,0,30,1,26,2,30,21,11,25,0,26,0,30],[29,31,22,19,9,18,17,7,32,27,31,23,13]];
 s.players=rs.map((r,p)=>({hand:p===0?[5,6,7,11,33]:null,count:p===0?5:13,melds:p===0?[{kind:'pon',tile:30,source:1},{kind:'pon',tile:32,source:3},{kind:'chi',tile:10,source:3}]:[],river:r.map(tile=>({tile,claimed:false}))}));
}
if(example==='chi'){
 s.phase='response';s.pending={source:3,tile:12};s.players[3].river.push({tile:12,claimed:false});
 s.options=[{kind:'chi',start:10,label:'吃二三四筒'},{kind:'chi',start:11,label:'吃三四五筒'},{kind:'pass',label:'跳过'}];
}
if(example==='result'||example==='result-nondealer'){
 s.dealer=example==='result'?0:2;
 const payments=s.dealer===0?[0,20,20,20]:[0,10,20,10];
 s.phase='over';s.scores=[payments.reduce((a,b)=>a+b),...payments.slice(1).map(n=>-n)];
 s.result={type:'win',source:-1,tile:10,winners:[{player:0,patterns:['普通胡'],payment:10,payments}],delta:[...s.scores],
   paymentsByRecipient:[payments,[0,0,0,0],[0,0,0,0],[0,0,0,0]]};
 s.players[0].hand=[18,9,27,4,20,5,11,6,27,19,28,28,28,10];
 s.players[0].count=14;s.players[0].melds=[];
}
if(example==='result-open'){
 s.phase='over';s.scores=[10,20,-10,-20];
 s.result={type:'win',source:3,tile:28,winners:[{player:0,patterns:['普通胡'],payment:10,payments:[0,0,0,20]}],delta:[...s.scores],
   paymentsByRecipient:[[0,0,10,20],[20,0,0,0],[0,0,0,0],[0,0,0,0]]};
 s.players[0].hand=[28];s.players[0].count=1;
 s.players[0].melds.push({kind:'kakan',tile:31,source:2},{kind:'kan',tile:13,source:1});
}
if(example==='result-kong-draw'){
 s.phase='over';s.scores=[10,10,-10,-10];
 s.result={type:'draw',delta:[...s.scores],paymentsByRecipient:[[0,10,10,10],[20,0,0,0],[0,0,0,0],[0,0,0,0]]};
}
class FixtureWorker{
 constructor(){FixtureWorker.instance=this;}
 terminate(){}
 postMessage(action){
   if(action.kind==='init') queueMicrotask(()=>this.onmessage({data:{ready:true}}));
   else if(action.kind==='new'&&!this.started){
     this.started=true;
     queueMicrotask(()=>this.onmessage({data:{state:structuredClone(s)}}));
   }
   else if(action.kind==='discard'){
     const hand=s.players[0].hand;hand.splice(hand.indexOf(action.tile),1);s.players[0].count--;
     s.players[0].river.push({tile:action.tile,claimed:false});s.hints={waits:s.hints.discards.find(d=>d.tile===action.tile)?.waits||[],discards:[]};
     s.turn=1;s.phase='response';s.options=[{kind:'pass',label:'过'}];s.pending={source:1,tile:31};s.lastDraw=null;
     queueMicrotask(()=>this.onmessage({data:{state:structuredClone(s)}}));
   }
 }
}
window.Worker=FixtureWorker;
await import('../web/app.js');
const controls=document.createElement('div');controls.style.cssText='position:fixed;top:88px;left:26px;z-index:99;display:flex;gap:8px';
for(const [p,name] of [[0,'自己鸣牌'],[1,'下家鸣牌'],[2,'对家鸣牌'],[3,'上家鸣牌']]){
 const button=document.createElement('button');button.textContent=name;button.onclick=()=>{
   s.players[p].melds.push({kind:'pon',tile:5,source:(p+1)%4});
   FixtureWorker.instance.onmessage({data:{state:structuredClone(s)}});
 };controls.append(button);
}
if(example==='animation')for(const [p,name] of [[1,'下家出牌'],[2,'对家出牌'],[3,'上家出牌']]){
 const button=document.createElement('button');button.textContent=name;button.onclick=()=>{
   s.players[p].river.push({tile:27+p,claimed:false});s.players[p].count--;
   FixtureWorker.instance.onmessage({data:{state:structuredClone(s)}});
 };controls.append(button);
}
if(example==='touch'){
 const touch=document.createElement('button');touch.textContent='模拟触控';touch.onclick=()=>{
   document.getElementById('hand').addEventListener('pointerdown',event=>Object.defineProperty(event,'pointerType',{value:'touch'}),{capture:true});
 };controls.append(touch);
}
document.body.append(controls);
const hide=document.createElement('button');hide.textContent='隐藏测试工具';hide.onclick=()=>controls.hidden=true;controls.append(hide);
