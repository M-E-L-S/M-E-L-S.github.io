const out=document.getElementById('out');
const w=new Worker(new URL('./wasm-test-worker.js',import.meta.url),{type:'module'});
w.onmessage=({data})=>{out.textContent+='\n'+data;};w.onerror=e=>{out.textContent+='\nFAIL '+e.message;};
