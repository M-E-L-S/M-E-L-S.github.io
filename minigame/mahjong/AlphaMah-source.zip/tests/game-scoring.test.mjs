import assert from 'node:assert/strict';
import {test} from 'node:test';
import {Game} from '../web/game.js';

const ordinaryWin = {payment:10};

async function newGame() {
  const game = new Game({evaluate:() => ({winning:false})});
  await game.new(1);
  return game;
}

test('dealer self-draw doubles every payment and the dealer draws first again', async () => {
  const game = await newGame();
  game.finishWin([[0, {payment:20, seven_pairs:true}]], -1, 0);
  assert.deepEqual(game.result.winners[0].payments, [0,40,40,40]);
  assert.deepEqual(game.result.delta, [120,-40,-40,-40]);
  await game.new(2);
  assert.deepEqual([game.round, game.dealer, game.turn], [2,0,0]);
  assert.equal(game.hands[0].length, 14);
  assert.deepEqual(game.scores, [120,-40,-40,-40]);
});

test('a nondealer self-draw doubles only the dealer payment and advances the dealer by one seat', async () => {
  const game = await newGame();
  game.finishWin([[2, ordinaryWin]], -1, 0);
  assert.deepEqual(game.result.winners[0].payments, [20,10,0,10]);
  assert.deepEqual(game.result.delta, [-20,-10,40,-10]);
  await game.new(2);
  assert.deepEqual([game.dealer, game.turn], [1,1]);
});

test('each winner is settled separately on a shared discard', async () => {
  const game = await newGame();
  game.finishWin([[0, ordinaryWin], [2, ordinaryWin]], 3, 0);
  assert.deepEqual(game.result.winners.map(w => w.payments), [[0,0,0,20],[0,0,0,10]]);
  assert.deepEqual(game.result.delta, [20,0,10,-30]);
  await game.new(2);
  assert.equal(game.dealer, 0);

  game.finishWin([[1, ordinaryWin], [2, ordinaryWin]], 0, 0);
  assert.deepEqual(game.result.winners.map(w => w.payments), [[20,0,0,0],[20,0,0,0]]);
  assert.deepEqual(game.result.delta, [-40,20,20,0]);
});

test('dealer kong payments double and a draw advances clockwise, including across seat zero', async () => {
  const game = await newGame();
  game.melds[1] = [{kind:'pon',tile:0,source:0}];
  game.hands[1] = [0];
  await game.completeKong(1, 0);
  assert.deepEqual(game.scores, [-20,20,0,0]);
  for(const nextDealer of [1,2,3,0]) {
    game.finishDraw();
    await game.new(2);
    assert.equal(game.dealer, nextDealer);
  }
  await game.new(3, true);
  assert.deepEqual([game.round, game.dealer], [1,0]);
  assert.deepEqual(game.scores, [0,0,0,0]);
});

test('settlement combines kong and win payments for each payer and recipient', async () => {
  const game = await newGame();
  game.hands[0] = [0,0,0,0];
  await game.selfKong(0, 'ankan', 0);
  game.finishWin([[0, ordinaryWin]], 2, 1);

  assert.deepEqual(game.result.winners[0].payments, [0,0,20,0]);
  assert.deepEqual(game.result.paymentsByRecipient, [[0,10,30,10],[0,0,0,0],[0,0,0,0],[0,0,0,0]]);
  assert.deepEqual(game.result.delta, [50,-10,-30,-10]);
});

test('draw settlement includes kong payments and starts a fresh payment record for the next round', async () => {
  const game = await newGame();
  game.melds[1] = [{kind:'pon',tile:0,source:0}];
  game.hands[1] = [0];
  await game.completeKong(1, 0);
  game.finishDraw();
  assert.deepEqual(game.result.paymentsByRecipient, [[0,0,0,0],[20,0,0,0],[0,0,0,0],[0,0,0,0]]);
  await game.new(2);
  game.finishDraw();
  assert.ok(game.result.paymentsByRecipient.every(row => row.every(amount => amount === 0)));
  assert.deepEqual(game.scores, [-20,20,0,0]);
});
