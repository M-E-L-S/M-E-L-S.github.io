import {Game,notation} from '../web/game.js';
const check=(v,m)=>{if(!v)throw Error(m);};
function physical(g){const ts=[...g.wall,...g.hands.flat(),...g.rivers.flat().filter(r=>!r.claimed).map(r=>r.tile),...g.melds.flat().flatMap(m=>m.kind==='chi'?[m.tile,m.tile+1,m.tile+2]:Array(m.kind==='pon'?3:4).fill(m.tile))];check(ts.length===136,'tile conservation');for(let t=0;t<34;t++)check(ts.filter(x=>x===t).length===4,'tile copies '+t);check(g.scores.reduce((a,b)=>a+b,0)===0,'zero sum');}
try{
 for(const variant of ['mt','st']){
 const {default:create}=await import(`../web/engine/${variant}/alphamah.js`);const m=await create();postMessage(variant+' initialized');
 function call(name,types,args){const p=m._malloc(131072);try{const c=m.cwrap(name,'number',[...types,'number','number'])(...args,p,131072);check(c===0,'C ABI '+name+' '+c);return JSON.parse(m.UTF8ToString(p));}finally{m._free(p);}}
 const engine={evaluate:(h,ms,k,r)=>call('alphamah_evaluate',['string','string','string','number'],[h,ms,k,+r]),search:async(...args)=>{await new Promise(resolve=>setTimeout(resolve,0));args[6]=+args[6];args[7]=25;const r=call('alphamah_search_timed',['string','string','string','string','string','string','number','number','number','number'],args);if(args[3].split(':')[2]==='-1'&&r.candidates.length>1)check(r.workers===(variant==='mt'?Math.min(4,navigator.hardwareConcurrency||1):1),'workers '+r.workers);return r;}};
 const hints=(h,ms='',k='')=>call('alphamah_hints',['string','string','string'],[h,ms,k]);
 const wait=hints('123456789m111p2z','','22z');check(wait.waits.length===1&&wait.waits[0].tile===28&&wait.waits[0].remaining===1,'wait hint public count');
 const discards=hints('123456789m111p22z');check(discards.discards.some(d=>d.tile===28&&d.waits.some(w=>w.tile===28&&w.remaining===2)),'discard wait does not recycle own tile');
 check(hints('123m123p111z2z','1:18:1').waits[0].tile===28,'open hand waits');
 postMessage(variant+': PASS exact waits, public counts, discard hints and open hands');
 const winning=engine.evaluate('123456789m111p22z','','',false);check(winning.winning&&winning.payment===20,'scoring');
 // After the lower seat discards 1s, the opposite seat can pass or chi.
 const responseStarted=performance.now();
 const response=call('alphamah_search_timed',
   ['string','string','string','string','string','string','number','number','number','number'],
   ['49m168p223356s77z','','1s11334z','2:1:18:78:1','0~0~-~34z/1~0~-~1s1z/3~0~-~3z',
    '0~29:0,30:0/1~27:0,18:0/2~27:0/3~29:0',0,1000,6,1829446110]);
 check(['pass','chi'].includes(response.action)&&response.workers===1,'timed FlatMC returns a legal response');
 const responseElapsed=Math.round(performance.now()-responseStarted);
 check(responseElapsed<5000,'1-second FlatMC exceeded its sampling budget: '+responseElapsed+' ms');
 postMessage(variant+': PASS timed FlatMC chi response ('+responseElapsed+' ms)');
 async function fixture(human,declared=[],others={},turn=0,forced=null){
 const g=new Game({...engine,search:async()=>({action:'pass'})});await g.new(1);const pool=Array.from({length:136},(_,i)=>i>>2);
 g.hands=[human.slice(),[],[],[]];g.melds=[declared.map(m=>({...m})),[],[],[]];
 const take=t=>{const i=pool.indexOf(t);check(i>=0,'fixture copies');pool.splice(i,1);};human.forEach(take);
 declared.forEach(m=>Array(m.kind==='pon'?3:4).fill(m.tile).forEach(take));
 for(const [p,h] of Object.entries(others)){g.hands[p]=h.slice();h.forEach(take);}
 if(forced!==null)take(forced);
 for(let i=pool.length-1;i>0;i--){const j=g.random()%(i+1);[pool[i],pool[j]]=[pool[j],pool[i]];}
 for(let p=1;p<4;p++)if(!g.hands[p].length)g.hands[p]=pool.splice(0,13);
 if(forced!==null)g.hands[turn].push(forced);
 g.wall=pool;g.rivers=[[],[],[],[]];g.turn=turn;g.phase='turn';g.pending=null;g.replacement=false;g.allowKong=true;g.lastDraw=forced;g.metrics=await g.evaluate(0);physical(g);return g;
 }
 let g=await fixture([0,1,2,9,10,11,18,19,20,4,4,27,28],[],{},3,4);await g.discard(3,4);await g.action({kind:'pon'});check(g.melds[0][0].kind==='pon','pon');physical(g);
 g=await fixture([0,1,2,9,10,11,18,19,20,4,4,27,28],[],{},3,3);await g.discard(3,3);await g.action({kind:'chi',start:2});check(g.melds[0][0].tile===2,'chi');physical(g);
 g=await fixture([0,0,0,0,9,10,11,18,19,20,27,27,28,28]);await g.action({kind:'ankan',tile:0});check(g.scores[0]===30&&g.replacement,'ankan payment');physical(g);
 g=await fixture([9,10,11,18,19,20,30,30,31,31,4],[{kind:'pon',tile:4,source:2}],{1:[9,10,11,18,19,20,27,27,27,28,28,3,5]});await g.action({kind:'kakan',index:0});check(g.result.robbery&&g.melds[0][0].kind==='pon'&&g.scores[0]===-20,'rob added kong from dealer');physical(g);
 g=await fixture([9,10,11,18,19,20,27,27,28,28,4],[{kind:'pon',tile:4,source:2}]);await g.completeKong(0,4);check(g.scores[0]===10&&g.scores[2]===-10,'added kong source payment');physical(g);
 postMessage(variant+': PASS chi, pon, concealed/added kong, robbery and physical tiles');
 for(const seed of [17,20261111,55]){
 const g=new Game(engine);await g.new(seed);let n=0;
 while(g.phase!=='over'&&n++<400){physical(g);if(g.phase==='response'){const os=g.options();await g.action(os.find(x=>x.kind==='ron')||os.find(x=>x.kind==='kan')||os.find(x=>x.kind==='pon')||os.find(x=>x.kind==='chi')||os.at(-1));}else if(g.turn===0){const os=g.options(),special=os.find(x=>['win','ankan','kakan'].includes(x.kind));if(special)await g.action(special);else {const r=await g.decision(0);await g.action({kind:'discard',tile:'mpsz'.indexOf(r.tile[1])*9+Number(r.tile[0])-1});}}else await g.action({kind:'step'});}
 check(g.phase==='over','round must end');physical(g);postMessage(`${variant} seed ${seed}: PASS (${n} actions, ${g.result.type})`);
 }
 postMessage(`${variant}: PASS actual workers, scoring, three complete games`);
 }
 postMessage('ALL PASS');
}catch(e){postMessage('FAIL '+e.message+'\n'+e.stack);}
