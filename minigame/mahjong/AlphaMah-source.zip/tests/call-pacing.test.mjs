import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Game} from '../web/game.js';

async function setup(action, beforeCall) {
  const game=new Game({evaluate:()=>({winning:false}),search:async()=>({action})},beforeCall);
  await game.new(42);
  game.hands=[[8],[4,4,9],[18],[27]];
  game.rivers[0]=[{tile:4,claimed:false}];
  game.phase='response';
  game.pending={source:0,tile:4,robbery:false,wins:[],offers:[]};
  return game;
}
test('AI may pass despite a legal pon and does not wait when passing',async()=>{
  let waits=0;const game=await setup('pass',async()=>{waits++;});
  await game.resolve('pass');
  assert.equal(waits,0);assert.equal(game.melds[1].length,0);
  assert.equal(game.rivers[0][0].claimed,false);
});
test('selected AI call waits before claiming or removing tiles',async()=>{
  let release,entered=false;
  const game=await setup('pon',()=>{entered=true;return new Promise(resolve=>{release=resolve;});});
  const resolving=game.resolve('pass');
  await Promise.resolve();await Promise.resolve();
  assert.equal(entered,true);assert.equal(game.rivers[0][0].claimed,false);
  assert.deepEqual(game.hands[1],[4,4,9]);assert.equal(game.melds[1].length,0);
  release();await resolving;
  assert.equal(game.rivers[0][0].claimed,true);assert.deepEqual(game.hands[1],[9]);
  assert.equal(game.melds[1][0].kind,'pon');assert.equal(game.turn,1);
});
test('a completed chi exposes the claimed tile separately from the sequence start',async()=>{
  const game=await setup('pass',async()=>{});
  game.hands[0]=[2,3,9];
  game.rivers[3]=[{tile:4,claimed:false}];
  game.pending={source:3,tile:4,robbery:false,wins:[],offers:game.claims(0,3,4)};
  await game.action({kind:'chi',start:2});
  assert.deepEqual(game.view().players[0].melds,[{kind:'chi',tile:2,source:3,called_tile:4}]);
  assert.deepEqual(game.hands[0],[9]);
  assert.equal(game.rivers[3][0].claimed,true);
});
