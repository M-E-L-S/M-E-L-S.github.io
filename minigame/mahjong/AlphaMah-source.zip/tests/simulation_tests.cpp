#include "alphamah/simulation.hpp"
#include "alphamah/api.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>

using namespace alphamah;
namespace {
unsigned checks=0;
void check(bool value,const char* message) { ++checks; if (!value) throw std::runtime_error(message); }
Hand closed(const std::string& text) { return {parse_tiles(text),{}}; }
TableState fixture(std::array<Hand,4> hands,int actor,int reserved=-1) {
    Counts pool{}; pool.fill(4);
    for (const auto& hand:hands) {
        auto own=physical_tiles(hand);
        for (int t=0;t<34;++t) {
            if (own[t]>pool[t]) throw std::logic_error("Impossible fixture");
            pool[t]-=own[t];
        }
    }
    if (reserved>=0) { if (!pool[reserved]) throw std::logic_error("Missing reserved tile"); --pool[reserved]; }
    std::vector<int> remaining;
    for (int t=0;t<34;++t) for (int n=0;n<pool[t];++n) remaining.push_back(t);
    std::mt19937 rng(42);
    for (std::size_t i=remaining.size();i>1;--i) std::swap(remaining[i-1],remaining[random_bounded(rng,static_cast<unsigned>(i))]);
    for (int p=0;p<4;++p) if (!tile_count(hands[p].concealed)) {
        int count=(p==actor ? 14 : 13)-3*static_cast<int>(hands[p].melds.size());
        for (int n=0;n<count;++n) { ++hands[p].concealed[remaining.back()]; remaining.pop_back(); }
    }
    TableState s; s.hands=hands; s.wall=remaining; s.actor=actor;
    if (reserved>=0) s.wall.insert(s.wall.begin(),reserved);
    validate_table(s); return s;
}
void responses(TableState& s,Evaluator& e,const std::array<Action,4>& actions) {
    while (s.phase==RoundPhase::Response) {
        auto options=round_legal_actions(observe(s,s.actor),e);
        check(std::any_of(options.begin(),options.end(),[&](const Action& a){return same_action(a,actions[s.actor]);}),"Fixture response must be legal");
        round_act(s,actions[s.actor],e); validate_table(s);
    }
}
void payment_tests() {
    Evaluator e;
    Hand one=closed("4m"), two=closed("4m");
    one.melds={{MeldKind::Triplet,0,2},{MeldKind::Triplet,1,2},{MeldKind::Triplet,2,2},{MeldKind::Triplet,5,2}};
    two.melds={{MeldKind::Triplet,9,3},{MeldKind::Triplet,10,3},{MeldKind::Triplet,11,3},{MeldKind::Triplet,14,3}};
    auto multi=fixture({closed("4m456789s456p777z8p"),one,two,{}},0,3);
    multi.rivers[1].push_back({multi.wall.front(),false}); multi.wall.erase(multi.wall.begin());
    round_act(multi,{ActionKind::Discard,3},e); validate_table(multi);
    auto ron_options=round_legal_actions(observe(multi,1),e);
    check(ron_options.front().kind==ActionKind::Win,"Previously discarded winning tiles are legal without furiten");
    std::array<Action,4> choices{}; choices[1]={ActionKind::Win,3}; choices[2]={ActionKind::Win,3};
    responses(multi,e,choices);
    check(multi.winners==6 && multi.scores==Payments{-20,10,10,0},"All ron winners charge only the source");

    auto priority=fixture({closed("3m456789s456p777z8p"),closed("123p123s55z12m667z"),closed("33m123p456p789s11z"),{}},0);
    round_act(priority,{ActionKind::Discard,2},e);
    choices={}; choices[1]={ActionKind::Chi,2,0}; choices[2]={ActionKind::Pon,2}; responses(priority,e,choices);
    check(priority.phase==RoundPhase::Turn && priority.actor==2 && !priority.allow_kong && priority.wall.size()>0,
          "Pon beats chi and changes turn order without a draw");
    check(priority.rivers[0].back().claimed && priority.hands[2].melds.back().source_player==0,"Called discard is not double counted");

    auto own=closed("123p123s55z66z5m"); own.melds={{MeldKind::Triplet,4,2}};
    auto rob=fixture({own,closed("123p123s111z22z46m"),{},{}},0);
    unsigned wall=rob.wall.size(); round_act(rob,{ActionKind::AddedKong,4,-1,0},e); validate_table(rob);
    auto rob_view=observe(rob,1);
    check(rob_view.robbing_kong && rob_view.known_outside[4]==4,"Pending added tile is public during robbery");

    choices={}; choices[1]={ActionKind::Win,4}; responses(rob,e,choices);
    check(rob.scores==Payments{-10,10,0,0} && rob.income[0]==0 && rob.wall.size()==wall
          && rob.hands[0].melds[0].kind==MeldKind::Triplet,"Robbery happens before kong payment or replacement draw");

    auto added=fixture({own,{},{},{}},0);
    round_act(added,{ActionKind::AddedKong,4,-1,0},e); choices={}; responses(added,e,choices);
    check(added.scores==Payments{10,0,-10,0} && added.draw_replacement,"A surviving added kong charges the original pon source only");
    auto exposed=fixture({closed("4m456789s456p777z8p"),closed("444m123p123s11z22z"),{},{}},0);
    round_act(exposed,{ActionKind::Discard,3},e); choices={}; choices[1]={ActionKind::Kong,3}; responses(exposed,e,choices);
    check(exposed.scores==Payments{-10,10,0,0} && exposed.draw_replacement,"An open kong charges only the discarder");

    auto kong=fixture({closed("1111m123p123s11z22z"),{},{},{}},0,28); kong.observer=0;
    round_act(kong,{ActionKind::ConcealedKong,0},e); validate_table(kong);
    check(kong.scores==Payments{30,-10,-10,-10},"Concealed kong is immediately settled among all three opponents");
    round_draw(kong,0,1); validate_table(kong);
    check(kong.last_draw==28 && kong.replacement,"Replacement comes from the opposite wall end");
    round_act(kong,{ActionKind::Win},e); validate_table(kong);
    check(kong.scores==Payments{90,-30,-30,-30},"Rinshan win stacks with already paid kong income");
}
void complete_rounds() {
    Evaluator e;
    for (unsigned seed=1;seed<=40;++seed) {
        auto s=deal_round(seed,seed%4); std::mt19937 rng(seed);
        while (s.phase!=RoundPhase::Terminal) {
            validate_table(s); ++checks;
            if (s.phase==RoundPhase::NeedDraw) { round_draw(s); continue; }
            auto o=observe(s,s.actor); auto a=public_policy(o,e,rng,seed%3 ? 0.05 : 0);
            round_act(s,a,e);
            check(s.actions<2048,"A complete round must terminate");
        }
        validate_table(s); ++checks;
    }
}
}
int main() {
    try {
        payment_tests(); complete_rounds();
        std::cout<<"PASS "<<checks<<" simulation checks\n"; return 0;
    } catch (const std::exception& error) { std::cerr<<"FAIL after "<<checks<<": "<<error.what()<<'\n'; return 1; }
}
