import {test} from 'node:test';
import assert from 'node:assert/strict';
import {handLayout, projectDiscard, latestDiscard, meldLayout, visibleRiver, automaticAction, discardTransitions, winningHandLayout} from '../web/presentation.js';

function state(){return {round:1,phase:'turn',turn:0,lastDraw:4,options:[{kind:'ankan',tile:4}],players:Array.from({length:4},(_,p)=>({hand:p===0?[0,4,4,8]:null,count:p===0?4:13,river:[],melds:[]}))};}

test('a duplicate drawn tile moves right but keeps its original action index',()=>{
 const s=state(),before=structuredClone(s);
 assert.deepEqual(handLayout(s),{order:[0,1,3,2],drawn:2});
 assert.deepEqual(s,before);
 s.turn=1;assert.deepEqual(handLayout(s),{order:[0,1,2,3],drawn:-1});
});
test('sort toggle preserves arrival order and the drawn tile action index',()=>{
 const s=state();s.players[0].hand=[8,0,4,4];
 assert.deepEqual(handLayout(s),{order:[1,2,0,3],drawn:3});
 assert.deepEqual(handLayout(s,false),{order:[0,1,2,3],drawn:3});
});
test('claimed discards close gaps while keeping source indices and river history',()=>{
 const river=[{tile:2,claimed:false},{tile:3,claimed:true},{tile:4,claimed:false}];
 assert.deepEqual(visibleRiver(river),[{tile:2,claimed:false,index:0},{tile:4,claimed:false,index:2}]);
 assert.equal(river.length,3);assert.equal(river[1].claimed,true);
});
test('automatic controls prioritize wins, skip only open calls and never cut a claimed hand',()=>{
 const s=state(),tools={win:true,noCall:true,cut:true};
 s.options=[{kind:'win'},{kind:'ankan',tile:4}];assert.deepEqual(automaticAction(s,tools),{kind:'win'});
 s.options=[{kind:'ankan',tile:4}];assert.equal(automaticAction(s,tools),null);
 s.options=[];assert.deepEqual(automaticAction(s,tools),{kind:'discard',tile:4});
 s.lastDraw=null;assert.equal(automaticAction(s,tools),null);
 s.phase='response';s.options=[{kind:'pon'},{kind:'pass'}];assert.deepEqual(automaticAction(s,tools),{kind:'pass'});
 s.options.unshift({kind:'ron'});assert.deepEqual(automaticAction(s,tools),{kind:'ron'});
 tools.win=false;assert.equal(automaticAction(s,tools),null);
});
test('immediate discard feedback removes only the selected tile and never mutates authoritative state',()=>{
 const s=state(),before=structuredClone(s),projected=projectDiscard(s,{kind:'discard',tile:4},2);
 assert.deepEqual(s,before);assert.deepEqual(projected.players[0].hand,[0,4,8]);
 assert.equal(projected.players[0].count,3);assert.equal(projected.players[1].hand,null);
 assert.deepEqual(projected.players[0].river,[{tile:4,claimed:false}]);
 assert.equal(projected.phase,'resolving');assert.equal(projected.lastDraw,null);
 assert.deepEqual(projected.options,[]);
 assert.equal(projectDiscard(s,{kind:'step'},null),s);
 assert.equal(projectDiscard(s,{kind:'discard',tile:33},null),s);
 s.hints={waits:[],discards:[{tile:4,waits:[{tile:5,remaining:2}]}]};
 assert.deepEqual(projectDiscard(s,{kind:'discard',tile:4},2).hints,{waits:[{tile:5,remaining:2}],discards:[]});
});
test('last-discard marker survives draw/claim updates and resets between rounds',()=>{
 const before=state(),after=state();after.players[3].river.push({tile:9,claimed:false});
 const mark=latestDiscard(before,after,null);assert.deepEqual(mark,{player:3,index:0});
 assert.deepEqual(latestDiscard(after,structuredClone(after),mark),mark);
 const next=state();next.round=2;assert.equal(latestDiscard(after,next,mark),null);
});
test('discard motion runs once across immediate projection, engine acknowledgement and unrelated renders',()=>{
 const before=state(),projected=projectDiscard(before,{kind:'discard',tile:4},2);
 assert.deepEqual(discardTransitions(null,before),[]);
 assert.deepEqual(discardTransitions(before,projected),[{key:'1:0:0',player:0,index:0,tile:4}]);
 const acknowledgement=structuredClone(projected);acknowledgement.phase='response';
 assert.deepEqual(discardTransitions(projected,acknowledgement),[]);
 assert.deepEqual(discardTransitions(acknowledgement,structuredClone(acknowledgement)),[]);
 const next=structuredClone(acknowledgement);next.players[2].river.push({tile:9,claimed:false});
 assert.deepEqual(discardTransitions(acknowledgement,next),[{key:'1:2:0',player:2,index:0,tile:9}]);
 const claimed=structuredClone(next);claimed.players[2].river[0].claimed=true;
 assert.deepEqual(discardTransitions(acknowledgement,claimed),[]);
 next.round=2;assert.deepEqual(discardTransitions(acknowledgement,next),[]);
});
test('standard meld faces conceal kong identities and rotate the source tile from each seat',()=>{
 assert.deepEqual(meldLayout({kind:'chi',tile:2,source:3}),{faces:[2,3,4],sideways:0,addedTile:null});
 assert.deepEqual(meldLayout({kind:'chi',tile:2,source:0,called_tile:4},1),{faces:[4,2,3],sideways:0,addedTile:null});
 for(const [source,pon,kan] of [[1,0,0],[0,1,1],[3,2,3]]){
   assert.equal(meldLayout({kind:'pon',tile:4,source},2).sideways,pon);
   assert.equal(meldLayout({kind:'kan',tile:4,source},2).sideways,kan);
   assert.deepEqual(meldLayout({kind:'kakan',tile:4,source},2),{faces:[4,4,4],sideways:pon,addedTile:4});
 }
 assert.deepEqual(meldLayout({kind:'ankan',tile:5,source:-1}),{faces:[null,5,5,null],sideways:-1,addedTile:null});
 assert.deepEqual(meldLayout({kind:'ankan',tile:null,source:-1},1).faces,[null,null,null,null]);
});
test('winning hands sort numerically and set aside exactly one winning tile',()=>{
 const hand=[27,10,2,10,0];
 assert.deepEqual(winningHandLayout(hand,{source:-1,tile:10}),{tiles:[0,2,10,27],winningTile:10});
 assert.deepEqual(winningHandLayout(hand,{source:3,tile:2}),{tiles:[0,2,10,10,27],winningTile:2});
 assert.deepEqual(winningHandLayout(hand,{source:-1,tile:null}),{tiles:[0,2,10,10,27],winningTile:null});
 assert.deepEqual(hand,[27,10,2,10,0]);
});
