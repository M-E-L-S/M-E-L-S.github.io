#include "alphamah/api.h"
#include "alphamah/core.hpp"
#include <algorithm>
#include <cmath>
#include <functional>
#include <iostream>
#include <numeric>
#include <random>
#include <stdexcept>

using namespace alphamah;
namespace {
int checks = 0;
void check(bool condition, const std::string& message) {
    ++checks;
    if (!condition) throw std::runtime_error(message);
}
void rejects(const std::function<void()>& action, const std::string& message) {
    bool rejected = false;
    try { action(); } catch (const std::invalid_argument&) { rejected = true; }
    check(rejected, message);
}
Hand closed(const std::string& tiles) { return {parse_tiles(tiles), {}}; }

// Independent complete-hand oracle: remove a pair first, then only full groups.
bool groups(Counts tiles, int remaining) {
    int first = 0;
    while (first < 34 && !tiles[first]) ++first;
    if (first == 34) return remaining == 0;
    if (!remaining) return false;
    if (tiles[first] >= 3) {
        auto next = tiles;
        next[first] -= 3;
        if (groups(next, remaining - 1)) return true;
    }
    if (first < 27 && first % 9 < 7 && tiles[first + 1] && tiles[first + 2]) {
        --tiles[first]; --tiles[first + 1]; --tiles[first + 2];
        if (groups(tiles, remaining - 1)) return true;
    }
    return false;
}
bool oracle(Counts tiles) {
    int pairs = 0, orphan_types = 0;
    bool orphan_pair = false, only_orphans = true;
    for (int i = 0; i < 34; ++i) {
        pairs += tiles[i] == 2;
        bool orphan = i >= 27 || i % 9 == 0 || i % 9 == 8;
        if (orphan) { orphan_types += tiles[i] > 0; orphan_pair |= tiles[i] >= 2; }
        else if (tiles[i]) only_orphans = false;
        if (tiles[i] >= 2) {
            auto next = tiles;
            next[i] -= 2;
            if (groups(next, 4)) return true;
        }
    }
    return pairs == 7 || (only_orphans && orphan_types == 13 && orphan_pair);
}

void test_tiles() {
    auto tiles = parse_tiles("123m 456p 789s 1234567z");
    check(format_tiles(tiles) == "123m456p789s1234567z", "Tile round trip");
    check(tile_name(33) == "7z", "Honor mapping");
    for (auto text : {"0m", "8z", "11111m", "123", "m", "12 m", "1x"})
        rejects([&] { parse_tiles(text); }, std::string("Reject notation: ") + text);
    rejects([] { validate_hand(closed("123m"), false); }, "Reject wrong hand length");
    auto overfull = closed("1111m123p123s112z");
    overfull.melds.push_back({MeldKind::Triplet, 0, 1});
    rejects([&] { physical_tiles(overfull); }, "Reject meld copy overflow");
}

void test_hands() {
    Evaluator evaluator;
    auto regular = evaluator.patterns(closed("123m123p123s111z22z"));
    check(regular.standard && !regular.seven_pairs, "Open-yaku-free standard win");
    check(evaluator.distance(closed("123m123p123s111z2z")).best() == 0, "Standard tenpai");
    check(evaluator.distance(closed("1111m222p333s444z")).standard == 1,
          "Four identical tiles cannot be both the eyes and an unfinished triplet");
    check(evaluator.patterns(closed("1122m3344p5566s77z")).seven_pairs, "Seven pairs win");
    check(evaluator.distance(closed("1122m3344p5566s7z")).seven_pairs == 0, "Seven pairs tenpai");
    check(evaluator.patterns(closed("119m19p19s1234567z")).thirteen_orphans, "Orphans win");
    auto kokushi = closed("19m19p19s1234567z");
    check(evaluator.distance(kokushi).thirteen_orphans == 0, "13-sided orphans tenpai");
    Counts unseen{};
    for (int i = 0; i < 34; ++i) unseen[i] = 4 - kokushi.concealed[i];
    auto metrics = efficiency(evaluator, kokushi, unseen);
    check(metrics.improving_tiles.size() == 13 && metrics.improving_copies == 39,
          "All 13 orphan tiles remain effective, including isolated honors");
    auto quad_pairs = closed("1111m2233p4455s66z");
    check(!evaluator.patterns(quad_pairs).seven_pairs, "Default distinct pairs excludes quad as two");
    Evaluator local_pairs(Rules{true});
    check(local_pairs.patterns(quad_pairs).seven_pairs, "Optional quad-as-two convention");
    check(evaluator.patterns(closed("123456789m111p22z")).pure_straight, "Pure straight");
    auto false_straight = evaluator.patterns(closed("12223345678999m"));
    check(false_straight.standard && !false_straight.pure_straight,
          "Possessing all ranks does not prove a pure straight");
    Hand open = closed("111p22z");
    open.melds = {{MeldKind::Sequence, 0, 1}, {MeldKind::Sequence, 3, 1}, {MeldKind::Sequence, 6, 1}};
    auto open_patterns = evaluator.patterns(open);
    check(open_patterns.standard && open_patterns.pure_straight, "Declared sequences enter decomposition");
    check(!open_patterns.seven_pairs && !open_patterns.thirteen_orphans, "Special closed patterns disabled with melds");
    Hand kong = closed("123m123p11z");
    kong.melds = {{MeldKind::ConcealedKong, 18, -1}, {MeldKind::Triplet, 31, 2}};
    check(evaluator.patterns(kong).standard && tile_count(physical_tiles(kong)) == 15,
          "Kong occupies one group but four physical tiles");
    Hand live_eye = closed("1m");
    live_eye.melds = {{MeldKind::Triplet, 9, 1}, {MeldKind::Triplet, 10, 1},
                     {MeldKind::Triplet, 11, 1}, {MeldKind::Triplet, 12, 1}};
    check(evaluator.distance(live_eye).standard == 0, "Singleton with a possible mate");
    auto dead_eye = live_eye;
    dead_eye.melds[0].tile = 0;
    check(evaluator.distance(dead_eye).standard == 1,
          "Memo distinguishes declared tiles that exhaust the eyes");
}

void test_oracle() {
    Evaluator evaluator;
    std::mt19937 rng(20261105);
    for (int trial = 0; trial < 400; ++trial) {
        Counts tiles{};
        for (int n = 0; n < 14;) {
            int tile = rng() % 34;
            if (tiles[tile] < 4) { ++tiles[tile]; ++n; }
        }
        check((evaluator.distance({tiles, {}}).best() == -1) == oracle(tiles), "Random complete-hand oracle");
        int remove = rng() % 34;
        while (!tiles[remove]) remove = (remove + 1) % 34;
        --tiles[remove];
        bool can_win = false;
        for (int tile = 0; tile < 34; ++tile) if (tiles[tile] < 4) {
            ++tiles[tile]; can_win |= oracle(tiles); --tiles[tile];
        }
        check((evaluator.distance({tiles, {}}).best() == 0) == can_win, "Random tenpai oracle");
        const int baseline = evaluator.distance({tiles,{}}).best();
        const auto mask = evaluator.improving_mask({tiles,{}});
        for (int tile = 0; tile < 34; ++tile) if (tiles[tile] < 4) {
            ++tiles[tile];
            check(bool((mask >> tile) & 1u) == (evaluator.distance({tiles,{}}).best() < baseline),
                  "Threshold improving query agrees with full-distance enumeration");
            --tiles[tile];
        }
    }
    for (int trial = 0; trial < 2000; ++trial) {
        Counts tiles{};
        const int start = rng() % 26;
        for (int n = 0; n < 13;) {
            int tile = start + rng() % 9;
            if (tiles[tile] < 4) { ++tiles[tile]; ++n; }
        }
        bool can_win = false;
        for (int tile = 0; tile < 34; ++tile) if (tiles[tile] < 4) {
            ++tiles[tile]; can_win |= oracle(tiles); --tiles[tile];
        }
        check((evaluator.distance({tiles, {}}).best() == 0) == can_win,
              "Dense-hand tenpai oracle: " + format_tiles(tiles));
        const auto mask = evaluator.improving_mask({tiles,{}});
        const int baseline = evaluator.distance({tiles,{}}).best();
        for (int tile=0;tile<34;++tile) if (tiles[tile]<4) {
            ++tiles[tile];
            check(bool((mask>>tile)&1u)==(evaluator.distance({tiles,{}}).best()<baseline),
                  "Dense-hand improving mask agrees with full enumeration: " + format_tiles(tiles));
            --tiles[tile];
        }
    }
    int generated = 0;
    while (generated < 300) {
        Counts tiles{};
        tiles[rng() % 34] = 2;
        bool valid = true;
        for (int group = 0; group < 4; ++group) {
            if (rng() % 2) {
                int tile = int(rng() % 3) * 9 + rng() % 7;
                for (int j = 0; j < 3; ++j) ++tiles[tile + j];
            } else tiles[rng() % 34] += 3;
        }
        for (auto n : tiles) valid &= n <= 4;
        if (!valid) continue;
        ++generated;
        check(evaluator.distance({tiles, {}}).standard == -1, "Generated legal normal win");
        int remove = rng() % 34;
        while (!tiles[remove]) remove = (remove + 1) % 34;
        --tiles[remove];
        check(evaluator.distance({tiles, {}}).standard == 0, "Generated normal tenpai");
    }
    // Declared sets can exhaust a concealed singleton's possible mate. In that
    // case a new isolated tile can improve the hand by replacing that singleton.
    for (auto hand : {closed("1111m2222p123s45m"),closed("1111m222p333s444z")}) {
        auto mask=evaluator.improving_mask(hand); int baseline=evaluator.distance(hand).best();
        for (int t=0;t<34;++t) if (hand.concealed[t]<4) {
            ++hand.concealed[t];
            check(bool((mask>>t)&1u)==(evaluator.distance(hand).best()<baseline),"Quad singleton replacement remains an improving tile");
            --hand.concealed[t];
        }
    }
    for (int trial=0;trial<400;++trial) {
        Hand hand; Counts physical{};
        const int groups=1+rng()%4;
        for (int n=0;n<groups;++n) {
            int t=rng()%34; while (physical[t]) t=(t+1)%34;
            const bool kong=rng()%2; physical[t]=kong ? 4 : 3;
            hand.melds.push_back({kong ? MeldKind::ConcealedKong : MeldKind::Triplet,t,kong ? -1 : 1});
        }
        for (int n=0;n<13-3*groups;) {
            int t=rng()%34;
            if (physical[t]<4) { ++physical[t]; ++hand.concealed[t]; ++n; }
        }
        auto mask=evaluator.improving_mask(hand); int baseline=evaluator.distance(hand).best();
        for (int t=0;t<34;++t) if (physical[t]<4) {
            ++hand.concealed[t];
            check(bool((mask>>t)&1u)==(evaluator.distance(hand).best()<baseline),"Open-hand improving mask agrees with full enumeration");
            --hand.concealed[t];
        }
    }
}

void test_scoring() {
    Evaluator evaluator;
    auto plain = evaluator.patterns(closed("123m123p123s111z22z"));
    auto straight = evaluator.patterns(closed("123456789m111p22z"));
    auto seven = evaluator.patterns(closed("1122m3344p5566s77z"));
    auto kokushi = evaluator.patterns(closed("119m19p19s1234567z"));
    check(payment_per_loser(plain) == 10, "Plain payment");
    check(payment_per_loser(straight) == 20 && payment_per_loser(seven) == 20, "Single bonus doubles");
    check(payment_per_loser(straight, {true}) == 40, "Straight plus replacement draw stacks");
    check(payment_per_loser(kokushi) == 40, "Orphans bonus plus additional double");
    check(settle_win(0, 2, plain) == Payments{10, 0, -10, 0}, "Only discarder pays ron");
    check(settle_win(0, -1, plain) == Payments{30, -10, -10, -10}, "Each opponent pays self draw");
    check(settle_win(1, -1, straight, {true}) == Payments{-40, 120, -40, -40}, "Stacked self draw payments");
    rejects([&] { settle_win(0, 1, straight, {true}); }, "Replacement draw cannot be ron");
    rejects([&] { settle_win(0, 0, plain); }, "Cannot pay oneself");
    check(settle_kong(0, {MeldKind::OpenKong, 5, 2}) == Payments{10, 0, -10, 0}, "Exposed kong payer");
    check(settle_kong(0, {MeldKind::AddedKong, 5, 2}) == Payments{10, 0, -10, 0}, "Added kong original pon payer");
    check(settle_kong(0, {MeldKind::ConcealedKong, 5, -1}) == Payments{30, -10, -10, -10}, "Concealed kong all pay");
    Payments balances{};
    apply_payments(balances, settle_kong(0, {MeldKind::ConcealedKong, 5, -1}));
    check(balances == Payments{30, -10, -10, -10}, "Kong payment applied before a win");
    apply_payments(balances, settle_win(2, 1, plain));
    check(balances == Payments{30, -20, 0, -10}, "Later win preserves earlier kong transfer");
    rejects([&] { apply_payments(balances, {1, 0, 0, 0}); }, "Reject nonconserving payment");
}

void test_api() {
    const char* hand = "123m123p123s11z22z3z";
    int size = alphamah_search(hand, "", 1, 1, 1, nullptr, 0);
    check(size > 1, "C ABI output size query");
    std::vector<char> buffer(size);
    check(alphamah_search(hand, "", 1, 1, 1, buffer.data(), size) == 0, "C ABI full output");
    check(std::string(buffer.data()).find("meowcats_upstream_pd_v10") != std::string::npos, "C ABI JSON model");
    check(alphamah_search(nullptr, "", 1, 1, 1, buffer.data(), size) == -1, "C ABI null hand rejection");
    check(std::string(buffer.data()).find("error") != std::string::npos, "C ABI error JSON");
    char small[1] = {'x'};
    check(alphamah_search(hand, "", 1, 1, 1, small, 1) == size && small[0] == '\0', "Small buffer not truncated JSON");

    const auto hints=[](const char* h,const char* ms,const char* known) {
        int size=alphamah_hints(h,ms,known,nullptr,0);
        check(size>0,"Wait hints size query");
        std::vector<char> out(size);
        check(alphamah_hints(h,ms,known,out.data(),size)==0,"Wait hints output");
        return std::string(out.data());
    };
    check(hints("123456789m111p2z","","22z")=="{\"waits\":[{\"tile\":28,\"remaining\":1}],\"discards\":[]}","Visible copies reduce waits without hidden information");
    check(hints("123456789m111p2z","","222z").find("\"remaining\":0")!=std::string::npos,"Dead waits remain visible");
    check(hints("123456789m111p22z","","").find("\"tile\":28,\"remaining\":2")!=std::string::npos,"Discarded tile does not become an unseen copy");
    check(hints("1122m3344p5566s7z","","")=="{\"waits\":[{\"tile\":33,\"remaining\":3}],\"discards\":[]}","Seven pairs waits");
    check(hints("123m123p111z2z","1:18:1","")=="{\"waits\":[{\"tile\":28,\"remaining\":3}],\"discards\":[]}","Open hand waits");
    check(alphamah_hints(nullptr,"","",nullptr,0)==-1,"Wait hints reject null input");
}

}
int main() {
    try {
        test_tiles(); test_hands(); test_oracle(); test_scoring(); test_api();
        std::cout << "PASS " << checks << " checks\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL after " << checks << " checks: " << e.what() << '\n';
        return 1;
    }
}
