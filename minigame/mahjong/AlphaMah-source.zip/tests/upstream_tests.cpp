#include "alphamah/winning_subsets.hpp"
#include "alphamah/simulation.hpp"
#include "MctsLibrary/Mcts2.h"
#include "SamplingLibrary/GodMoveSampling_v3.h"
#include "root_policy_oracle.hpp"
#include <cmath>
#include <algorithm>
#include <iostream>
#include <set>
#include <stdexcept>

using namespace alphamah;
namespace {
int checks=0;
void check(bool ok,const char* message) {++checks;if(!ok) throw std::runtime_error(message);}
PlayerTile player(const char* text) {
    HandTile h;auto counts=parse_tiles(text);
    for(int t=0;t<34;++t) for(int k=0;k<counts[t];++k) h.putTile(t);
    return PlayerTile(h,{});
}
class Inspect : public Mcts2 {
public:
    Inspect(const PlayerTile& p,bool call=false) {
        RemainTile pool;MctsConfig cfg;cfg.m_bFirstSetup=false;cfg.m_bKeepSelectionDownThroughTTNode=true;
        _init(SamplingData(Move(),p,pool,6),cfg,true);
        if(call) setupCandidateNodes({Move(MoveType::Move_Pass),Move(MoveType::Move_Pong,Tile(27))});
        else setupCandidateNodes(getLegalMoves(p,pool,false,false,false));
    }
    using Mcts2::getBestChild;
    using Mcts2::getUcbValue;
};
void author_selection() {
    Inspect tree(player("123m123p123s11234z"));
    auto root=const_cast<BaseTreeNode2*>(tree.getRootNodePtr());
    std::set<int> choices;
    for(int seed=1;seed<=40;++seed) {
        gen.seed(seed);auto child=tree.getBestChild(root);choices.insert(child->getMove().getTargetTile());
        int minimum=99;for(auto c:root->m_vChildren) minimum=std::min(minimum,c->getMinLack());
        check(child->getMinLack()==minimum,"Author move ordering prefers minimum lack among unvisited ties");
    }
    check(choices.size()>1,"Author reservoir sampling randomizes genuinely tied actions");
    Inspect near_tree(player("123m123p123s11223z"));
    root=const_cast<BaseTreeNode2*>(near_tree.getRootNodePtr());
    root->addVisitCountTT(100);
    bool near=false,far=false;
    for(auto child:root->m_vChildren) {
        child->completeSetup(false,1,false);child->addVisitCountNoTT(10);child->addVisitCountTT(10);
        const double cp=child->getMinLack()<=1 ? .5:.1;
        check(std::abs(near_tree.getUcbValue(child.get())-cp*std::sqrt(std::log(100.)/10))<1e-6,
            "The original near-ready exploration coefficient is retained");
        near|=cp==.5;far|=cp==.1;
    }
    check(near && far,"The exploration test exercises both near-ready and ordinary children");
    Inspect call(player("123m123p457s1122z"),true);int pong=0;
    for(auto child:call.getRootNodePtr()->m_vChildren) if(child->getMove().getMoveType()==MoveType::Move_Pong) ++pong;
    check(pong>1,"Author MCTS meld expansion retains separate meld-discard root candidates");
}
void integration() {
    auto table=deal_round(1900091);auto o=observe(table,0);SearchConfig c;c.iterations=256;c.max_draws=6;
    for(int mask=0;mask<8;++mask) {
        c.merge_solitary=mask&1;c.importance_sampling=mask&2;c.multidepth_sharing=mask&4;
        auto r=search(o,c);check(r.upstream_pd && r.iterations==256,"Author backend is the production default and conserves iterations");
        check(result_json(r)==result_json(search(o,c)),"All original component profiles reproduce at a fixed seed");
        unsigned n=0;for(auto x:r.candidates) {n+=x.samples;check(std::isfinite(x.win_probability),"Original ordinary-IS estimates remain finite");}
        check(n>=256,"Application root statistics are shared TT visits and need not partition outer iterations");
        auto changed=table;std::reverse(changed.wall.begin(),changed.wall.end());
        check(result_json(r)==result_json(search(observe(changed,0),c)),"The author backend never reads the actual invisible wall order");
    }
    c.threads=4;auto parallel=search(o,c);
    check(parallel.workers==4 && parallel.iterations==256,"Four independent author trees share the fixed total budget");
    check(result_json(parallel)==result_json(search(o,c)),"Four-tree results reproduce exactly");
    c.threads=1;
    Observation response;response.hand={parse_tiles("123m123p457s1122z"),{}};
    response.offered_tile=27;response.source_player=3;response.player=0;response.remaining_wall=50;
    response.known_outside[27]=1;
    auto flat=search(response,c);Evaluator e;auto legal=round_legal_actions(response,e);
    check(flat.upstream_pd && std::any_of(legal.begin(),legal.end(),[&](auto a){return same_action(a,flat.recommended_action);}),
        "The shipped original FlatMC meld policy returns a local legal action");
    check(result_json(flat)==result_json(search(response,c)),"The original FlatMC meld path reproduces exactly");
    check(flat.paper_rollouts>0,"Real call decisions run the author's sampling code");
    check(flat.candidates.size()==legal.size(),"The shipped FlatMC path evaluates calls before choosing a discard");
    for(const char* h:{"1122m3344p5566s77z","19m19p19s12345677z"}) {
        Observation won;won.hand={parse_tiles(h),{}};check(search(won,c).win_now,"Local special hands win at the actual root");
        auto source=player(h);source.putTileToHandTile(Tile(4));
        check(source.isWin(),"Original optimistic sampling recognizes a special-hand subset among surplus tiles");
    }
    for(int remaining:{0,1,2,3,4,8,12}) {
        Observation sparse;sparse.hand={parse_tiles("2466899m257p26s23z"),{}};
        auto owned=physical_tiles(sparse.hand);
        for(int t=0;t<34;++t) sparse.known_outside[t]=4-owned[t];
        std::vector<int> absent;for(int t=0;t<34;++t) if(!owned[t]) absent.push_back(t);
        for(int n=0;n<remaining;++n) --sparse.known_outside[absent[n/4]];
        auto r=search(sparse,c);
        check(r.iterations==0 && std::all_of(r.candidates.begin(),r.candidates.end(),[](auto x){return !x.samples && x.win_probability==0;}),
            "A pool shorter than the author's minimum simulation window is handled without fictitious samples or an assertion");
    }
    std::string short_pool(34,'0');short_pool[4]='4';RemainTile small(short_pool,RemainTileType::Type_Original);
    SamplingData bounded(Move(),player("123m123p123s1122z"),small,1);
    bounded.m_iDrawCount=AVERAGE_MAX_DRAW_COUNT;bounded.sample(32);
    check(bounded.getWinCount()==0 && bounded.m_oRemainTile.getRemainNumber()==4,
        "An extended original sampling window cannot consume tiles beyond its physical pool");
    GodMoveSampling_v3 flat_bound(player("123m123p123s1122z"),small,GodMoveSampling_v3::SampleMode::Mode_Count,128,1);
    flat_bound.reset();flat_bound.makeMeldSamplingData(Tile(),MoveType::Move_Pass);
    flat_bound.makeMeldSamplingData(Tile(),MoveType::Move_Pass);flat_bound.makeMoveDecision();
    for(int i=0;i<64;++i) flat_bound.prune();
    for(auto d:flat_bound.getCandidates()) check(d.m_iDrawCount==AVERAGE_MAX_DRAW_COUNT,
        "Author zero-win horizon extension stays within the local array capacity");
}
void root_oracle() {
    std::mt19937 rng(1927);
    for(int trial=0;trial<1024;++trial) {
        meowcats_root_oracle::MctsPlayer oracle;
        std::vector<alphamah::Candidate> ours;
        for(int t=0;t<8;++t) {
            meowcats_root_oracle::Candidate c;c.m_oMove=Move(MoveType::Move_Throw,Tile(t));
            c.m_uiVisitCount=1+rng()%5;c.m_uiDrawCount=3;c.m_uiVote=0;c.m_vWinCounts.fill(float(rng()%20)/10);
            oracle.m_vCandidates.push_back(c);
            alphamah::Candidate x;x.action={ActionKind::Discard,t};x.upstream_order=t;
            x.samples=c.m_uiVisitCount;x.wins=c.getWinCount();ours.push_back(x);
        }
        std::stable_sort(ours.begin(),ours.end(),upstream_prefer);
        check(ours.front().action.tile==int(oracle.getBestMove().getTargetTile()),
            "Root selection exactly matches the actual author application method, including ties");
    }
}
void long_parallel_lifetime() {
    // This opening previously crashed in MinGW TLS destruction after the first
    // one-second parallel search. Exercise actual thread teardown for each mask.
    for(auto seed:{2100007u,2100009u}) {
    auto o=observe(deal_round(seed,seed==2100007 ? 2:0),seed==2100007 ? 2:0);
    SearchConfig c;c.time_limit_ms=1000;c.threads=4;c.iterations=512;
    for(int mask:{1,3,7}) {
        c.merge_solitary=mask&1;c.importance_sampling=mask&2;c.multidepth_sharing=mask&4;
        auto r=search(o,c);
        check(r.workers==4 && r.iterations>0,"Long author search joins and releases all native roots");
        check(!r.candidates.empty() && std::all_of(r.candidates.begin(),r.candidates.end(),[](auto x){return std::isfinite(x.win_probability);}),
            "Long parallel search returns finite candidate statistics after thread teardown");
    }
    }
}
}
int main() {
    try {integration();author_selection();root_oracle();long_parallel_lifetime();std::cout<<"PASS "<<checks<<" upstream checks\n";return 0;}
    catch(const std::exception& e) {std::cerr<<"FAIL after "<<checks<<": "<<e.what()<<'\n';return 1;}
}
