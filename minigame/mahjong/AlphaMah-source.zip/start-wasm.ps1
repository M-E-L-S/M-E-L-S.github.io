$ErrorActionPreference='Stop'
Set-Location -LiteralPath $PSScriptRoot
& ./.venv/Scripts/python.exe scripts/serve_wasm.py --open
