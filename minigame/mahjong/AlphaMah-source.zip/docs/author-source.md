# 当前作者源码后端

唯一搜索后端是 vendor/meowcats 的 PD，固定提交 1e6ae5320d5e0d3d3b5d017ff83e05d02b9ba162。WASM 发布增加三处日志字符串的 `.c_str()` 修正，以兼容 Clang；不改变搜索算法。

- Mcts2、ChanceNode2、BaseTree2：作者树选择、机会分布、MST、普通 IS、MDTT 与回传。
- GodMoveSamplingData：作者乐观叶模拟。
- GodMoveSampling_v3：发布配置中的真实吃碰杠 FlatMC 决策。
- DrawCountTable：作者无训练文件时的默认期限逻辑。
- 根汇总遵循作者 MctsPlayer 的共享访问数及原顺序破同分。

地方规则与工程适配沿用已核对版本：五组改四组、七对子与十三幺判定、特殊型孤张例外、物理牌池及数组保护、可设种子的随机流、MinGW 的显式资源释放、原生及 WASM pthread 根并行和经过时间预算。实际番分、杠分由地方规则裁判结算，不改写作者搜索回报。完整导入差异在 vendor/meowcats/adaptation.patch，来源哈希在 provenance.json；v10 的详细逐项核对见 upstream-method-audit.md。

本地 winning_subsets.cpp 只包含地方规则所需的和牌子集判定及缓存，没有 PD 搜索器。simulation.cpp 保留四人裁判及固定公开牌效对手，后者仅作为对局基准，不是自制 MCTS。dispatch.cpp 只负责调用作者后端和汇总原生根树。

旧适配 PD、自制己方／四人 MCTS、对手暗手采样、风险估计、训练模型及其脚本已从当前源码删除。C ABI、Python 协议及 JSON 中少量旧字段仍为兼容保留；风险字段为空或零，不运行旧模型。旧代码和历史报告可从 upstream-pd-v10 标签回溯。

当前完整八组合消融及验证见 [消融报告](author-ablation.md)。没有重新设计 IS、MST 或 MDTT 的算法含义。
