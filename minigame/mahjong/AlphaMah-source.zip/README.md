# AlphaMah

原生 Python 对战和持续牌局分析：运行 `.\.venv\Scripts\python.exe gui\desktop.py` 或 `powershell -ExecutionPolicy Bypass -File .\start-desktop.ps1`。详见 [原生版说明](docs/desktop.md)。旧 Web 测试桌仍可使用 [原入口](gui/README.md)。

地方麻将 C++ 内核。总体采用蒙特卡洛搜索，最终通过 WASM 在浏览器 Worker 中运行。

## 当前搜索方案

默认入口已改为直接调用作者 [MeowCaTS 源码](vendor/meowcats/README.md)的 PD 搜索，固定提交为 `1e6ae5320d5e0d3d3b5d017ff83e05d02b9ba162`。保留作者的树选择、乐观叶模拟、自动期限、实际 FlatMC 吃碰杠响应及根统计汇总；MST、IS、MDTT 按原组件提供开关。十四张地方规则、特殊和牌、牌池／数组边界和宿主资源接口的必要改动见 [源码核对](docs/author-source.md)。

当前仅保留作者源码 PD；此前自写 MCTS、v9 适配 PD、对手采样／风险模型和训练脚本已删除。历史代码与旧报告可通过 upstream-pd-v10 标签回溯。作者原组件的完整 2³ 消融见 [当前消融报告](docs/author-ablation.md)。

- 默认或 --original-pd：作者 PD 基线。
- --original-all：作者 PD＋MST＋IS＋MDTT。
- 分别指定 --merge-solitary、--importance、--multidepth 开启对应原组件。

Python 窗口的人机对局和持续记录分析使用当前默认后端。思考时间为 1／3／8 秒，随时调整、下一次决策生效，按本机逻辑处理器数选择根树并行（本机最多 32），并保留 MST／IS／MDTT 开关；作者吃碰杠响应保留一次 FlatMC 决策。纯前端 WASM 牌桌默认使用单线程内核，固定标准档。见 [WASM 发布说明](docs/wasm-release.md)。

## 已确认规则

- 34 种牌，各四张；无花牌和赤牌。
- 普通型四组顺／刻（杠按一组）加一对，无最低番要求，允许副露。
- 特殊番形：七对子、同色 `123 + 456 + 789` 的龙、岭上开花、十三幺。
- 每个付款方普通胡付 10；每个特殊番形分别翻倍；十三幺再额外翻一倍。因此普通胡 10，七对子／龙 20，龙＋岭上 40，十三幺 40。
- 点炮只有放铳者支付；自摸由另外三家各支付。
- 杠分每笔基础分为 10。点杠由提供杠牌者支付，暗杠由另外三家各付，加杠由原碰牌的供牌者支付。杠分立即结算。
- 对局中，庄家胡牌就续庄。只有闲家胡牌或流局时，由当前庄家的下家接庄。一炮多响只要庄家也胡牌就续庄。
- 庄家胡牌时，所有付款方在番形结算后各付双倍。庄家作为付款方时也付双倍，包括杠分。

尚待确认的地方细则：七对子是否允许四张相同牌算两对、龙是否允许吃出、抢杠胡、一炮多响、过胡限制及留牌／补牌。当前七对子默认七种不同对子，可通过 `Rules::quad_counts_as_two_pairs`（CLI `--quad-pairs`）切换；GUI 暂用约定详见页面“规则”。

## 本次实现范围

- C++17，直接编译随仓库附带的作者代码；原生运行不需要 Python 之外的额外服务。
- 合法手牌校验，普通型／七对子／十三幺向听数（胡牌 -1、听牌 0），按剩余张数计算进张。
- 完整拆牌确认龙，避免把“有一到九”误判为龙；支持固定吃碰杠副露。
- 四人零和支付函数：胡牌、番形叠加、各类杠及累计余额。
- 作者 PD 树搜索弃牌与原版 FlatMC 吃碰杠决策；提供候选访问次数、乐观和牌率及物理树深度。
- 原生 CLI、C ABI 和 Emscripten 构建目标。新 C ABI `alphamah_search_table` 和 CLI 支持完整公开桌面；旧闭手与公开信息接口保持兼容。

**评价口径**：默认 `meowcats_upstream_pd_v10` 采用作者乐观和牌率模型，不模拟他家和牌或防守，也不按番分／杠分重新设计搜索回报。实际对局仍由地方规则裁判结算。界面展示的是乐观模型估计，不能当作实战和牌概率或预计净分；无样本时显示横线。已知牌用于未见牌池，隐藏的实际牌山与对手暗手不交给搜索。

## 本地构建

需要已有的 C++17 编译器、CMake（3.20 以上）和 Ninja；不自动下载工具。以工具已在 PATH 为例：

```powershell
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build
ctest --test-dir build --output-on-failure
.\build\alphamah_cli.exe --hand '123m123p123s11z22z3z' --samples 128 --draws 18 --seed 1
```

也可向 CMake 传入 `-DCMAKE_CXX_COMPILER=完整路径` 和 `-DCMAKE_MAKE_PROGRAM=完整路径`，调用已有 IDE 附带的工具。使用 MinGW 时仍需把编译器的 `bin` 目录加入当前终端 PATH，以便编译器找到其运行库和子程序。原生 Windows CLI 静态链接 MinGW 运行库，运行产物不需要设置该路径。

牌表示：`m` 万、`p` 筒、`s` 索；`1z` 至 `7z` 依次为东南西北白发中。已知外部牌用 `--known '...'` 输入，包含所有牌河和其他玩家公开副露，不包含自己的暗手或副露。同一实体牌只能计入一次。为兼容旧参数，`--samples` 现为预算系数：总模拟数为系数乘以根动作数，再由 UCT 自适应分配，已不保证每个动作等量模拟；也可用 `--iterations 1000` 直接指定总数（至少覆盖全部根动作）。`--draws` 在 作者后端中不覆盖原期限表逻辑；有实际牌山信息时按原版自动期限计算。

CLI stdout 为 JSON，stderr 为诊断与运行时间。`ukeire` 是未见牌池中能降低最小向听数的牌张数，听牌时即和牌张数；这是精算展示，不额外用于改写作者选点规则。源码版按共享访问数最大推荐，同访问数取作者原顺序最后者。MDTT 共享计数可能使根候选访问数之和超过外层迭代数。统一输出中尚未映射的 ESS 等字段不能按零解释为关闭机制。

## WASM 目标

已有 Emscripten 时可构建：

```powershell
emcmake cmake -S . -B build-wasm -G Ninja -DCMAKE_BUILD_TYPE=Release -DALPHAMAH_BUILD_TESTS=OFF
cmake --build build-wasm
```

产物为 ES module `alphamah.js` 和 `alphamah.wasm`，在 Worker 中加载。本机使用现有 D:/sdkdata/emsdk（6.0.13），重新构建双版本发布包运行 `powershell -ExecutionPolicy Bypass -File scripts/build-wasm.ps1`。已验证真实多线程、单线程与完整牌局。C ABI 定义见 `include/alphamah/api.h`，不把 C++ 对象布局暴露给 JavaScript。

## 研究依据

- [MeowCaTS 代码](https://github.com/fight5566jay/MeowCaTS_1.0)
- [Applying Importance Sampling to MCTS for Mahjong](https://doi.org/10.1109/TG.2025.3535740)
- [Information Set Monte Carlo Tree Search](https://doi.org/10.1109/TCIAIG.2012.2200894)
- [Building a Computer Mahjong Player Based on Monte Carlo Simulation and Opponent Models](https://doi.org/10.1109/CIG.2015.7317929)

当前版本直接复用作者代码，保留 [LGPL-2.1 许可](vendor/meowcats/LICENSE)与原有第三方声明；来源、规范化原文哈希及所有导入差异随仓库保存。旧适配版已从当前源码删除。对照结论限于本项目规则、对手和预算，不沿用论文比赛的牌力评级。
