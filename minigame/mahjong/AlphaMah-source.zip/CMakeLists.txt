cmake_minimum_required(VERSION 3.20)
project(AlphaMah VERSION 0.1.0 LANGUAGES CXX)

option(ALPHAMAH_BUILD_TESTS "Build native core tests" ON)
option(ALPHAMAH_WASM_THREADS "Enable browser pthread root trees" OFF)
option(ALPHAMAH_PROFILE "Instrument inclusive kernel timings for development" OFF)
option(ALPHAMAH_IPO "Enable supported native interprocedural optimization" OFF)
if(ALPHAMAH_IPO)
  include(CheckIPOSupported)
  check_ipo_supported(RESULT ipo_supported OUTPUT ipo_error)
  if(NOT ipo_supported)
    message(FATAL_ERROR "IPO unavailable: ${ipo_error}")
  endif()
  set(CMAKE_INTERPROCEDURAL_OPTIMIZATION ON)
endif()
add_library(alphamah STATIC src/tiles.cpp src/hand.cpp src/scoring.cpp src/observation.cpp src/result.cpp src/simulation.cpp src/winning_subsets.cpp src/dispatch.cpp src/api.cpp)
target_include_directories(alphamah PUBLIC include)
target_compile_features(alphamah PUBLIC cxx_std_17)
set(MEOW vendor/meowcats)
target_include_directories(alphamah PRIVATE ${MEOW})
if(EMSCRIPTEN)
  target_compile_definitions(alphamah PRIVATE ALPHAMAH_MEOW_CONFIG="/meowcats.ini")
else()
  target_compile_definitions(alphamah PRIVATE ALPHAMAH_MEOW_CONFIG="${CMAKE_CURRENT_SOURCE_DIR}/${MEOW}/host.ini")
endif()
target_sources(alphamah PRIVATE src/upstream_search.cpp
  ${MEOW}/MctsLibrary/Mcts2.cpp ${MEOW}/MctsLibrary/BaseTree2.cpp
  ${MEOW}/MctsLibrary/ChanceNode2.cpp ${MEOW}/MctsLibrary/ExplorationTermTable.cpp
  ${MEOW}/MJLibrary/Base/Tools.cpp ${MEOW}/MJLibrary/Base/Ini.cpp
  ${MEOW}/MJLibrary/Base/SGF.cpp ${MEOW}/MJLibrary/Base/DebugLogger.cpp
  ${MEOW}/MJLibrary/MJ_Base/Tile.cpp ${MEOW}/MJLibrary/MJ_Base/HandTile.cpp
  ${MEOW}/MJLibrary/MJ_Base/PlayerTile.cpp ${MEOW}/MJLibrary/MJ_Base/MeldTile.cpp
  ${MEOW}/MJLibrary/MJ_Base/Move.cpp ${MEOW}/MJLibrary/MJ_Base/RemainTile.cpp
  ${MEOW}/MJLibrary/MJ_Base/MJStateHashKeyCalculator.cpp
  ${MEOW}/MJLibrary/MJ_Base/HandTileDecomposer.cpp
  ${MEOW}/MJLibrary/MJ_Base/TilePartCombination/TilePart.cpp
  ${MEOW}/SamplingLibrary/SamplingData/BaseSamplingData.cpp
  ${MEOW}/SamplingLibrary/SamplingData/GodMoveSamplingData.cpp
  ${MEOW}/SamplingLibrary/GodMoveSampling_v3.cpp ${MEOW}/SamplingLibrary/DrawCountTable.cpp
  ${MEOW}/MJLibrary/Base/SgfManager.cpp)
if(ALPHAMAH_PROFILE)
  target_compile_definitions(alphamah PUBLIC ALPHAMAH_PROFILE)
endif()
if(MSVC)
  target_compile_options(alphamah PRIVATE /W4 /utf-8)
else()
  target_compile_options(alphamah PRIVATE -Wall -Wextra -Wpedantic)
endif()
if(NOT EMSCRIPTEN)
  find_package(Threads REQUIRED)
  target_link_libraries(alphamah PUBLIC Threads::Threads)
endif()

if(EMSCRIPTEN)
  add_executable(alphamah_wasm src/wasm_main.cpp)
  target_link_libraries(alphamah_wasm PRIVATE alphamah)
  set_target_properties(alphamah_wasm PROPERTIES OUTPUT_NAME alphamah SUFFIX .js)
  target_link_options(alphamah_wasm PRIVATE
    --no-entry -fexceptions -sMODULARIZE=1 -sEXPORT_ES6=1 -sENVIRONMENT=worker
    "--embed-file=${CMAKE_CURRENT_SOURCE_DIR}/${MEOW}/host.ini@/meowcats.ini"
    -sALLOW_MEMORY_GROWTH=1
    "-sEXPORTED_FUNCTIONS=['_alphamah_hints','_alphamah_evaluate','_alphamah_search_timed','_alphamah_search','_alphamah_search_public','_alphamah_search_table','_malloc','_free']"
    "-sEXPORTED_RUNTIME_METHODS=['cwrap','UTF8ToString']")
  target_compile_options(alphamah PRIVATE -fexceptions)
  if(ALPHAMAH_WASM_THREADS)
    target_compile_options(alphamah PUBLIC -pthread)
    target_link_options(alphamah_wasm PRIVATE -pthread -sPTHREAD_POOL_SIZE=4 -sSTACK_SIZE=2097152 -sDEFAULT_PTHREAD_STACK_SIZE=2097152)
  endif()
else()
  add_executable(alphamah_cli src/main.cpp)
  target_link_libraries(alphamah_cli PRIVATE alphamah)
  add_executable(alphamah_web_engine src/web_engine.cpp)
  target_link_libraries(alphamah_web_engine PRIVATE alphamah)
  add_executable(alphamah_lab lab/lab.cpp)
  target_link_libraries(alphamah_lab PRIVATE alphamah)
  if(MINGW)
    target_link_options(alphamah_cli PRIVATE -static)
    target_link_options(alphamah_web_engine PRIVATE -static)
    target_link_options(alphamah_lab PRIVATE -static)
  endif()
  if(ALPHAMAH_BUILD_TESTS)
    enable_testing()
    add_executable(alphamah_tests tests/core_tests.cpp)
    target_link_libraries(alphamah_tests PRIVATE alphamah)
    if(MINGW)
      target_link_options(alphamah_tests PRIVATE -static)
    endif()
    add_test(NAME core COMMAND alphamah_tests)
    add_executable(alphamah_simulation_tests tests/simulation_tests.cpp)
    target_link_libraries(alphamah_simulation_tests PRIVATE alphamah)
    if(MINGW)
      target_link_options(alphamah_simulation_tests PRIVATE -static)
    endif()
    add_test(NAME simulation COMMAND alphamah_simulation_tests)
    add_executable(alphamah_upstream_tests tests/upstream_tests.cpp)
    target_include_directories(alphamah_upstream_tests PRIVATE ${MEOW})
    target_link_libraries(alphamah_upstream_tests PRIVATE alphamah)
    if(MINGW)
      target_link_options(alphamah_upstream_tests PRIVATE -static)
    endif()
    add_test(NAME upstream COMMAND alphamah_upstream_tests)
  endif()
endif()
