param([string]$Journal)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$nativePython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $nativePython)) { throw 'Project .venv is required.' }
if ($Journal) { & $nativePython (Join-Path $PSScriptRoot 'gui\desktop.py') --journal $Journal }
else { & $nativePython (Join-Path $PSScriptRoot 'gui\desktop.py') }
