#include "alphamah/winning_subsets.hpp"
#include <unordered_map>
namespace alphamah::paper {
namespace {
constexpr int orphan_tiles[]={0,8,9,17,18,26,27,28,29,30,31,32,33};
class Subsets {
    std::unordered_map<unsigned,unsigned> cache;
    unsigned groups(unsigned code,bool honors) {
        const unsigned key=code|(honors ? 1u<<31 : 0);
        auto found=cache.find(key); if (found!=cache.end()) return found->second;
        if (!code) return 1;
        int first=0; while (!((code>>(3*first))&7u)) ++first;
        unsigned unit=1u<<(3*first), count=(code>>(3*first))&7u;
        unsigned result=groups(code-unit,honors); // Optimistically discard this unused tile.
        if (count>=2) result|=(groups(code-2*unit,honors)&0x155u)<<1;
        if (count>=3) result|=groups(code-3*unit,honors)<<2;
        if (!honors && first<=6 && ((code>>(3*(first+1)))&7u) && ((code>>(3*(first+2)))&7u))
            result|=groups(code-unit-(unit<<3)-(unit<<6),false)<<2;
        return cache.emplace(key,result&0x3ffu).first->second;
    }
public:
    bool wins(const Hand& hand,Rules rules) {
        if (hand.melds.empty()) {
            int pairs=0; bool all=true, pair=false;
            for (auto n:hand.concealed) pairs+=rules.quad_counts_as_two_pairs ? n/2 : n>=2;
            if (pairs>=7) return true;
            for (int t:orphan_tiles) { all&=hand.concealed[t]>0; pair|=hand.concealed[t]>=2; }
            if (all && pair) return true;
        }
        int need=4-int(hand.melds.size()); if (need<0) return false;
        unsigned possible=1;
        for (int suit=0;suit<4;++suit) {
            unsigned code=0;
            for (int r=0;r<(suit==3 ? 7 : 9);++r) code|=unsigned(hand.concealed[suit*9+r])<<(3*r);
            unsigned part=groups(code,suit==3), next=0;
            for (int a=0;a<=need;++a) for (int p=0;p<2;++p) if ((possible>>(2*a+p))&1u)
                for (int b=0;b+a<=need;++b) for (int q=0;q+p<2;++q) if ((part>>(2*b+q))&1u)
                    next|=1u<<(2*(a+b)+p+q);
            possible=next;
        }
        return (possible>>(2*need+1))&1u;
    }
};
}
namespace { thread_local Subsets* active_subsets=nullptr; }
struct SubsetContext::Impl {
    Subsets cache;
    Subsets* previous=active_subsets;
    Impl() { active_subsets=&cache; }
    ~Impl() { active_subsets=previous; }
};
SubsetContext::SubsetContext():impl(std::make_unique<Impl>()) {}
SubsetContext::~SubsetContext()=default;
bool contains_win(const Hand& available,Rules rules) {
    if(active_subsets) return active_subsets->wins(available,rules);
    Subsets checker; return checker.wins(available,rules);
}

}
