#include "alphamah/core.hpp"
#include <numeric>
#include <stdexcept>

namespace alphamah {
namespace {
void seat(int player) {
    if (player < 0 || player >= 4) throw std::invalid_argument("Player must be 0-3");
}
Payments transfer(int winner, int source, int amount) {
    seat(winner);
    Payments payments{};
    if (source == -1) {
        for (int p = 0; p < 4; ++p) if (p != winner) {
            payments[p] -= amount;
            payments[winner] += amount;
        }
    } else {
        seat(source);
        if (source == winner) throw std::invalid_argument("Payer and receiver must differ");
        payments[source] -= amount;
        payments[winner] += amount;
    }
    return payments;
}
} // namespace

int payment_per_loser(const Patterns& p, WinContext context) {
    if (!p.winning()) throw std::invalid_argument("Cannot score a nonwinning hand");
    if ((p.pure_straight && !p.standard) || (p.thirteen_orphans && (p.standard || p.seven_pairs)))
        throw std::invalid_argument("Inconsistent winning patterns");
    int doubles = int(p.seven_pairs) + int(p.pure_straight)
                + int(context.replacement_draw) + 2 * int(p.thirteen_orphans);
    return 10 * (1 << doubles);
}

Payments settle_win(int winner, int discarder, const Patterns& p, WinContext context) {
    if (context.replacement_draw && discarder != -1)
        throw std::invalid_argument("Replacement-draw win must be self drawn");
    return transfer(winner, discarder, payment_per_loser(p, context));
}

Payments settle_kong(int player, const Meld& kong) {
    if (kong.tile < 0 || kong.tile >= tile_types) throw std::invalid_argument("Invalid kong tile");
    switch (kong.kind) {
    case MeldKind::ConcealedKong: return transfer(player, -1, 10);
    case MeldKind::OpenKong:
    case MeldKind::AddedKong:
        if (kong.source_player < 0) throw std::invalid_argument("Exposed kong needs its source player");
        return transfer(player, kong.source_player, 10);
    default: throw std::invalid_argument("Only kongs have kong payments");
    }
}

void apply_payments(Payments& balances, const Payments& payments) {
    if (std::accumulate(payments.begin(), payments.end(), 0) != 0)
        throw std::invalid_argument("Payments must sum to zero");
    for (int p = 0; p < 4; ++p) balances[p] += payments[p];
}
} // namespace alphamah
