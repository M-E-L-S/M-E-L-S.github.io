#include "alphamah/simulation.hpp"
#include "alphamah/profile.hpp"
#include <algorithm>
#include <cmath>
#include <numeric>
#include <stdexcept>

namespace alphamah {
unsigned random_bounded(std::mt19937& rng, unsigned size) {
    if (!size) throw std::logic_error("Empty random choice");
    unsigned threshold=(0u-size)%size, value;
    do { value=rng(); } while (value<threshold);
    return value%size;
}
bool same_action(const Action& a,const Action& b) {
    return a.kind==b.kind && a.tile==b.tile && a.sequence_start==b.sequence_start && a.meld_index==b.meld_index;
}
namespace {
void event(TableState& s,int kind,int player,int tile=-1,int extra=-1) {
    s.events.push_back(static_cast<char>(kind)); s.events.push_back(static_cast<char>(player));
    s.events.push_back(static_cast<char>(tile+1)); s.events.push_back(static_cast<char>(extra+1));
}
void pay(TableState& s,const Payments& payment) {
    apply_payments(s.scores,payment);
    for (int p=0;p<4;++p) { s.income[p]+=std::max(0,payment[p]); s.loss[p]+=std::max(0,-payment[p]); }
}
void request_draw(TableState& s,int player,bool replacement) {
    s.phase=RoundPhase::NeedDraw; s.draw_actor=player; s.draw_replacement=replacement;
}
void begin_response(TableState& s,int source,int tile,bool robbery) {
    s.phase=RoundPhase::Response; s.source=source; s.offered=tile; s.robbery=robbery;
    s.response_offset=1; s.actor=(source+1)%4; s.responses={};
    s.response_done=1u<<source;
}
void resolve(TableState& s,Evaluator& evaluator) {
    unsigned winners=0;
    for (int p=0;p<4;++p) if (p!=s.source && s.responses[p].kind==ActionKind::Win) {
        Hand won=s.hands[p]; ++won.concealed[s.offered];
        auto patterns=evaluator.patterns(won);
        if (!patterns.winning()) throw std::logic_error("Illegal simulated ron");
        pay(s,settle_win(p,s.source,patterns)); winners|=1u<<p;
    }
    if (winners) { s.winners=winners; s.phase=RoundPhase::Terminal; event(s,20,s.source,s.offered,winners); return; }
    if (s.robbery) {
        auto& hand=s.hands[s.source];
        auto meld=std::find_if(hand.melds.begin(),hand.melds.end(),[&](const Meld& m){return m.kind==MeldKind::Triplet && m.tile==s.offered;});
        if (meld==hand.melds.end() || !hand.concealed[s.offered]) throw std::logic_error("Missing added kong");
        --hand.concealed[s.offered]; meld->kind=MeldKind::AddedKong;
        pay(s,settle_kong(s.source,*meld)); event(s,14,s.source,s.offered);
        request_draw(s,s.source,true); return;
    }
    int caller=-1, priority=10;
    for (int offset=1;offset<=3;++offset) {
        int p=(s.source+offset)%4; auto kind=s.responses[p].kind;
        int rank=kind==ActionKind::Pon || kind==ActionKind::Kong ? 0 : kind==ActionKind::Chi ? 1 : 10;
        if (rank<priority) { priority=rank; caller=p; }
    }
    if (caller<0) { request_draw(s,(s.source+1)%4,false); return; }
    if (s.rivers[s.source].empty() || s.rivers[s.source].back().tile!=s.offered) throw std::logic_error("Missing called discard");
    s.rivers[s.source].back().claimed=true;
    auto a=s.responses[caller]; auto& hand=s.hands[caller];
    if (a.kind==ActionKind::Chi) {
        for (int t=a.sequence_start;t<a.sequence_start+3;++t) if (t!=s.offered) --hand.concealed[t];
        hand.melds.push_back({MeldKind::Sequence,a.sequence_start,s.source});
    } else {
        hand.concealed[s.offered]-=a.kind==ActionKind::Kong ? 3 : 2;
        hand.melds.push_back({a.kind==ActionKind::Kong ? MeldKind::OpenKong : MeldKind::Triplet,s.offered,s.source});
    }
    event(s,10+static_cast<int>(a.kind),caller,s.offered,a.sequence_start);
    if (a.kind==ActionKind::Kong) {
        pay(s,settle_kong(caller,hand.melds.back())); request_draw(s,caller,true);
    } else {
        s.phase=RoundPhase::Turn; s.actor=caller; s.replacement=false; s.allow_kong=false; s.last_draw=-1;
    }
}
Hand after_call(const Hand& before,const Action& a,int source) {
    Hand hand=before;
    if (a.kind==ActionKind::Chi) {
        for (int t=a.sequence_start;t<a.sequence_start+3;++t) if (t!=a.tile) --hand.concealed[t];
        hand.melds.push_back({MeldKind::Sequence,a.sequence_start,source});
    } else if (a.kind==ActionKind::Pon || a.kind==ActionKind::Kong) {
        hand.concealed[a.tile]-=a.kind==ActionKind::Pon ? 2 : 3;
        hand.melds.push_back({a.kind==ActionKind::Pon ? MeldKind::Triplet : MeldKind::OpenKong,a.tile,source});
    } else if (a.kind==ActionKind::ConcealedKong) {
        hand.concealed[a.tile]-=4; hand.melds.push_back({MeldKind::ConcealedKong,a.tile,-1});
    } else if (a.kind==ActionKind::AddedKong) {
        --hand.concealed[a.tile]; hand.melds[a.meld_index].kind=MeldKind::AddedKong;
    }
    return hand;
}
// The policy accepts only an actor's observation. There is no TableState/hidden-hand argument.
double hand_quality(Evaluator& evaluator,const Hand& hand,const Counts& unseen) {
    int d=evaluator.distance(hand).best();
    int copies=0;
    if (d<=1) {
        auto mask=evaluator.improving_mask(hand);
        for (int t=0;t<34;++t) if ((mask>>t)&1u) copies+=unseen[t];
    } else {
        // Cheap public-information tie-break for self-play generation and rollout.
        auto physical=physical_tiles(hand);
        for (int t=0;t<34;++t) if (unseen[t] && physical[t]<4) {
            bool useful=hand.concealed[t]>0;
            if (t<27) for (int offset=-2;offset<=2;++offset) {
                int other=t+offset;
                if (other>=0 && other<27 && other/9==t/9 && hand.concealed[other]) useful=true;
            }
            if (useful) copies+=unseen[t];
        }
    }
    return -12.0*d+std::log1p(copies);
}
double best_after_discard(Evaluator& evaluator,Hand hand,const Counts& unseen) {
    int minimum=99;
    for (int t=0;t<34;++t) if (hand.concealed[t]) {
        --hand.concealed[t]; minimum=std::min(minimum,evaluator.distance(hand).best()); ++hand.concealed[t];
    }
    double best=-1e9;
    for (int t=0;t<34;++t) if (hand.concealed[t]) {
        --hand.concealed[t];
        if (evaluator.distance(hand).best()==minimum) best=std::max(best,hand_quality(evaluator,hand,unseen));
        ++hand.concealed[t];
    }
    return best;
}
}

TableState deal_round(std::uint32_t seed,int dealer) {
    if (dealer<0 || dealer>3) throw std::invalid_argument("Invalid dealer");
    TableState s; std::mt19937 rng(seed);
    for (int t=0;t<34;++t) for (int i=0;i<4;++i) s.wall.push_back(t);
    for (std::size_t i=s.wall.size();i>1;--i) std::swap(s.wall[i-1],s.wall[random_bounded(rng,static_cast<unsigned>(i))]);
    for (int n=0;n<13;++n) for (int p=0;p<4;++p) { ++s.hands[p].concealed[s.wall.back()]; s.wall.pop_back(); }
    request_draw(s,dealer,false); round_draw(s); return s;
}
Observation observe(const TableState& s,int player) {
    ProfileScope profile(3);
    if (player<0 || player>3) throw std::invalid_argument("Invalid observer");
    Observation o; o.player=player; o.hand=s.hands[player]; o.remaining_wall=static_cast<int>(s.wall.size());
    o.has_public_table=true; o.rivers=s.rivers;
    o.allow_self_kong=s.allow_kong;
    if (s.phase==RoundPhase::Turn && s.actor==player) o.current_draw.replacement_draw=s.replacement;
    if (s.phase==RoundPhase::Response && player!=s.source) {
        o.offered_tile=s.offered; o.source_player=s.source; o.robbing_kong=s.robbery;
    }
    for (const auto& river:s.rivers) for (const auto& discard:river) if (!discard.claimed) ++o.known_outside[discard.tile];
    if (s.phase==RoundPhase::Response && s.robbery && player!=s.source) ++o.known_outside[s.offered];
    for (int p=0;p<4;++p) if (p!=player) {
        PublicOpponent public_hand; public_hand.player=p;
        for (const auto& meld:s.hands[p].melds) {
            if (meld.kind==MeldKind::ConcealedKong) ++public_hand.concealed_kongs;
            else {
                public_hand.melds.push_back(meld);
                auto tiles=physical_tiles({{}, {meld}});
                for (int t=0;t<34;++t) o.known_outside[t]+=tiles[t];
            }
        }
        for (const auto& discard:s.rivers[p]) public_hand.discards.push_back(discard.tile);
        o.opponents.push_back(public_hand);
    }
    return o;
}
std::vector<Action> legal_actions(const Observation& o) { Evaluator e; return round_legal_actions(o,e); }
std::vector<Action> round_legal_actions(const Observation& o,Evaluator& e) {
    std::vector<Action> result; const auto& hand=o.hand;
    if (o.offered_tile>=0) {
        Hand won=hand;
        auto own=physical_tiles(hand);
        if (own[o.offered_tile]<4 && e.distance(hand).best()==0) {
            ++won.concealed[o.offered_tile];
            if (e.distance(won).best()==-1) result.push_back({ActionKind::Win,o.offered_tile});
        }
        result.push_back({ActionKind::Pass});
        if (o.robbing_kong) return result;
        int tile=o.offered_tile;
        if (hand.concealed[tile]>=2) result.push_back({ActionKind::Pon,tile});
        if (hand.concealed[tile]>=3 && o.remaining_wall>0) result.push_back({ActionKind::Kong,tile});
        if ((o.source_player+1)%4==o.player && tile<27) for (int first=std::max(tile/9*9,tile-2);first<=std::min(tile,tile/9*9+6);++first) {
            bool possible=true;
            for (int t=first;t<first+3;++t) if (t!=tile && !hand.concealed[t]) possible=false;
            if (possible) result.push_back({ActionKind::Chi,tile,first});
        }
    } else {
        if (e.distance(hand).best()==-1) result.push_back({ActionKind::Win});
        for (int t=0;t<34;++t) if (hand.concealed[t]) {
            result.push_back({ActionKind::Discard,t});
            if (hand.concealed[t]==4 && o.allow_self_kong && o.remaining_wall>0) result.push_back({ActionKind::ConcealedKong,t});
        }
        if (o.allow_self_kong && o.remaining_wall>0) for (std::size_t i=0;i<hand.melds.size();++i)
            if (hand.melds[i].kind==MeldKind::Triplet && hand.concealed[hand.melds[i].tile])
                result.push_back({ActionKind::AddedKong,hand.melds[i].tile,-1,static_cast<int>(i)});
    }
    return result;
}
Action public_policy(const Observation& o,Evaluator& e,std::mt19937& rng,double random_rate) {
    ProfileScope profile(2);
    auto choices=round_legal_actions(o,e);
    if (choices.empty()) throw std::logic_error("No public policy action");
    if (choices.front().kind==ActionKind::Win) return choices.front();
    if (choices.size()==1) return choices.front();
    if (random_rate>0 && double(random_bounded(rng,10000))/10000<random_rate)
        return choices[random_bounded(rng,static_cast<unsigned>(choices.size()))];
    auto unseen=unseen_tiles(o); double best=-1e9; std::vector<Action> ties;
    // Distance-only prefilter is an offense rollout policy, not the MCTS action set.
    int minimum=99;
    if (o.offered_tile<0) for (auto a:choices) {
        Hand hand=a.kind==ActionKind::Discard ? o.hand : after_call(o.hand,a,o.source_player);
        if (a.kind==ActionKind::Discard) --hand.concealed[a.tile];
        minimum=std::min(minimum,e.distance(hand).best());
    }
    for (auto a:choices) {
        double value;
        if (a.kind==ActionKind::Pass) value=hand_quality(e,o.hand,unseen)+0.02;
        else if (a.kind==ActionKind::Discard) {
            Hand hand=o.hand; --hand.concealed[a.tile];
            if (e.distance(hand).best()!=minimum) continue;
            value=hand_quality(e,hand,unseen);
        } else {
            Hand hand=after_call(o.hand,a,o.source_player);
            value=a.kind==ActionKind::Chi || a.kind==ActionKind::Pon ? best_after_discard(e,hand,unseen) : hand_quality(e,hand,unseen)+0.5;
        }
        if (value>best+1e-9) { best=value; ties.clear(); }
        if (std::abs(value-best)<1e-9) ties.push_back(a);
    }
    return ties[random_bounded(rng,static_cast<unsigned>(ties.size()))];
}
void round_act(TableState& s,const Action& a,Evaluator& e) {
    if (s.phase!=RoundPhase::Turn && s.phase!=RoundPhase::Response) throw std::logic_error("Round is not awaiting a decision");
    int player=s.actor; auto& hand=s.hands[player]; ++s.actions;
    if (s.phase==RoundPhase::Response) {
        s.responses[player]=a;
        s.response_done|=1u<<player;
        if (s.response_done==15) resolve(s,e);
        else for (int offset=1;offset<=3;++offset) {
            int next=(s.source+offset)%4;
            if (!(s.response_done&(1u<<next))) { s.actor=next; break; }
        }
        return;
    }
    switch (a.kind) {
    case ActionKind::Win: {
        auto patterns=e.patterns(hand);
        pay(s,settle_win(player,-1,patterns,{s.replacement}));
        s.winners=1u<<player; s.source=-1; s.phase=RoundPhase::Terminal; event(s,21,player,s.last_draw); break;
    }
    case ActionKind::Discard:
        if (a.tile<0 || a.tile>=34 || !hand.concealed[a.tile]) throw std::logic_error("Invalid simulated discard");
        --hand.concealed[a.tile]; s.rivers[player].push_back({a.tile,false});
        event(s,1,player,a.tile); begin_response(s,player,a.tile,false); break;
    case ActionKind::ConcealedKong:
        hand=after_call(hand,a,-1); pay(s,settle_kong(player,hand.melds.back()));
        event(s,15,player,player==s.observer ? a.tile : -1); request_draw(s,player,true); break;
    case ActionKind::AddedKong:
        event(s,16,player,a.tile); begin_response(s,player,a.tile,true); break;
    default: throw std::logic_error("Invalid turn action");
    }
}
bool round_draw(TableState& s,int observer,int max_draws) {
    if (s.phase!=RoundPhase::NeedDraw) return false;
    if (s.wall.empty()) { s.phase=RoundPhase::Terminal; event(s,22,s.draw_actor); return false; }
    if (s.draw_actor==observer && s.draws[observer]>=max_draws) { s.phase=RoundPhase::Truncated; return false; }
    int tile=s.draw_replacement ? s.wall.front() : s.wall.back();
    if (s.draw_replacement) s.wall.erase(s.wall.begin()); else s.wall.pop_back();
    s.actor=s.draw_actor; s.last_draw=tile; s.replacement=s.draw_replacement; s.allow_kong=true;
    ++s.hands[s.actor].concealed[tile]; ++s.draws[s.actor]; s.phase=RoundPhase::Turn;
    event(s,2,s.actor,s.actor==s.observer ? tile : -1,s.replacement); return true;
}
void validate_table(const TableState& s) {
    std::array<int,34> total{};
    for (int tile:s.wall) { if (tile<0 || tile>=34) throw std::logic_error("Bad wall tile"); ++total[tile]; }
    for (int p=0;p<4;++p) {
        auto physical=physical_tiles(s.hands[p]);
        for (int t=0;t<34;++t) total[t]+=physical[t];
        for (const auto& discard:s.rivers[p]) {
            if (discard.tile<0 || discard.tile>=34) throw std::logic_error("Bad river tile");
            if (!discard.claimed) ++total[discard.tile];
        }
        bool after_draw=s.phase==RoundPhase::Turn && s.actor==p;
        // During an added-kong robbery window the source still owns its fourth tile.
        after_draw|=s.phase==RoundPhase::Response && s.robbery && s.source==p;
        if (s.phase!=RoundPhase::Terminal) validate_hand(s.hands[p],after_draw);
    }
    for (int count:total) if (count!=4) throw std::logic_error("Simulated table does not conserve 136 tiles");
    if (std::accumulate(s.scores.begin(),s.scores.end(),0)!=0) throw std::logic_error("Scores are not zero sum");
}
} // namespace alphamah
