#include "alphamah/core.hpp"
#include <sstream>
#include <stdexcept>

namespace alphamah {
namespace {
int number(const std::string& text) {
    std::size_t used = 0;
    int value = std::stoi(text, &used);
    if (used != text.size()) throw std::invalid_argument("Invalid integer field");
    return value;
}
std::vector<std::string> split(const std::string& text, char separator) {
    std::vector<std::string> parts;
    std::istringstream input(text); std::string part;
    while (std::getline(input, part, separator)) parts.push_back(part);
    return parts;
}
std::vector<Meld> melds(const std::string& text) {
    std::vector<Meld> result;
    if (text.empty() || text == "-") return result;
    for (const auto& item : split(text, '|')) {
        auto fields = split(item, ':');
        if (fields.size() != 3) throw std::invalid_argument("Invalid meld encoding");
        int kind = number(fields[0]);
        if (kind < 0 || kind > 4) throw std::invalid_argument("Invalid meld kind");
        result.push_back({static_cast<MeldKind>(kind), number(fields[1]), number(fields[2])});
    }
    return result;
}
}
Observation parse_observation(const std::string& hand, const std::string& declared,
                              const std::string& known, const std::string& context,
                              const std::string& opponents, bool replacement, const std::string& rivers) {
    Observation o;
    o.hand.concealed = parse_tiles(hand == "-" ? "" : hand);
    o.hand.melds = melds(declared);
    o.known_outside = parse_tiles(known == "-" ? "" : known);
    o.current_draw.replacement_draw = replacement;
    if (!context.empty() && context != "-") {
        auto fields = split(context, ':');
        if (fields.size() != 5 && fields.size() != 6) throw std::invalid_argument("Invalid search context");
        o.player = number(fields[0]); o.source_player = number(fields[1]);
        o.offered_tile = number(fields[2]); o.remaining_wall = number(fields[3]);
        int kong = number(fields[4]);
        if (kong != 0 && kong != 1) throw std::invalid_argument("Invalid kong permission");
        o.allow_self_kong = kong != 0;
        if (fields.size() == 6) {
            int rob = number(fields[5]);
            if (rob != 0 && rob != 1) throw std::invalid_argument("Invalid robbery flag");
            o.robbing_kong = rob != 0;
        }
    }
    if (!rivers.empty() && rivers != "-") {
        unsigned seats = 0;
        for (const auto& item : split(rivers,'/')) {
            auto fields=split(item,'~');
            if (fields.size()!=2) throw std::invalid_argument("Invalid public rivers");
            int player=number(fields[0]);
            if (player<0 || player>3 || (seats&(1u<<player))) throw std::invalid_argument("Invalid river seat");
            seats|=1u<<player;
            if (fields[1]!="-") for (const auto& discard:split(fields[1],',')) {
                auto entry=split(discard,':');
                if (entry.size()!=2) throw std::invalid_argument("Invalid public discard");
                int tile=number(entry[0]), claimed=number(entry[1]);
                if (tile<0 || tile>=34 || (claimed!=0 && claimed!=1)) throw std::invalid_argument("Invalid public discard");
                o.rivers[player].push_back({tile,claimed!=0});
            }
        }
        if (seats!=15) throw std::invalid_argument("All four public rivers are required");
        o.has_public_table=true;
    }
    if (!opponents.empty() && opponents != "-") for (const auto& item : split(opponents, '/')) {
        auto fields = split(item, '~');
        if (fields.size() != 4) throw std::invalid_argument("Invalid public opponent encoding");
        PublicOpponent p; p.player = number(fields[0]); p.concealed_kongs = number(fields[1]);
        p.melds = melds(fields[2]);
        auto river = parse_tiles(fields[3] == "-" ? "" : fields[3]);
        for (int t = 0; t < 34; ++t) for (int n = 0; n < river[t]; ++n) p.discards.push_back(t);
        o.opponents.push_back(p);
    }
    if (o.has_public_table) for (auto& opponent:o.opponents) {
        if (opponent.player<0 || opponent.player>3) throw std::invalid_argument("Invalid opponent seat");
        opponent.discards.clear();
        for (const auto& discard:o.rivers[opponent.player]) opponent.discards.push_back(discard.tile);
    }
    return o;
}
} // namespace alphamah
