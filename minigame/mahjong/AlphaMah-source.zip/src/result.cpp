#include "alphamah/simulation.hpp"
#include <sstream>
#include <iomanip>
#include <locale>
#include <stdexcept>
namespace alphamah {
const char* action_name(ActionKind k) {
    switch (k) {
    case ActionKind::Discard: return "discard";
    case ActionKind::Pass: return "pass";
    case ActionKind::Chi: return "chi";
    case ActionKind::Pon: return "pon";
    case ActionKind::Kong: return "kan";
    case ActionKind::ConcealedKong: return "ankan";
    case ActionKind::AddedKong: return "kakan";
    case ActionKind::Win: return "win";
    }
    throw std::invalid_argument("Invalid action kind");
}
std::string result_json(const SearchResult& result) {
    std::ostringstream out; out.imbue(std::locale::classic()); out << std::setprecision(10);
    const auto& a = result.recommended_action;
    out << "{\"model\":\"" << "meowcats_upstream_pd_v10" << "\",\"action\":\"" << action_name(a.kind) << '"';
    if (a.tile >= 0) out << ",\"tile\":\"" << tile_name(a.tile) << '"';
    out << ",\"sequence_start\":" << a.sequence_start << ",\"meld_index\":" << a.meld_index;
    if (result.win_now) out << ",\"gain_now\":" << result.gain_now;
    out << ",\"elapsed_ms\":" << result.elapsed_ms << ",\"workers\":" << result.workers
        << ",\"iterations\":" << result.iterations << ",\"tree_nodes\":" << result.tree_nodes
        << ",\"branching_decision_nodes\":" << result.branching_decision_nodes
        << ",\"max_decision_depth\":" << result.max_decision_depth
        << ",\"risk_model\":\"" << "disabled"
        << "\",\"belief_model\":\"" << "none"
        << "\",\"objective\":\"" << "paper_win_rate"
        << "\",\"world_samples\":" << result.world_samples << ",\"simulated_actions\":" << result.simulated_actions
        << ",\"importance_ess\":" << result.importance_ess << ",\"transposition_hits\":" << result.transposition_hits
        << ",\"importance_draws\":" << result.importance_draws << ",\"solitary_deferrals\":" << result.solitary_deferrals
        << ",\"short_horizon_captures\":" << result.short_horizon_captures
        << ",\"belief_acceptance\":" << result.belief_acceptance << ",\"risk_chain_standard_error\":" << result.risk_standard_error
        ;
    if (result.paper) out << ",\"paper_rollouts\":" << result.paper_rollouts << ",\"paper_cycle_skips\":" << result.paper_cycle_skips
        << ",\"paper_horizon_updates\":" << result.paper_horizon_updates << ",\"paper_chance_groups\":" << result.paper_chance_groups
        << ",\"paper_solitary_groups\":" << result.paper_solitary_groups
        << ",\"gain_estimate_kind\":\"30_times_optimistic_win_rate_plus_external_adjustments\"";
    out << ",\"opponents\":[";
    bool first_opponent = true;
    for (const auto& p : result.risk.opponents) {
        if (!first_opponent) out << ',';
        first_opponent = false;
        out << "{\"player\":" << p.player << ",\"tenpai_probability\":" << p.tenpai_probability
            << ",\"accepted_samples\":" << p.accepted_samples << ",\"exact_singleton\":" << (p.exact_singleton ? "true" : "false")
            << ",\"fallback\":" << (p.fallback ? "true" : "false") << ",\"tiles\":[";
        for (int t = 0; t < 34; ++t) {
            if (t) out << ',';
            out << "{\"tile\":\"" << tile_name(t) << "\",\"win_probability\":" << p.win_probability[t]
                << ",\"expected_payment\":" << p.expected_payment[t] << '}';
        }
        out << "]}";
    }
    out << "],\"candidates\":[";
    bool first = true;
    for (const auto& c : result.candidates) {
        if (!first) out << ',';
        first = false;
        out << "{\"action\":\"" << action_name(c.action.kind) << "\",\"discard\":";
        if (c.discard >= 0) out << '"' << tile_name(c.discard) << '"'; else out << "null";
        if(result.upstream_pd) out << ",\"followup_discard\":" << c.followup_discard;
        out << ",\"tile\":";
        if (c.action.tile >= 0) out << '"' << tile_name(c.action.tile) << '"'; else out << "null";
        out << ",\"sequence_start\":" << c.action.sequence_start << ",\"meld_index\":" << c.action.meld_index
            << ",\"shanten\":" << c.efficiency.distance.best()
            << ",\"standard_shanten\":" << c.efficiency.distance.standard
            << ",\"seven_pairs_shanten\":" << c.efficiency.distance.seven_pairs
            << ",\"thirteen_orphans_shanten\":" << c.efficiency.distance.thirteen_orphans
            << ",\"ukeire\":" << c.efficiency.improving_copies << ",\"winning_value\":" << c.efficiency.winning_value
            << ",\"improving_tiles\":[";
        for (std::size_t i = 0; i < c.efficiency.improving_tiles.size(); ++i) {
            if (i) out << ',';
            out << '"' << tile_name(c.efficiency.improving_tiles[i]) << '"';
        }
        out << "],\"samples\":" << c.samples << ",\"wins\":" << c.wins
            << ",\"win_probability\":" << c.win_probability << ",\"expected_gain\":" << c.expected_gain
            << ",\"expected_loss\":" << c.expected_loss << ",\"deal_in_probability\":" << c.deal_in_probability
            << ",\"immediate_expected_loss\":" << c.immediate_expected_loss
            << ",\"continuation_value\":" << c.continuation_value << ",\"search_value\":" << c.search_value
            << ",\"mean_winning_draw\":" << c.mean_winning_draw << '}';
    }
    out << "]}"; return out.str();
}
} // namespace alphamah
