#include "alphamah/core.hpp"
#include <cctype>
#include <stdexcept>

namespace alphamah {

int tile_count(const Counts& tiles) {
    int total = 0;
    for (auto n : tiles) total += n;
    return total;
}

Counts parse_tiles(const std::string& notation) {
    Counts result{};
    std::string digits;
    for (unsigned char c : notation) {
        if (std::isspace(c)) {
            if (!digits.empty()) throw std::invalid_argument("A suit must follow each digit group");
            continue;
        }
        if (c >= '1' && c <= '9') { digits.push_back(static_cast<char>(c)); continue; }
        int offset;
        if (c == 'm') offset = 0;
        else if (c == 'p') offset = 9;
        else if (c == 's') offset = 18;
        else if (c == 'z') offset = 27;
        else throw std::invalid_argument("Use digits 1-9 followed by m/p/s, or 1-7 followed by z");
        if (digits.empty()) throw std::invalid_argument("Empty tile group");
        for (char d : digits) {
            if (c == 'z' && d > '7') throw std::invalid_argument("Honor rank must be 1-7");
            auto& n = result[offset + d - '1'];
            if (++n > 4) throw std::invalid_argument("More than four copies of a tile");
        }
        digits.clear();
    }
    if (!digits.empty()) throw std::invalid_argument("Missing suit after digits");
    return result;
}

std::string tile_name(int tile) {
    if (tile < 0 || tile >= tile_types) throw std::invalid_argument("Invalid tile id");
    return std::string(1, static_cast<char>('1' + tile % 9)) + "mpsz"[tile / 9];
}

std::string format_tiles(const Counts& tiles) {
    std::string out;
    for (int suit = 0; suit < 4; ++suit) {
        std::string group;
        const int ranks = suit == 3 ? 7 : 9;
        for (int rank = 0; rank < ranks; ++rank)
            group.append(tiles[suit * 9 + rank], static_cast<char>('1' + rank));
        if (!group.empty()) out += group + "mpsz"[suit];
    }
    return out;
}

Counts physical_tiles(const Hand& hand) {
    if (hand.melds.size() > 4) throw std::invalid_argument("At most four melds");
    Counts counts = hand.concealed;
    for (auto n : counts) if (n > 4) throw std::invalid_argument("Too many concealed copies");
    auto add = [&](int tile, int number) {
        if (tile < 0 || tile >= tile_types || counts[tile] + number > 4)
            throw std::invalid_argument("Invalid meld or more than four physical copies");
        counts[tile] = static_cast<std::uint8_t>(counts[tile] + number);
    };
    for (const Meld& meld : hand.melds) {
        switch (meld.kind) {
        case MeldKind::Sequence:
            if (meld.tile < 0 || meld.tile >= 27 || meld.tile % 9 > 6)
                throw std::invalid_argument("Invalid sequence");
            for (int j = 0; j < 3; ++j) add(meld.tile + j, 1);
            break;
        case MeldKind::Triplet: add(meld.tile, 3); break;
        case MeldKind::OpenKong:
        case MeldKind::ConcealedKong:
        case MeldKind::AddedKong: add(meld.tile, 4); break;
        default: throw std::invalid_argument("Invalid meld kind");
        }
    }
    return counts;
}

void validate_hand(const Hand& hand, bool after_draw) {
    physical_tiles(hand);
    int expected = (after_draw ? 14 : 13) - 3 * static_cast<int>(hand.melds.size());
    if (tile_count(hand.concealed) != expected)
        throw std::invalid_argument("Concealed tile count must be 13/14 minus three per meld");
}

Counts unseen_tiles(const Observation& observation) {
    Counts own = physical_tiles(observation.hand), unseen{};
    for (int i = 0; i < tile_types; ++i) {
        int known = own[i] + observation.known_outside[i];
        if (observation.known_outside[i] > 4 || known > 4)
            throw std::invalid_argument("Known and owned tiles exceed four copies");
        unseen[i] = static_cast<std::uint8_t>(4 - known);
    }
    return unseen;
}

} // namespace alphamah
