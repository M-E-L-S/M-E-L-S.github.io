#include "alphamah/core.hpp"
#include "alphamah/profile.hpp"
#include <algorithm>
#include <stdexcept>

namespace alphamah {
namespace {
constexpr int orphans[] = {0, 8, 9, 17, 18, 26, 27, 28, 29, 30, 31, 32, 33};

void standard_dfs(Counts& tiles, int start, int melds, int partials, int eyes,
                  std::uint64_t paired_partials, bool available_single,
                  const Counts& physical, int& best, int stop = -1) {
    if (best <= stop) return;
    while (start < tile_types && tiles[start] == 0) ++start;
    if (start == tile_types) {
        int value = 8 - 2 * melds - std::min(partials, 4 - melds) - int(eyes >= 0);
        // Without eyes, one isolated tile must have a physically possible mate.
        // Four complete groups + the fourth copy of a group tile is not tenpai.
        if (eyes < 0 && !available_single) ++value;
        best = std::min(best, value);
        return;
    }
    if (tiles[start] >= 3 && melds < 4) {
        tiles[start] -= 3;
        standard_dfs(tiles, start, melds + 1, partials, eyes, paired_partials, available_single, physical, best, stop);
        tiles[start] += 3;
    }
    bool sequence = start < 27 && start % 9 <= 6;
    if (sequence && melds < 4 && tiles[start + 1] && tiles[start + 2]) {
        --tiles[start]; --tiles[start + 1]; --tiles[start + 2];
        standard_dfs(tiles, start, melds + 1, partials, eyes, paired_partials, available_single, physical, best, stop);
        ++tiles[start]; ++tiles[start + 1]; ++tiles[start + 2];
    }
    if (tiles[start] >= 2) {
        tiles[start] -= 2;
        const auto bit = std::uint64_t(1) << start;
        if (eyes < 0 && !(paired_partials & bit))
            standard_dfs(tiles, start, melds, partials, start, paired_partials, available_single, physical, best, stop);
        // Two 11 groups cannot both be completed: that would require 5/6 copies.
        if (partials < 4 - melds && eyes != start && !(paired_partials & bit))
            standard_dfs(tiles, start, melds, partials + 1, eyes, paired_partials | bit, available_single, physical, best, stop);
        tiles[start] += 2;
    }
    if (start < 27 && partials < 4 - melds) {
        for (int gap = 1; gap <= 2; ++gap) {
            if (start % 9 + gap > 8 || !tiles[start + gap]) continue;
            --tiles[start]; --tiles[start + gap];
            standard_dfs(tiles, start, melds, partials + 1, eyes, paired_partials, available_single, physical, best, stop);
            ++tiles[start]; ++tiles[start + gap];
        }
    }
    --tiles[start];
    standard_dfs(tiles, start, melds, partials, eyes, paired_partials,
                 available_single || physical[start] < 4, physical, best, stop);
    ++tiles[start];
}

// Enumerate complete standard decompositions. A pure straight requires actual
// 123,456,789 sequence groups in one suit, including already declared sequences.
bool complete_dfs(Counts& tiles, int needed, bool pair,
                  std::array<unsigned, 3> sequences, bool& straight) {
    int tile = 0;
    while (tile < tile_types && !tiles[tile]) ++tile;
    if (tile == tile_types) {
        bool won = needed == 0 && pair;
        if (won) for (auto mask : sequences) if ((mask & 0x49u) == 0x49u) straight = true;
        return won;
    }
    bool won = false;
    if (!pair && tiles[tile] >= 2) {
        tiles[tile] -= 2;
        won |= complete_dfs(tiles, needed, true, sequences, straight);
        tiles[tile] += 2;
    }
    if (needed > 0 && tiles[tile] >= 3) {
        tiles[tile] -= 3;
        won |= complete_dfs(tiles, needed - 1, pair, sequences, straight);
        tiles[tile] += 3;
    }
    if (needed > 0 && tile < 27 && tile % 9 <= 6 && tiles[tile + 1] && tiles[tile + 2]) {
        --tiles[tile]; --tiles[tile + 1]; --tiles[tile + 2];
        sequences[tile / 9] |= 1u << (tile % 9);
        won |= complete_dfs(tiles, needed - 1, pair, sequences, straight);
        ++tiles[tile]; ++tiles[tile + 1]; ++tiles[tile + 2];
    }
    return won;
}

HandKey pack(const Hand& hand, const Counts& physical) {
    HandKey key;
    for (int i = 0; i < 21; ++i) {
        key.low |= std::uint64_t(hand.concealed[i]) << (3 * i);
        key.physical_low |= std::uint64_t(physical[i]) << (3 * i);
    }
    for (int i = 21; i < tile_types; ++i) {
        key.high |= std::uint64_t(hand.concealed[i]) << (3 * (i - 21));
        key.physical_high |= std::uint64_t(physical[i]) << (3 * (i - 21));
    }
    key.high |= std::uint64_t(hand.melds.size()) << 40;
    return key;
}
} // namespace

int Distance::best() const { return std::min({standard, seven_pairs, thirteen_orphans}); }
bool Patterns::winning() const { return standard || seven_pairs || thirteen_orphans; }
bool HandKey::operator==(const HandKey& other) const {
    return low == other.low && high == other.high && physical_low == other.physical_low
        && physical_high == other.physical_high;
}
std::size_t HandKeyHash::operator()(const HandKey& key) const {
    std::uint64_t h = key.low ^ (key.high + 0x9e3779b97f4a7c15ULL + (key.low << 6) + (key.low >> 2));
    h ^= key.physical_low + (h << 6) + (h >> 2);
    h ^= key.physical_high + (h << 6) + (h >> 2);
    h ^= h >> 30; h *= 0xbf58476d1ce4e5b9ULL; h ^= h >> 27;
    return static_cast<std::size_t>(h ^ (h >> 31));
}

Evaluator::Evaluator(Rules rules) : rules_(rules) {}

Distance Evaluator::distance(const Hand& hand) {
    ProfileScope profile(0);
    int count = tile_count(hand.concealed);
    bool after_draw = count == 14 - 3 * static_cast<int>(hand.melds.size());
    validate_hand(hand, after_draw);
    Counts physical = physical_tiles(hand);
    HandKey key = pack(hand, physical);
    auto found = cache_.find(key);
    if (found != cache_.end()) return found->second;
    Distance result;
    Counts tiles = hand.concealed;
    standard_dfs(tiles, 0, static_cast<int>(hand.melds.size()), 0, -1, 0, false, physical, result.standard);
    if (hand.melds.empty()) {
        int pairs = 0, distinct = 0;
        for (auto n : tiles) {
            distinct += n > 0;
            pairs += rules_.quad_counts_as_two_pairs ? n / 2 : n >= 2;
        }
        result.seven_pairs = 6 - pairs + (rules_.quad_counts_as_two_pairs ? 0 : std::max(0, 7 - distinct));
        int unique_orphans = 0;
        bool orphan_pair = false;
        for (int tile : orphans) {
            unique_orphans += tiles[tile] > 0;
            orphan_pair |= tiles[tile] >= 2;
        }
        result.thirteen_orphans = 13 - unique_orphans - int(orphan_pair);
    }
    // Bound local memo memory. This is not transposition sharing of search values.
    if (cache_.size() >= 100000) cache_.clear();
    cache_.emplace(key, result);
    return result;
}

Patterns Evaluator::patterns(const Hand& hand) {
    validate_hand(hand, true);
    Distance d = distance(hand);
    Patterns result;
    result.seven_pairs = d.seven_pairs == -1;
    result.thirteen_orphans = d.thirteen_orphans == -1;
    if (d.standard == -1) {
        Counts tiles = hand.concealed;
        std::array<unsigned, 3> sequences{};
        for (const Meld& meld : hand.melds)
            if (meld.kind == MeldKind::Sequence) sequences[meld.tile / 9] |= 1u << (meld.tile % 9);
        result.standard = complete_dfs(tiles, 4 - static_cast<int>(hand.melds.size()), false,
                                       sequences, result.pure_straight);
    }
    return result;
}

std::uint64_t Evaluator::improving_mask(const Hand& hand) {
    ProfileScope profile(1);
    validate_hand(hand, false);
    auto physical = physical_tiles(hand);
    auto key = pack(hand, physical);
    auto found = improving_cache_.find(key);
    if (found != improving_cache_.end()) return found->second;
    const int baseline = distance(hand).best();
    bool dead_single_possible=false;
    for (int t=0;t<34;++t) dead_single_possible|=hand.concealed[t]>0 && physical[t]==4;
    std::uint64_t mask = 0;
    Hand next = hand;
    for (int t = 0; t < tile_types; ++t) {
        if (physical[t] == 4) continue;
        ++next.concealed[t]; ++physical[t];
        auto cached = cache_.find(pack(next, physical));
        bool improved = cached != cache_.end() && cached->second.best() < baseline;
        if (cached == cache_.end()) {
            if (hand.melds.empty()) {
                int pairs = 0, distinct = 0, unique_orphans = 0;
                bool orphan_pair = false;
                for (auto n : next.concealed) {
                    pairs += rules_.quad_counts_as_two_pairs ? n / 2 : n >= 2;
                    distinct += n > 0;
                }
                int seven = 6 - pairs + (rules_.quad_counts_as_two_pairs ? 0 : std::max(0, 7 - distinct));
                for (int o : orphans) { unique_orphans += next.concealed[o] > 0; orphan_pair |= next.concealed[o] >= 2; }
                improved = std::min(seven, 13 - unique_orphans - int(orphan_pair)) < baseline;
            }
            if (!improved) {
                bool connected=hand.concealed[t]>0;
                if (t<27) for (int offset=-2;offset<=2;++offset) {
                    int other=t+offset;
                    if (other>=0 && other<27 && other/9==t/9 && hand.concealed[other]) connected=true;
                }
                // With no dead singleton to replace, a new isolated tile cannot
                // improve the standard hand. Special hands were checked above.
                if (!connected && !dead_single_possible) {
                    --next.concealed[t]; --physical[t]; continue;
                }
                auto tiles = next.concealed;
                if (baseline==0) {
                    bool straight=false;
                    improved=complete_dfs(tiles,4-static_cast<int>(hand.melds.size()),false,{},straight);
                } else {
                    int best = 8;
                    standard_dfs(tiles, 0, static_cast<int>(hand.melds.size()), 0, -1, 0, false, physical, best, baseline - 1);
                    improved = best < baseline;
                }
            }
        }
        if (improved) mask |= std::uint64_t(1) << t;
        --next.concealed[t]; --physical[t];
    }
    if (improving_cache_.size() >= 100000) improving_cache_.clear();
    improving_cache_.emplace(key, mask);
    return mask;
}

Efficiency efficiency(Evaluator& evaluator, const Hand& hand, const Counts& unseen) {
    validate_hand(hand, false);
    Efficiency result;
    result.distance = evaluator.distance(hand);
    Counts own = physical_tiles(hand);
    Hand next = hand;
    auto mask = evaluator.improving_mask(hand);
    for (int tile = 0; tile < tile_types; ++tile) {
        if (unseen[tile] == 0 || own[tile] >= 4) continue;
        ++next.concealed[tile];
        if ((mask >> tile) & 1u) {
            result.improving_tiles.push_back(tile);
            result.improving_copies += unseen[tile];
            if (result.distance.best() == 0) {
                auto p = evaluator.patterns(next);
                if (p.winning()) result.winning_value += unseen[tile] * payment_per_loser(p);
            }
        }
        --next.concealed[tile];
    }
    return result;
}

} // namespace alphamah
