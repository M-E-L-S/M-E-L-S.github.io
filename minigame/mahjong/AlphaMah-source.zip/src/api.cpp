#include "alphamah/api.h"
#include "alphamah/core.hpp"
#include <cstring>
#include <exception>
#include <stdexcept>
#include <sstream>
#include <thread>
#include <algorithm>

extern "C" int alphamah_search_timed(const char* hand,const char* melds,const char* known,
    const char* context,const char* opponents,const char* rivers,int replacement,
    uint32_t milliseconds,int draws,uint32_t seed,char* out,int capacity) {
    if (capacity<0 || (!out && capacity)) return -1;
    if (!capacity) return 131072;
    out[0]='\0';
    try {
        if (!hand || !rivers || milliseconds<1 || (replacement!=0 && replacement!=1)) throw std::invalid_argument("Invalid timed request");
        auto o=alphamah::parse_observation(hand,melds ? melds : "",known ? known : "",context ? context : "",opponents ? opponents : "",replacement!=0,rivers);
        alphamah::SearchConfig c; c.time_limit_ms=milliseconds; c.max_draws=draws; c.seed=seed; c.risk_samples=64;
#ifdef __EMSCRIPTEN_PTHREADS__
        c.threads=std::min(4u,std::max(1u,std::thread::hardware_concurrency()));
#endif
        auto json=alphamah::result_json(alphamah::search(o,c));
        if (capacity<=static_cast<int>(json.size())) return static_cast<int>(json.size()+1);
        std::memcpy(out,json.c_str(),json.size()+1); return 0;
    } catch (const std::exception&) { return -1; }
}

namespace {
std::string escape(const std::string& input) {
    std::string out;
    for (unsigned char c : input) {
        if (c == '"' || c == '\\') out.push_back('\\');
        if (c >= 32) out.push_back(static_cast<char>(c));
    }
    return out;
}
}

extern "C" int alphamah_search_public(const char* hand, const char* melds, const char* known,
                                      const char* context, const char* opponents, int replacement,
                                      uint32_t samples, int draws, uint32_t seed, uint32_t risk_samples,
                                      char* out, int capacity) {
    if (capacity < 0 || (!out && capacity > 0)) return -1;
    if (out && capacity) out[0] = '\0';
    try {
        if (!hand) throw std::invalid_argument("Hand is required");
        if (replacement != 0 && replacement != 1) throw std::invalid_argument("Invalid replacement flag");
        auto o = alphamah::parse_observation(hand,melds ? melds : "",known ? known : "",
                                            context ? context : "",opponents ? opponents : "",replacement != 0);
        alphamah::SearchConfig config;
        config.samples_per_discard = samples; config.max_draws = draws;
        config.seed = seed; config.risk_samples = risk_samples;
        auto json = alphamah::result_json(alphamah::search(o,config));
        int needed = static_cast<int>(json.size()+1);
        if (capacity < needed) return needed;
        std::memcpy(out,json.c_str(),json.size()+1); return 0;
    } catch (const std::exception& error) {
        auto json = "{\"error\":\"" + escape(error.what()) + "\"}";
        if (out && capacity > static_cast<int>(json.size())) std::memcpy(out,json.c_str(),json.size()+1);
        return -1;
    }
}

extern "C" int alphamah_search(const char* hand, const char* known, uint32_t samples,
                                int draws, uint32_t seed, char* out, int capacity) {
    if (capacity < 0 || (!out && capacity > 0)) return -1;
    if (out && capacity) out[0] = '\0';
    try {
        if (!hand) throw std::invalid_argument("Hand is required");
        alphamah::Observation observation;
        observation.hand.concealed = alphamah::parse_tiles(hand);
        if (known) observation.known_outside = alphamah::parse_tiles(known);
        alphamah::SearchConfig config;
        config.samples_per_discard = samples;
        config.max_draws = draws;
        config.seed = seed;
        std::string json = alphamah::result_json(alphamah::search(observation, config));
        int needed = static_cast<int>(json.size() + 1);
        if (capacity < needed) return needed;
        std::memcpy(out, json.c_str(), json.size() + 1);
        return 0;
    } catch (const std::exception& error) {
        std::string json = "{\"error\":\"" + escape(error.what()) + "\"}";
        if (out && capacity > static_cast<int>(json.size()))
            std::memcpy(out, json.c_str(), json.size() + 1);
        return -1;
    }
}

extern "C" int alphamah_search_table(const char* hand,const char* melds,const char* known,
                                     const char* context,const char* opponents,const char* rivers,int replacement,
                                     uint32_t samples,int draws,uint32_t seed,uint32_t risk_samples,char* out,int capacity) {
    if (capacity<0 || (!out && capacity>0)) return -1;
    if (out && capacity) out[0]='\0';
    try {
        if (!hand || !rivers || (replacement!=0 && replacement!=1)) throw std::invalid_argument("Full table inputs required");
        auto o=alphamah::parse_observation(hand,melds ? melds : "",known ? known : "",context ? context : "",
                                           opponents ? opponents : "",replacement!=0,rivers);
        if (!o.has_public_table) throw std::invalid_argument("Full public rivers required");
        alphamah::SearchConfig config; config.samples_per_discard=samples; config.max_draws=draws;
        config.seed=seed; config.risk_samples=risk_samples;
        auto json=alphamah::result_json(alphamah::search(o,config)); int needed=static_cast<int>(json.size()+1);
        if (capacity<needed) return needed;
        std::memcpy(out,json.c_str(),json.size()+1); return 0;
    } catch (const std::exception& error) {
        auto json="{\"error\":\""+escape(error.what())+"\"}";
        if (out && capacity>static_cast<int>(json.size())) std::memcpy(out,json.c_str(),json.size()+1);
        return -1;
    }
}

extern "C" int alphamah_evaluate(const char* hand,const char* melds,const char* known,int replacement,char* out,int capacity) {
    if(capacity<0 || (!out && capacity)) return -1;
    try {
        auto o=alphamah::parse_observation(hand,melds,known,"","",replacement!=0);
        alphamah::Evaluator e; auto d=e.distance(o.hand);
        bool drawn=alphamah::tile_count(o.hand.concealed)==14-3*int(o.hand.melds.size());
        alphamah::Patterns p; if(drawn) p=e.patterns(o.hand);
        std::ostringstream s;
        s << "{\"shanten\":" << d.best() << ",\"winning\":" << (p.winning()?"true":"false")
          << ",\"seven_pairs\":" << p.seven_pairs << ",\"pure_straight\":" << p.pure_straight
          << ",\"thirteen_orphans\":" << p.thirteen_orphans << ",\"payment\":"
          << (p.winning()?alphamah::payment_per_loser(p,o.current_draw):0) << "}";
        auto json=s.str(); if(capacity<=int(json.size())) return int(json.size()+1);
        std::memcpy(out,json.c_str(),json.size()+1); return 0;
    } catch(const std::exception&) {return -1;}
}

extern "C" int alphamah_hints(const char* hand,const char* melds,const char* known,char* out,int capacity) {
    if (capacity<0 || (!out && capacity)) return -1;
    if (out && capacity) out[0]='\0';
    try {
        if (!hand) throw std::invalid_argument("Hand is required");
        auto o=alphamah::parse_observation(hand,melds ? melds : "",known ? known : "","","",false);
        auto unseen=alphamah::unseen_tiles(o);
        alphamah::Evaluator evaluator;
        std::ostringstream s;
        auto waits=[&](const alphamah::Hand& h) {
            s << '[';
            auto mask=evaluator.distance(h).best()==0 ? evaluator.improving_mask(h) : 0;
            bool first=true;
            for (int t=0;t<34;++t) if ((mask>>t)&1u) {
                if (!first) s << ',';
                first=false;
                s << "{\"tile\":" << t << ",\"remaining\":" << int(unseen[t]) << '}';
            }
            s << ']';
        };
        const int count=alphamah::tile_count(o.hand.concealed);
        const int resting=13-3*int(o.hand.melds.size());
        s << "{\"waits\":";
        if (count==resting) waits(o.hand); else s << "[]";
        s << ",\"discards\":[";
        bool first=true;
        if (count==resting+1) for (int t=0;t<34;++t) if (o.hand.concealed[t]) {
            --o.hand.concealed[t];
            if (evaluator.distance(o.hand).best()==0 && evaluator.improving_mask(o.hand)) {
                if (!first) s << ',';
                first=false;
                s << "{\"tile\":" << t << ",\"waits\":"; waits(o.hand); s << '}';
            }
            ++o.hand.concealed[t];
        }
        s << "]}";
        auto json=s.str();
        if (capacity<=int(json.size())) return int(json.size()+1);
        std::memcpy(out,json.c_str(),json.size()+1); return 0;
    } catch (const std::exception&) {return -1;}
}
