// Emscripten links the C adapter from the static library via EXPORTED_FUNCTIONS.
// The browser Worker owns the module; no game or search runs at module load.
