// Thin local-rule/API adapter. Selection, expansion, IS and MDTT run in vendor/meowcats.
#include "alphamah/winning_subsets.hpp"
#include "alphamah/simulation.hpp"
#include "MctsLibrary/Mcts2.h"
#include "SamplingLibrary/GodMoveSampling_v3.h"
#include <chrono>
#include <mutex>
#include <stdexcept>

thread_local std::default_random_engine gen(1);
thread_local std::uniform_real_distribution<double> dis_double(0,1);
thread_local std::uniform_int_distribution<int> dis_int(0,INT_MAX);

namespace {
thread_local alphamah::Rules local_rules;
thread_local alphamah::Evaluator* rule_evaluator=nullptr;
alphamah::Distance local_distance(const alphamah::Hand& h) {
    if(rule_evaluator) return rule_evaluator->distance(h);
    return alphamah::Evaluator(local_rules).distance(h);
}
struct HostResources {
    alphamah::Evaluator evaluator;
    alphamah::Evaluator* previous=rule_evaluator;
    explicit HostResources(alphamah::Rules rules):evaluator(rules) { rule_evaluator=&evaluator; }
    ~HostResources() { TT::releaseTable();rule_evaluator=previous; }
};
alphamah::Hand local_hand(const PlayerTile& p) {
    alphamah::Hand h;
    for(int t=0;t<34;++t) h.concealed[t]=p.getHandTileNumber(t);
    for(auto m:p.getMeldTiles()) {
        auto type=m.getMeldType();
        auto kind=type==MeldType::Meld_DarkKong ? alphamah::MeldKind::ConcealedKong :
            type==MeldType::Meld_Kong ? alphamah::MeldKind::OpenKong :
            type==MeldType::Meld_Pong ? alphamah::MeldKind::Triplet : alphamah::MeldKind::Sequence;
        h.melds.push_back({kind,int(m.getMinRankTile()),m.getTargetPlayer()});
    }
    return h;
}
PlayerTile upstream_hand(const alphamah::Hand& h) {
    HandTile hand; for(int t=0;t<34;++t) for(int k=0;k<h.concealed[t];++k) hand.putTile(t);
    std::vector<MeldTile> melds;
    for(auto m:h.melds) {
        auto type=m.kind==alphamah::MeldKind::Sequence ? MeldType::Meld_EatLeft :
            m.kind==alphamah::MeldKind::Triplet ? MeldType::Meld_Pong :
            m.kind==alphamah::MeldKind::ConcealedKong ? MeldType::Meld_DarkKong : MeldType::Meld_Kong;
        melds.emplace_back(Tile(m.tile),type,m.source_player);
    }
    return PlayerTile(hand,melds);
}
Move upstream_move(const alphamah::Action& a) {
    using K=alphamah::ActionKind; MoveType type=MoveType::Move_Pass;
    switch(a.kind) {
    case K::Discard:type=MoveType::Move_Throw;break;
    case K::Pon:type=MoveType::Move_Pong;break;
    case K::Kong:type=MoveType::Move_Kong;break;
    case K::ConcealedKong:type=MoveType::Move_DarkKong;break;
    case K::AddedKong:type=MoveType::Move_UpgradeKong;break;
    case K::Chi:type=a.tile==a.sequence_start ? MoveType::Move_EatLeft : a.tile==a.sequence_start+1 ? MoveType::Move_EatMiddle : MoveType::Move_EatRight;break;
    default:break;
    }
    return a.tile<0 ? Move(type):Move(type,Tile(a.tile));
}
class HostMcts : public Mcts2 {
public:
    HostMcts(const SamplingData& data,const MctsConfig& cfg,const std::vector<Move>& moves) {
        _init(data,cfg,true); setupCandidateNodes(moves);
    }
};
alphamah::Action local_action(const Move& m,const alphamah::Observation& o) {
    alphamah::Evaluator e(local_rules);
    for(auto a:alphamah::round_legal_actions(o,e)) {
        auto expected=upstream_move(a);
        if(expected.getMoveType()==m.getMoveType() && (a.tile<0 || expected.getTargetTile()==m.getTargetTile())) return a;
    }
    throw std::logic_error("Upstream selected an action outside the local legal set: "+m.toString());
}
alphamah::Efficiency display_efficiency(const PlayerTile& original,const Move& move,const alphamah::Counts& pool) {
    auto p=original;p.doAction(move);auto h=local_hand(p);
    if(alphamah::tile_count(h.concealed)+int(h.melds.size())*3!=14)
        return alphamah::efficiency(*rule_evaluator,h,pool);
    alphamah::Efficiency best;best.distance.standard=best.distance.seven_pairs=best.distance.thirteen_orphans=99;
    for(int t=0;t<34;++t) if(h.concealed[t]) {
        --h.concealed[t];auto e=alphamah::efficiency(*rule_evaluator,h,pool);++h.concealed[t];
        if(e.distance.best()<best.distance.best() || (e.distance.best()==best.distance.best() && e.improving_copies>best.improving_copies)) best=e;
    }
    return best;
}
}
// The author uses min-lack=0 for a win, 1 for tenpai; our shanten is one lower.
int PlayerTile::getMinLack() const {
    auto h=local_hand(*this);
    if(alphamah::tile_count(h.concealed)+int(h.melds.size())*3>14)
        return alphamah::paper::contains_win(h,local_rules) ? 0 : 1;
    return local_distance(h).best()+1;
}
int PlayerTile::getMinLack(const int&) const { return getMinLack(); }
bool PlayerTile::isWin(const int&) const { return alphamah::paper::contains_win(local_hand(*this),local_rules); }
bool PlayerTile::canWin(const Tile& t,const int&) const {
    auto h=local_hand(*this); if(h.concealed[int(t)]>=4) return false;
    ++h.concealed[int(t)]; return alphamah::paper::contains_win(h,local_rules);
}
bool PlayerTile::willBeAloneTile(const Tile& t) const {
    if(!m_oHandTile.willBeAloneTile(t)) return false;
    if(!m_vMeldTiles.empty()) return true;
    // Minimal special-hand exception: retain a tile only when it improves the local shanten.
    auto h=local_hand(*this); auto before=local_distance(h);
    ++h.concealed[int(t)]; auto after=local_distance(h);
    return after.seven_pairs>=before.seven_pairs && after.thirteen_orphans>=before.thirteen_orphans;
}
int HandTile::getMinLack() const { return getMinLack(getNeedMeldNumber()); }
int HandTile::getMinLack(const int& groups) const {
    alphamah::Hand h; for(int t=0;t<34;++t) h.concealed[t]=getTileNumber(t);
    for(int i=groups;i<4;++i) h.melds.push_back({alphamah::MeldKind::Triplet,27+i%7,-1});
    if(alphamah::tile_count(h.concealed)+int(h.melds.size())*3>14)
        return alphamah::paper::contains_win(h,local_rules) ? 0 : 1;
    return local_distance(h).best()+1;
}

namespace alphamah {
bool upstream_prefer(const Candidate& a,const Candidate& b) {
    // MctsPlayer::getBestMove, SelectBestWinRateCandidate=0: greatest TT visits;
    // its >= comparison elects the last original root candidate on a tie.
    return a.samples!=b.samples ? a.samples>b.samples:a.upstream_order>b.upstream_order;
}
SearchResult upstream_search(const Observation& o,const SearchConfig& c) {
    const auto started=std::chrono::steady_clock::now();
    paper::SubsetContext subset_context;
    if(c.max_draws<1 || c.max_draws>34 || !c.samples_per_discard || c.samples_per_discard>100000 || c.iterations>1000000)
        throw std::invalid_argument("Original PD requires draws 1-34, ten samples per batch and no external risk adapter");
    static MctsConfig base_config;
    static std::once_flag once;
    std::call_once(once,[]{Tile::setupTileIds();MJStateHashKeyCalculator::makeTable();DrawCountTable table;base_config.loadFromConfigFile(Ini::getInstance());});
    local_rules=c.rules; HostResources resources(c.rules); gen.seed(c.seed);
    validate_hand(o.hand,o.offered_tile<0);
    auto legal=round_legal_actions(o,*rule_evaluator);
    SearchResult result; result.paper=result.upstream_pd=true;
    if(legal.front().kind==ActionKind::Win) {
        result.win_now=true;result.recommended_action=legal.front();
        Hand h=o.hand;if(o.offered_tile>=0) ++h.concealed[o.offered_tile];
        result.gain_now=(o.offered_tile>=0 ? 1:3)*payment_per_loser(rule_evaluator->patterns(h),o.current_draw);
        return result;
    }
    auto player=upstream_hand(o.hand); auto pool=unseen_tiles(o);std::string counts;
    for(auto n:pool) counts.push_back(char('0'+n));
    RemainTile remain(counts,RemainTileType::Type_Original);
    auto choices_for_root=[&]{
        std::vector<Move> choices;
        if(o.offered_tile>=0) {
            for(auto type:{MoveType::Move_Pass,MoveType::Move_EatLeft,MoveType::Move_EatMiddle,MoveType::Move_EatRight,MoveType::Move_Pong,MoveType::Move_Kong})
                for(auto a:legal) if(upstream_move(a).getMoveType()==type) choices.push_back(upstream_move(a));
        } else {
            for(auto m:Mcts2::getLegalMoves(player,remain,o.allow_self_kong,false,c.merge_solitary))
                for(auto a:legal) if(upstream_move(a)==m) {choices.push_back(m);break;}
        }
        return choices;
    };
    if(tile_count(pool)/4<player.getMinLack()) {
        // The original four-player leaf sampler clamps this pool to zero rounds,
        // while Mcts2 asserts a positive min-lack horizon. Handle the unsupported
        // boundary without inventing future samples; retain its zero-value tie rule.
        for(auto move:choices_for_root()) {
            Candidate x;x.action=local_action(move,o);x.upstream_order=int(result.candidates.size());
            x.discard=x.action.kind==ActionKind::Discard ? x.action.tile:-1;
            x.efficiency=display_efficiency(player,move,pool);result.candidates.push_back(x);
        }
        std::stable_sort(result.candidates.begin(),result.candidates.end(),upstream_prefer);
        result.recommended_action=result.candidates.front().action;result.recommended_discard=result.candidates.front().discard;
        result.tree_nodes=1;return result;
    }
    int left=o.remaining_wall<0 ? c.max_draws:o.remaining_wall/4;
    left=std::clamp(left,0,AVERAGE_MAX_DRAW_COUNT);
    int horizon=std::max(DrawCountTable::getDrawCount(player.getMinLack(),left),player.getMinLack());
    // Retain upstream max(requested horizon, min-lack); the optimistic model's horizon
    // is not a literal simulation of the public wall, exactly as in the author's constructor.
    SamplingData data(Move(),player,remain,horizon);
    if(o.offered_tile>=0 && Ini::getInstance().getIntIni("MCTS.UseFlatMCMeld")) {
        // Author's shipped config selects FlatMC for calls (MctsPlayer::getBestMeldMove).
        // Preserve that path too; it is not the old local root-only search.
        bool chi=false,kong=false;
        for(auto a:legal) {chi|=a.kind==ActionKind::Chi;kong|=a.kind==ActionKind::Kong;}
        unsigned budget=c.iterations ? c.iterations*10:c.samples_per_discard*unsigned(legal.size())*10;
        auto mode=c.time_limit_ms ? GodMoveSampling_v3::SampleMode::Mode_Time:GodMoveSampling_v3::SampleMode::Mode_Count;
        auto spent=std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now()-started).count();
        unsigned ms=unsigned(std::max<long long>(1,static_cast<long long>(c.time_limit_ms)-spent));
        GodMoveSampling_v3 flat(player,remain,mode,c.time_limit_ms ? ms:budget,horizon);
        auto best=flat.meld(Tile(o.offered_tile),chi,kong);
        for(auto a:legal) if(upstream_move(a).getMoveType()==best) result.recommended_action=a;
        for(auto d:flat.getCandidates()) {
            Candidate x;x.action=local_action(d.m_oAction,o);x.samples=d.m_iUsedSampleCount;
            x.efficiency=display_efficiency(player,d.m_oAction,pool);
            if(x.action.kind==ActionKind::Chi || x.action.kind==ActionKind::Pon) {
                auto after=player;after.doAction(d.m_oAction);
                for(int t=0;t<34;++t) if(after.getHandTileNumber(t)>d.m_oPlayerTile.getHandTileNumber(t)) x.followup_discard=t;
            }
            x.wins=d.getWinCount();x.win_probability=x.samples ? x.wins/x.samples:0;
            x.search_value=x.win_probability;x.expected_gain=30*x.win_probability;result.candidates.push_back(x);
        }
        result.paper_rollouts=flat.getUsedSampleCount();result.iterations=(result.paper_rollouts+9)/10;
        return result;
    }
    MctsConfig cfg=base_config;
    cfg.m_bMergeAloneTile=c.merge_solitary;cfg.m_bUseImportanceSampling=c.importance_sampling;
    cfg.m_bUseTT=c.multidepth_sharing;
    // A per-thread TT is allocated even for the no-TT profile because upstream init clears it.
    TT::makeTable(15);
    auto choices=choices_for_root();
    HostMcts tree(data,cfg,choices);
    unsigned target=c.iterations ? c.iterations:c.samples_per_discard*unsigned(tree.getRootNodePtr()->getChildrenCount());
    target=std::max(target,unsigned(tree.getRootNodePtr()->getChildrenCount()));
    if(c.time_limit_ms) {
        // The original clock() budget measures process CPU time on some platforms; use elapsed
        // time at the host boundary, retaining the author's sample() iteration unchanged.
        do {tree.sample(10);} while(tree.getRootNodePtr()->getChildrenCount()>1 &&
            std::chrono::steady_clock::now()-started<std::chrono::milliseconds(c.time_limit_ms));
    } else tree.sample(int(target)*10);
    auto root=tree.getRootNodePtr();result.iterations=root->getVisitCountNoTT();result.paper_rollouts=result.iterations*10;
    for(auto child:root->m_vChildren) {
        Candidate x;x.action=local_action(child->getMove(),o);
        x.upstream_order=child->getChildId();
        if(x.action.kind==ActionKind::Chi || x.action.kind==ActionKind::Pon)
            x.followup_discard=int(child->m_vChildren.front()->getMove().getTargetTile());
        x.discard=x.action.kind==ActionKind::Discard ? x.action.tile:-1;
        if(child->isCompleteSetup()) {x.samples=child->getVisitCountTT();x.wins=child->getWinCountTT();}
        x.win_probability=x.samples ? x.wins/x.samples:0;x.search_value=x.win_probability;x.expected_gain=30*x.win_probability;
        x.efficiency=display_efficiency(player,child->getMove(),pool);
        result.candidates.push_back(x);
    }
    std::stable_sort(result.candidates.begin(),result.candidates.end(),upstream_prefer);
    result.recommended_action=result.candidates.front().action;result.recommended_discard=result.candidates.front().discard;
    std::vector<std::pair<const BaseTreeNode2*,int>> stack{{root,0}};
    while(!stack.empty()) {
        auto [node,depth]=stack.back();stack.pop_back();++result.tree_nodes;
        bool decision=dynamic_cast<const ChanceNode2*>(node)==nullptr;
        if(decision && node->m_vChildren.size()>1) {++result.branching_decision_nodes;++depth;}
        result.max_decision_depth=std::max(result.max_decision_depth,depth);
        for(auto child:node->m_vChildren) stack.push_back({child.get(),depth});
    }
    return result;
}
}
