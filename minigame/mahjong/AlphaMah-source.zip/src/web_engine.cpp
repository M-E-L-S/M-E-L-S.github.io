// Local GUI adapter. Search and hand/scoring algorithms remain in the core.
#include "alphamah/core.hpp"
#include <iostream>
#include <sstream>
#include <stdexcept>

int main(int argc, char** argv) {
    try {
        if (argc < 9 || argc > 16) throw std::invalid_argument("Expected mode hand melds known replacement samples draws seed [context [opponents [risk_samples [rivers]]]]");
        std::string mode = argv[1];
        auto o = alphamah::parse_observation(argv[2],argv[3],argv[4],argc >= 10 ? argv[9] : "",
                                             argc >= 11 ? argv[10] : "",std::string(argv[5]) == "1",argc >= 13 ? argv[12] : "");
        if (mode == "search" || mode == "respond") {
            alphamah::SearchConfig config;
            config.samples_per_discard = static_cast<std::uint32_t>(std::stoul(argv[6]));
            config.max_draws = std::stoi(argv[7]);
            config.seed = static_cast<std::uint32_t>(std::stoul(argv[8]));
            if (argc >= 12) config.risk_samples = static_cast<std::uint32_t>(std::stoul(argv[11]));
            if (argc >= 14) config.time_limit_ms=static_cast<std::uint32_t>(std::stoul(argv[13]));
            if (argc >= 15) config.threads=static_cast<unsigned>(std::stoul(argv[14]));
            if (argc >= 16) {
                unsigned mask=std::stoul(argv[15]);
                if(mask>7) throw std::invalid_argument("Invalid component mask");
                config.merge_solitary=mask&1; config.importance_sampling=mask&2; config.multidepth_sharing=mask&4;
            }
            std::cout << alphamah::result_json(alphamah::search(o, config)) << '\n';
        } else if (mode == "evaluate") {
            alphamah::Evaluator evaluator;
            auto d = evaluator.distance(o.hand);
            bool after_draw = alphamah::tile_count(o.hand.concealed) == 14 - 3 * int(o.hand.melds.size());
            alphamah::Patterns p;
            if (after_draw) p = evaluator.patterns(o.hand);
            std::cout << "{\"shanten\":" << d.best() << ",\"winning\":" << (p.winning() ? "true" : "false")
                << ",\"standard\":" << p.standard << ",\"seven_pairs\":" << p.seven_pairs
                << ",\"thirteen_orphans\":" << p.thirteen_orphans << ",\"pure_straight\":" << p.pure_straight
                << ",\"payment\":" << (p.winning() ? alphamah::payment_per_loser(p, o.current_draw) : 0);
            std::cout << ",\"waits\":[";
            if (!after_draw) {
                auto e = alphamah::efficiency(evaluator, o.hand, alphamah::unseen_tiles(o));
                for (std::size_t i = 0; i < e.improving_tiles.size(); ++i) {
                    if (i) std::cout << ',';
                    std::cout << e.improving_tiles[i];
                }
                std::cout << "],\"ukeire\":" << e.improving_copies;
            } else std::cout << "],\"ukeire\":0";
            std::cout << "}\n";
        } else throw std::invalid_argument("Unknown mode");
        return 0;
    } catch (const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
