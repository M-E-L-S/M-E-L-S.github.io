#include "alphamah/simulation.hpp"
#include <algorithm>
#include <chrono>
#include <stdexcept>
#if !defined(__EMSCRIPTEN__) || defined(__EMSCRIPTEN_PTHREADS__)
#include <future>
#endif

namespace alphamah {
SearchResult search(const Observation& o,const SearchConfig& config) {
    if (config.time_limit_ms>8000 || config.threads<1 || config.threads>64)
        throw std::invalid_argument("Time limit must be 0-8000 ms and workers 1-64");
    const auto start=std::chrono::steady_clock::now();
    auto run=[&](SearchConfig c) { return upstream_search(o,c); };
    SearchResult result;
#if !defined(__EMSCRIPTEN__) || defined(__EMSCRIPTEN_PTHREADS__)
    unsigned total=config.iterations, workers=config.threads;
    if(o.offered_tile>=0) workers=1; // Author's FlatMC call policy is one host decision.
    if (!config.time_limit_ms && workers>1) {
        unsigned roots=static_cast<unsigned>(legal_actions(o).size());
        total=config.iterations ? config.iterations : config.samples_per_discard*roots;
        workers=std::min(workers,std::max(1u,total/std::max(1u,roots)));
    }
    if (workers>1) {
        std::vector<std::future<SearchResult>> tasks;
        for (unsigned i=0;i<workers;++i) {
            auto c=config; c.threads=1; c.seed+=i*0x9e3779b9u;
            c.iterations=total/workers+(i<total%workers);
            tasks.push_back(std::async(std::launch::async,[run,c]{return run(c);}));
        }
        result=tasks.front().get(); result.workers=workers;
        for (unsigned i=1;i<workers;++i) {
            auto other=tasks[i].get();
            result.iterations+=other.iterations; result.world_samples+=other.world_samples;
            result.tree_nodes+=other.tree_nodes; result.branching_decision_nodes+=other.branching_decision_nodes;
            result.max_decision_depth=std::max(result.max_decision_depth,other.max_decision_depth);
            result.simulated_actions+=other.simulated_actions; result.importance_ess+=other.importance_ess;
            result.importance_draws+=other.importance_draws; result.solitary_deferrals+=other.solitary_deferrals;
            result.short_horizon_captures+=other.short_horizon_captures;
            result.paper_rollouts+=other.paper_rollouts; result.paper_cycle_skips+=other.paper_cycle_skips;
            result.paper_horizon_updates+=other.paper_horizon_updates;
            result.paper_chance_groups+=other.paper_chance_groups; result.paper_solitary_groups+=other.paper_solitary_groups;
            for (auto& c:result.candidates) {
                auto found=std::find_if(other.candidates.begin(),other.candidates.end(),[&](const Candidate& b){return same_action(c.action,b.action) && c.followup_discard==b.followup_discard;});
                if (found==other.candidates.end()) throw std::logic_error("Parallel root actions differ");
                const auto& b=*found; double n=c.samples+b.samples;
                if(result.upstream_pd && !n) continue;
                c.mean_winning_draw=(c.mean_winning_draw*c.wins+b.mean_winning_draw*b.wins)/std::max(1e-100,c.wins+b.wins);
                for (auto member:{&Candidate::expected_gain,&Candidate::expected_loss,&Candidate::continuation_value,&Candidate::search_value})
                    c.*member=((c.*member)*c.samples+(b.*member)*b.samples)/n;
                c.samples+=b.samples; c.wins+=b.wins; c.win_probability=c.wins/c.samples;
            }
        }
        std::stable_sort(result.candidates.begin(),result.candidates.end(),upstream_prefer);
        if (!result.candidates.empty()) { result.recommended_action=result.candidates.front().action; result.recommended_discard=result.candidates.front().discard; }
    } else result=run(config);
#else
    if (config.threads!=1) throw std::invalid_argument("WASM build uses one worker");
    result=run(config);
#endif
    if (config.time_limit_ms) result.elapsed_ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
    return result;
}
}
