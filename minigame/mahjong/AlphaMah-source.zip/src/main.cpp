#include "alphamah/core.hpp"
#include "alphamah/profile.hpp"
#include <chrono>
#include <iostream>
#include <stdexcept>

int main(int argc, char** argv) {
    try {
        alphamah::Observation observation;
        alphamah::SearchConfig config;
        bool hand_given = false;
        bool budget_given=false, time_given=false, draws_given=false, risk_given=false;
        for (int i = 1; i < argc; ++i) {
            std::string option = argv[i];
            if (option == "--help") {
                std::cout << "alphamah_cli --hand 123m123p123s11z22z3z [--known 123m] "
                             "[--samples 128 | --iterations 1000] [--draws 18] [--seed 1] [--quad-pairs] "
                             "[--melds encoding --context encoding --opponents encoding --rivers encoding --risk-samples 128] "
                             "[--original-pd | --original-all] [--importance] [--merge-solitary] [--multidepth] [--level fast|standard|deep] [--time-ms 3000] [--threads 2]\n";
                return 0;
            }
            if (option == "--quad-pairs") { config.rules.quad_counts_as_two_pairs = true; continue; }
            if (option == "--original-pd" || option == "--no-risk") continue;
            if (option == "--original-all") { config.merge_solitary=config.importance_sampling=config.multidepth_sharing=true;continue; }
            if (option == "--importance") { config.importance_sampling=true;continue; }
            if (option == "--merge-solitary") { config.merge_solitary=true;continue; }
            if (option == "--multidepth") { config.multidepth_sharing=true;continue; }
            if (i + 1 == argc) throw std::invalid_argument("Missing value for " + option);
            std::string value = argv[++i];
            if (option == "--level") {
                if (value!="fast" && value!="standard" && value!="deep") throw std::invalid_argument("Level must be fast, standard or deep");
                config.time_limit_ms=value=="fast" ? 1000 : value=="standard" ? 3000 : 8000;
                config.max_draws=value=="fast" ? 4 : value=="standard" ? 6 : 10;
                config.risk_samples=value=="fast" ? 256 : value=="standard" ? 512 : 1024;
                time_given=draws_given=true;
            }
            else if (option == "--hand") { observation.hand.concealed = alphamah::parse_tiles(value); hand_given = true; }
            else if (option == "--known") observation.known_outside = alphamah::parse_tiles(value);
            else if (option == "--melds") observation.hand.melds = alphamah::parse_observation("",value,"").hand.melds;
            else if (option == "--context") {
                auto context=alphamah::parse_observation("","","",value);
                observation.player=context.player; observation.source_player=context.source_player;
                observation.offered_tile=context.offered_tile; observation.remaining_wall=context.remaining_wall;
                observation.allow_self_kong=context.allow_self_kong;
            }
            else if (option == "--opponents") observation.opponents = alphamah::parse_observation("","","","",value).opponents;
            else if (option == "--rivers") {
                auto public_table=alphamah::parse_observation("","","","","",false,value);
                observation.rivers=public_table.rivers; observation.has_public_table=true;
            }
            else if (option == "--samples" || option == "--iterations" || option == "--draws" || option == "--seed" || option == "--risk-samples" || option == "--time-ms" || option == "--threads") {
                if (value.empty() || value.find_first_not_of("0123456789") != std::string::npos)
                    throw std::invalid_argument("Expected nonnegative integer for " + option);
                auto number = std::stoull(value);
                if (number > UINT32_MAX) throw std::invalid_argument("Integer out of range");
                if (option=="--samples" || option=="--iterations") budget_given=true;
                if (option=="--time-ms") time_given=true;
                if (option=="--draws") draws_given=true;
                if (option=="--risk-samples") risk_given=true;
                if (option == "--time-ms") config.time_limit_ms=static_cast<std::uint32_t>(number);
                else if (option == "--threads") config.threads=static_cast<unsigned>(number);
                else if (option == "--samples") config.samples_per_discard = static_cast<std::uint32_t>(number);
                else if (option == "--iterations") config.iterations = static_cast<std::uint32_t>(number);
                else if (option == "--seed") config.seed = static_cast<std::uint32_t>(number);
                else if (option == "--risk-samples") config.risk_samples = static_cast<std::uint32_t>(number);
                else { if (number > 34) throw std::invalid_argument("Draw horizon must be 1-34"); config.max_draws = static_cast<int>(number); }
            } else throw std::invalid_argument("Unknown option " + option);
        }
        if (!hand_given) throw std::invalid_argument("Use --hand or --help");
        if (!budget_given && !time_given) config.time_limit_ms=3000;
        if (config.time_limit_ms && !draws_given)
            config.max_draws=config.time_limit_ms<=1000 ? 4 : config.time_limit_ms<=3000 ? 6 : 10;
        if (config.time_limit_ms && !risk_given)
            config.risk_samples=config.time_limit_ms<=1000 ? 256 : config.time_limit_ms<=3000 ? 512 : 1024;
        auto start = std::chrono::steady_clock::now();
        auto result = alphamah::search(observation, config);
        std::cout << alphamah::result_json(result) << '\n';
#ifdef ALPHAMAH_PROFILE
        for (int i=0;i<5;++i) std::cerr<<"profile_slot="<<i<<" calls="<<alphamah::profile_metrics[i].calls<<" inclusive_ns="<<alphamah::profile_metrics[i].ns<<'\n';
#endif
        std::cerr << "elapsed_ms=" << std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now() - start).count() << '\n';
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "error: " << error.what() << '\n';
        return 1;
    }
}
